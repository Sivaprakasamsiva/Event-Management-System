package Config;
import com.Event_Management.System.*;
import Connectors.DBConnection;
import Connectors.OTPCheck;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Register extends JFrame {
    private JTextField T1, T2, T3, T6, T7;
    private JPasswordField T4, T5;
    private JTextArea TA1;
    private JDateChooser DOB;
    private ButtonGroup genderGroup;
    private JRadioButton RB1, RB2, RB3;
    private JLabel customerIdLabel;
    private String generatedCustomerId;

    public Register() {
        super("Register - Event Management System");
        setupUI();
        setSize(500, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        
        // Generate customer ID when form opens
        generateCustomerId();
    }

    private void setupUI() {
        // Main panel with padding
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);

        // Header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = createFormPanel();
        mainPanel.add(new JScrollPane(formPanel), BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = createButtonPanel();
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(65, 105, 225));
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titleLabel = new JLabel("User Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Initialize components with modern styling
        initializeComponents();

        int row = 0;

        // Customer ID Section
        addSectionLabel("Customer ID", formPanel, gbc, row++);

        // Customer ID Display
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Customer ID:"), gbc);
        gbc.gridx = 1;
        customerIdLabel = new JLabel(generatedCustomerId != null ? generatedCustomerId : "Generating...");
        customerIdLabel.setFont(new Font("Arial", Font.BOLD, 14));
        customerIdLabel.setForeground(new Color(220, 53, 69));
        customerIdLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 53, 69), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        customerIdLabel.setOpaque(true);
        customerIdLabel.setBackground(new Color(255, 243, 205));
        customerIdLabel.setPreferredSize(new Dimension(200, 35));
        formPanel.add(customerIdLabel, gbc);
        row++;

        // Refresh Customer ID Button
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton refreshIdButton = new JButton("Refresh Customer ID");
        refreshIdButton.setFont(new Font("Arial", Font.PLAIN, 12));
        refreshIdButton.setBackground(new Color(108, 117, 125));
        refreshIdButton.setForeground(Color.WHITE);
        refreshIdButton.setFocusPainted(false);
        refreshIdButton.setPreferredSize(new Dimension(180, 30));
        refreshIdButton.addActionListener(e -> generateCustomerId());
        formPanel.add(refreshIdButton, gbc);
        row++;

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;

        // Personal Information Section
        addSectionLabel("Personal Information", formPanel, gbc, row++);

        // First Name
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("First Name *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T1), gbc);
        row++;

        // Last Name
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Last Name *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T2), gbc);
        row++;

        // Mobile Number
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Mobile Number:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T6), gbc);
        row++;

        // Email
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Email:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T7), gbc);
        row++;

        // Account Information Section
        addSectionLabel("Account Information", formPanel, gbc, row++);

        // Username
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Username *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T3), gbc);
        row++;

        // Password
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Password *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledPasswordField(T4), gbc);
        row++;

        // Confirm Password
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Confirm Password *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledPasswordField(T5), gbc);
        row++;

        // Additional Information Section
        addSectionLabel("Additional Information", formPanel, gbc, row++);

        // Date of Birth
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Date of Birth:"), gbc);
        gbc.gridx = 1;
        DOB.setPreferredSize(new Dimension(200, 30));
        DOB.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(DOB, gbc);
        row++;

        // Gender
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Gender:"), gbc);
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.setBackground(Color.WHITE);
        genderPanel.add(RB1);
        genderPanel.add(RB2);
        genderPanel.add(RB3);
        formPanel.add(genderPanel, gbc);
        row++;

        // Address
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Address:"), gbc);
        gbc.gridx = 1;
        JScrollPane addressScroll = new JScrollPane(TA1);
        addressScroll.setPreferredSize(new Dimension(200, 80));
        formPanel.add(addressScroll, gbc);
        row++;

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton B1 = createStyledButton("Create Account", new Color(40, 167, 69));
        JButton B2 = createStyledButton("Clear Form", new Color(108, 117, 125));

        B1.addActionListener(e -> createAccount());
        B2.addActionListener(e -> clearForm());

        buttonPanel.add(B1);
        buttonPanel.add(B2);

        return buttonPanel;
    }

    private void initializeComponents() {
        // Text fields
        T1 = new JTextField(20);
        T2 = new JTextField(20);
        T3 = new JTextField(20);
        T6 = new JTextField(20);
        T7 = new JTextField(20);

        // Password fields
        T4 = new JPasswordField(20);
        T5 = new JPasswordField(20);

        // Text area
        TA1 = new JTextArea(3, 20);
        TA1.setLineWrap(true);
        TA1.setWrapStyleWord(true);

        // Date chooser
        DOB = new JDateChooser();
        DOB.setDateFormatString("yyyy-MM-dd");

        // Gender radio buttons
        genderGroup = new ButtonGroup();
        RB1 = createStyledRadioButton("Male");
        RB2 = createStyledRadioButton("Female");
        RB3 = createStyledRadioButton("Other");

        genderGroup.add(RB1);
        genderGroup.add(RB2);
        genderGroup.add(RB3);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(51, 51, 51));
        return label;
    }

    private JTextField createStyledTextField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(200, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JPasswordField createStyledPasswordField(JPasswordField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(200, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JRadioButton createStyledRadioButton(String text) {
        JRadioButton radio = new JRadioButton(text);
        radio.setFont(new Font("Arial", Font.PLAIN, 14));
        radio.setBackground(Color.WHITE);
        return radio;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void addSectionLabel(String text, JPanel panel, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 8, 10, 8);
        
        JLabel sectionLabel = new JLabel(text);
        sectionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        sectionLabel.setForeground(new Color(65, 105, 225));
        sectionLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(65, 105, 225)));
        
        panel.add(sectionLabel, gbc);
        
        gbc.gridwidth = 1;
        gbc.insets = new Insets(8, 8, 8, 8);
    }

    private void generateCustomerId() {
        try (Connection con = DBConnection.getConnection()) {
            // Get the maximum customer ID from the database
            String sql = "SELECT MAX(CAST(SUBSTRING(member_id, 5) AS UNSIGNED)) as max_id FROM members WHERE member_id REGEXP '^CUST[0-9]+$'";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            int nextId = 1; // Default starting ID
            
            if (rs.next()) {
                int maxId = rs.getInt("max_id");
                if (!rs.wasNull()) {
                    nextId = maxId + 1;
                }
            }
            
            // Format the ID as CUST001, CUST002, etc.
            generatedCustomerId = String.format("CUST%03d", nextId);
            
            // Update the label
            if (customerIdLabel != null) {
                customerIdLabel.setText(generatedCustomerId);
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
            // Fallback ID generation
            generatedCustomerId = "CUST" + (System.currentTimeMillis() % 1000);
            if (customerIdLabel != null) {
                customerIdLabel.setText(generatedCustomerId + " (Temp)");
            }
            JOptionPane.showMessageDialog(this,
                "Could not generate sequential ID. Using temporary ID.",
                "Warning",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void createAccount() {
        String fname = T1.getText().trim();
        String lname = T2.getText().trim();
        String mobile = T6.getText().trim();
        String email = T7.getText().trim();
        String uname = T3.getText().trim();
        Date dob = DOB.getDate();
        String gender = getSelectedGender();
        String pass = new String(T4.getPassword());
        String cpass = new String(T5.getPassword());
        String address = TA1.getText().trim();

        // Validation
        if (!validateInput(fname, lname, uname, pass, cpass, mobile, email)) {
            return;
        }

        // Confirm customer ID
        int confirm = JOptionPane.showConfirmDialog(this,
            "Your Customer ID will be: " + generatedCustomerId + "\n\nDo you want to proceed with registration?",
            "Confirm Registration",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        // OTP Handling
        OTPCheck otpService = new OTPCheck();
        boolean otpSent = false;

        if (!mobile.isEmpty() && mobile.matches("\\d{10}")) {
            otpSent = otpService.sendOtpMobile("+91" + mobile);
        }

        if (!email.isEmpty() && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            boolean emailSent = otpService.sendOtpEmail(email);
            otpSent = otpSent || emailSent;
        }

        if (!otpSent) {
            JOptionPane.showMessageDialog(this,
                "Failed to send OTP to both mobile and email. Registration aborted!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean verified = otpService.verifyOtpWithDialog();
        if (!verified) {
            JOptionPane.showMessageDialog(this,
                "OTP verification failed. Registration aborted!",
                "Failed",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert into Database
        try (Connection con = DBConnection.getConnection()) {
            // Check if the generated customer ID is still available
            String checkSql = "SELECT member_id FROM members WHERE member_id = ?";
            PreparedStatement checkStmt = con.prepareStatement(checkSql);
            checkStmt.setString(1, generatedCustomerId);
            ResultSet checkRs = checkStmt.executeQuery();
            
            if (checkRs.next()) {
                // ID is taken, generate a new one
                generateCustomerId();
            }
            
            String sql = "INSERT INTO members(member_id, firstname, lastname, username, dob, gender, password, address, mobile, email) VALUES(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, generatedCustomerId);
            ps.setString(2, fname);
            ps.setString(3, lname);
            ps.setString(4, uname);
            ps.setDate(5, dob != null ? new java.sql.Date(dob.getTime()) : null);
            ps.setString(6, gender);
            ps.setString(7, pass);
            ps.setString(8, address);
            ps.setString(9, mobile);
            ps.setString(10, email);
            
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, 
                    "✅ Member registered successfully!\n\n" +
                    "Customer ID: " + generatedCustomerId + "\n" +
                    "Name: " + fname + " " + lname + "\n" +
                    "Username: " + uname, 
                    "Registration Successful", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                new App();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to register member. Please try again.",
                    "Registration Failed",
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Database error! " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validateInput(String fname, String lname, String uname, String pass, 
                                 String cpass, String mobile, String email) {
        if (fname.isEmpty() || lname.isEmpty() || uname.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please fill in all required fields!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!pass.equals(cpass)) {
            JOptionPane.showMessageDialog(this, 
                "Passwords do not match!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!pass.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$")) {
            JOptionPane.showMessageDialog(this,
                "Password must be at least 8 characters and include:\n" +
                "- Uppercase letter\n- Lowercase letter\n- Number",
                "Password Requirements",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        boolean validMobile = mobile.isEmpty() || mobile.matches("\\d{10}");
        boolean validEmail = email.isEmpty() || email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        if ((!mobile.isEmpty() && !validMobile) || (!email.isEmpty() && !validEmail)) {
            JOptionPane.showMessageDialog(this,
                "Please enter valid mobile number (10 digits) or email address.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (mobile.isEmpty() && email.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please provide either mobile number or email address for OTP verification.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Check if username already exists
        try (Connection con = DBConnection.getConnection()) {
            String checkSql = "SELECT username FROM members WHERE username = ?";
            PreparedStatement checkStmt = con.prepareStatement(checkSql);
            checkStmt.setString(1, uname);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                JOptionPane.showMessageDialog(this,
                    "Username '" + uname + "' is already taken. Please choose a different username.",
                    "Username Taken",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error checking username availability.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private String getSelectedGender() {
        if (RB1.isSelected()) return "Male";
        if (RB2.isSelected()) return "Female";
        if (RB3.isSelected()) return "Other";
        return null;
    }

    private void clearForm() {
        T1.setText("");
        T2.setText("");
        T3.setText("");
        T4.setText("");
        T5.setText("");
        T6.setText("");
        T7.setText("");
        TA1.setText("");
        genderGroup.clearSelection();
        DOB.setDate(null);
        // Regenerate customer ID when clearing form
        generateCustomerId();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Register());
    }
}