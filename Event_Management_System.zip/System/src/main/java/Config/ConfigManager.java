package Config;


import java.io.*;
import java.util.*;

import javax.swing.SwingUtilities;

public class ConfigManager {
    public static void main(String[] args) {
        new ConfigManager();
    }
    private static final String CONFIG_FILE = "config.properties";
    private Properties props = new Properties();

    public ConfigManager() {
        load();
    }

    public void load() {
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
            // After loading, ensure the complete DB URL is available
            updateCompleteDbUrl();
        } catch (IOException e) {
            System.out.println("Config file not found, using defaults.");
            setDefaultProperties();
        }
    }

    public void save() {
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Event Management Config");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String key) {
        // If requesting DB_URL and we have separate components, return the complete URL
        if ("DB_URL".equals(key) && hasSeparateDbComponents()) {
            return getCompleteDbUrl();
        }
        return props.getProperty(key, "");
    }

    public void set(String key, String value) {
        props.setProperty(key, value);
        
        // If DB_URL or DB_NAME is updated, update the complete URL
        if ("DB_URL".equals(key) || "DB_NAME".equals(key)) {
            updateCompleteDbUrl();
        }
    }
    
    private boolean hasSeparateDbComponents() {
        String baseUrl = props.getProperty("DB_URL", "");
        String dbName = props.getProperty("DB_NAME", "");
        
        // Check if we have separate components that need to be combined
        return !baseUrl.isEmpty() && !dbName.isEmpty() && !baseUrl.contains("/" + dbName);
    }
    
    private String getCompleteDbUrl() {
        String baseUrl = props.getProperty("DB_URL", "");
        String dbName = props.getProperty("DB_NAME", "");
        
        if (baseUrl.isEmpty() || dbName.isEmpty()) {
            return baseUrl;
        }
        
        // Remove any trailing slashes from base URL
        baseUrl = baseUrl.replaceAll("/+$", "");
        
        // Combine base URL and database name
        return baseUrl + "/" + dbName;
    }
    
    private void updateCompleteDbUrl() {
        if (hasSeparateDbComponents()) {
            String completeUrl = getCompleteDbUrl();
            // Store the complete URL separately so we don't modify the original base URL
            props.setProperty("DB_URL_COMPLETE", completeUrl);
        }
    }
    
    // Method to get the base DB URL without the database name
    public String getBaseDbUrl() {
        String url = props.getProperty("DB_URL", "");
        // If it's a complete URL with database name, extract the base
        if (url.contains("/")) {
            int lastSlash = url.lastIndexOf("/");
            String base = url.substring(0, lastSlash);
            // Check if what's after the last slash looks like a database name
            String afterSlash = url.substring(lastSlash + 1);
            if (!afterSlash.isEmpty() && !afterSlash.contains(":") && !afterSlash.contains("?")) {
                return base;
            }
        }
        return url;
    }
    
    // Method to get just the database name from the URL
    public String getDbNameFromUrl() {
        String url = props.getProperty("DB_URL", "");
        if (url.contains("/")) {
            int lastSlash = url.lastIndexOf("/");
            String dbName = url.substring(lastSlash + 1);
            // Only return if it looks like a database name (not connection parameters)
            if (!dbName.isEmpty() && !dbName.contains(":") && !dbName.contains("?")) {
                return dbName;
            }
        }
        return "";
    }
    
    private void setDefaultProperties() {
        // Set default database properties
        props.setProperty("DB_URL", "jdbc:mysql://localhost:3306/event_management");
        props.setProperty("DB_USER", "root");
        props.setProperty("DB_PASS", "");
        props.setProperty("DB_NAME", "event_management");
        
        // Set default Twilio properties
        props.setProperty("ACCOUNT_SID", "");
        props.setProperty("AUTH_TOKEN", "");
        props.setProperty("TWILIO_NUMBER", "");
        
        // Set default Email properties
        props.setProperty("EMAIL_USER", "");
        props.setProperty("EMAIL_APP_PASSWORD", "");
        props.setProperty("EMAIL_HOST", "smtp.gmail.com");
        
        // Save defaults
        save();
    }
}