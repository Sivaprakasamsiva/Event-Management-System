package Config;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Connectors.*;

public class ConfigEditor extends JFrame {
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ConfigEditor::new);
        
    }
    
    private ConfigManager config;
    private JTextField dbUrlField, dbUserField, dbPassField;
    private JTextField sidField, tokenField, twilioField;
    private JTextField emailUserField, emailPassField, emailHostField;
    
    // Admin Details Fields
    private JTextField adminFirstNameField, adminLastNameField, adminMobileField, adminEmailField, adminPasswordField;
    
    // Database Creation Fields
    private JTextField databaseNameField;

    public ConfigEditor() {
        super("Configuration Settings");
        config = new ConfigManager();
        
        initializeUI();
        setupWindow();
        setVisible(true);
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 650);
        setLocationRelativeTo(null);
        
        // Main panel with styling
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("Configuration Settings", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form panel with tabs for better organization
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Database", createDatabasePanel());
        tabbedPane.addTab("Twilio", createTwilioPanel());
        tabbedPane.addTab("Email", createEmailPanel());
        tabbedPane.addTab("Admin Details", createAdminDetailsPanel());
        tabbedPane.addTab("Database Creation", createDatabaseCreationPanel());
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createDatabasePanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        dbUrlField = createTextField(config.get("DB_URL"));
        dbUserField = createTextField(config.get("DB_USER"));
        dbPassField = createTextField(config.get("DB_PASS"));
        

        addLabelAndField(panel, gbc, "Database URL:", dbUrlField, 0);
        addLabelAndField(panel, gbc, "Database User:", dbUserField, 1);
        addLabelAndField(panel, gbc, "Database Password:", dbPassField, 2);

        return panel;
    }

    private JPanel createTwilioPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        sidField = createTextField(config.get("ACCOUNT_SID"));
        tokenField = createTextField(config.get("AUTH_TOKEN"));
        
        twilioField = createTextField(config.get("TWILIO_NUMBER"));

        addLabelAndField(panel, gbc, "Twilio Account SID:", sidField, 0);
        addLabelAndField(panel, gbc, "Twilio Auth Token:", tokenField, 1);
        addLabelAndField(panel, gbc, "Twilio Phone Number:", twilioField, 2);

        return panel;
    }

    private JPanel createEmailPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        emailUserField = createTextField(config.get("EMAIL_USER"));
        emailPassField = createTextField(config.get("EMAIL_APP_PASSWORD"));
       
        emailHostField = createTextField(config.get("EMAIL_HOST"));

        addLabelAndField(panel, gbc, "Email Username:", emailUserField, 0);
        addLabelAndField(panel, gbc, "Email App Password:", emailPassField, 1);
        addLabelAndField(panel, gbc, "Email Host:", emailHostField, 2);

        return panel;
    }

    private JPanel createAdminDetailsPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        // Initialize admin fields
        adminFirstNameField = createTextField("Monkey D");
        adminLastNameField = createTextField("Luffy");
        adminMobileField = createTextField("1234567890");
        adminEmailField = createTextField("luffy@strawhat.com");
        adminPasswordField = createTextField("password");

        addLabelAndField(panel, gbc, "First Name:", adminFirstNameField, 0);
        addLabelAndField(panel, gbc, "Last Name:", adminLastNameField, 1);
        addLabelAndField(panel, gbc, "Mobile:", adminMobileField, 2);
        addLabelAndField(panel, gbc, "Email:", adminEmailField, 3);
        addLabelAndField(panel, gbc, "Password:", adminPasswordField, 4);

        // Admin table structure info
        JTextArea tableInfo = new JTextArea();
        tableInfo.setEditable(false);
        tableInfo.setFont(new Font("Monospaced", Font.PLAIN, 12));
        tableInfo.setBackground(new Color(250, 250, 250));
        tableInfo.setText(
            "admins Table Structure:\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "| Field      | Type         | Null | Key | Default           | Extra             |\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "| admin_id   | int          | NO   | PRI | NULL              | auto_increment    |\n" +
            "| firstname  | varchar(50)  | NO   |     | NULL              |                   |\n" +
            "| lastname   | varchar(50)  | NO   |     | NULL              |                   |\n" +
            "| mobile     | varchar(15)  | NO   | UNI | NULL              |                   |\n" +
            "| email      | varchar(100) | NO   | UNI | NULL              |                   |\n" +
            "| password   | varchar(255) | NO   |     | NULL              |                   |\n" +
            "| created_at | timestamp    | YES   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED |\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "7 rows in set (0.00 sec)"
        );

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        panel.add(new JScrollPane(tableInfo), gbc);

        return panel;
    }

    private JPanel createDatabaseCreationPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new BorderLayout(10, 10));

        // Top panel for database name input
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(Color.WHITE);
        
        JLabel dbNameLabel = new JLabel("Database Name:");
        dbNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        databaseNameField = createTextField(config.get("DB_NAME"));
        databaseNameField.setPreferredSize(new Dimension(200, 35));
        
        topPanel.add(dbNameLabel);
        topPanel.add(databaseNameField);
        
        panel.add(topPanel, BorderLayout.NORTH);

        // Center panel for schema display
        JTextArea schemaArea = new JTextArea();
        schemaArea.setEditable(false);
        schemaArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        schemaArea.setBackground(new Color(250, 250, 250));
        schemaArea.setBorder(BorderFactory.createTitledBorder("Database Schema Information"));
        
        JScrollPane scrollPane = new JScrollPane(schemaArea);
        scrollPane.setPreferredSize(new Dimension(650, 350));
        panel.add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton viewSchemaBtn = createStyledButton("View Schema", new Color(70, 130, 180));
        JButton createTablesBtn = createStyledButton("Create Tables", new Color(60, 179, 113));
        JButton insertDataBtn = createStyledButton("Insert Values", new Color(218, 165, 32));

        viewSchemaBtn.addActionListener(e -> viewDatabaseSchema(schemaArea));
        createTablesBtn.addActionListener(e -> createTables());
        insertDataBtn.addActionListener(e -> insertSampleData());

        buttonPanel.add(viewSchemaBtn);
        buttonPanel.add(createTablesBtn);
        buttonPanel.add(insertDataBtn);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(245, 245, 245));

        JButton saveBtn = createStyledButton("Save", new Color(70, 130, 180));
        JButton cancelBtn = createStyledButton("Cancel", new Color(120, 120, 120));
        JButton testBtn = createStyledButton("Test Connections", new Color(60, 179, 113));

        saveBtn.addActionListener(e -> saveConfig());
        cancelBtn.addActionListener(e -> dispose());
        testBtn.addActionListener(e -> testConnections());

        buttonPanel.add(testBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        return buttonPanel;
    }

    private void addLabelAndField(JPanel panel, GridBagConstraints gbc, String labelText, JTextField field, int gridy) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 0;
        gbc.gridy = gridy;
        gbc.anchor = GridBagConstraints.LINE_END;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weighty = 0.0;
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(field, gbc);
    }

    private JPanel createStyledPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        return panel;
    }

    private GridBagConstraints createGBC() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        return gbc;
    }

    private JTextField createTextField(String text) {
        JTextField field = new JTextField(text, 20);
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(250, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(160, 35));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }

    private void setupWindow() {
        // Add window listener for confirmation on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (hasUnsavedChanges()) {
                    int result = JOptionPane.showConfirmDialog(
                        ConfigEditor.this,
                        "You have unsaved changes. Are you sure you want to close?",
                        "Unsaved Changes",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (result == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                dispose();
            }
        });
    }

    private boolean hasUnsavedChanges() {
        // Check if any field has been modified from original config values
        return !dbUrlField.getText().equals(config.get("DB_URL")) ||
               !dbUserField.getText().equals(config.get("DB_USER")) ||
               !dbPassField.getText().equals(config.get("DB_PASS")) ||
               !sidField.getText().equals(config.get("ACCOUNT_SID")) ||
               !tokenField.getText().equals(config.get("AUTH_TOKEN")) ||
               !twilioField.getText().equals(config.get("TWILIO_NUMBER")) ||
               !emailUserField.getText().equals(config.get("EMAIL_USER")) ||
               !emailPassField.getText().equals(config.get("EMAIL_APP_PASSWORD")) ||
               !emailHostField.getText().equals(config.get("EMAIL_HOST")) ||
               !databaseNameField.getText().equals(config.get("DB_NAME"));
    }

    private void saveConfig() {
        try {
            config.set("DB_URL", dbUrlField.getText().trim());
            config.set("DB_USER", dbUserField.getText().trim());
            config.set("DB_PASS", dbPassField.getText().trim());

            config.set("ACCOUNT_SID", sidField.getText().trim());
            config.set("AUTH_TOKEN", tokenField.getText().trim());
            config.set("TWILIO_NUMBER", twilioField.getText().trim());

            config.set("EMAIL_USER", emailUserField.getText().trim());
            config.set("EMAIL_APP_PASSWORD", emailPassField.getText().trim());
            config.set("EMAIL_HOST", emailHostField.getText().trim());

            // Save database name to config
            config.set("DB_NAME", databaseNameField.getText().trim());

            config.save();
            
            JOptionPane.showMessageDialog(this, 
                "Configuration saved successfully!\nPlease restart the application for changes to take effect.",
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saving configuration: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void testConnections() {
        // Simple connection testing simulation
        StringBuilder result = new StringBuilder();
        result.append("Connection Test Results:\n\n");
        
        // Test database connection
        if (dbUrlField.getText().trim().isEmpty() || dbUserField.getText().trim().isEmpty()) {
            result.append("❌ Database: Missing URL or username\n");
        } else {
            result.append("✅ Database: Configuration looks valid\n");
        }
        
        // Test Twilio configuration
        if (sidField.getText().trim().isEmpty() || tokenField.getText().trim().isEmpty()) {
            result.append("❌ Twilio: Missing SID or Token\n");
        } else {
            result.append("✅ Twilio: Configuration looks valid\n");
        }
        
        // Test Email configuration
        if (emailUserField.getText().trim().isEmpty() || emailPassField.getText().trim().isEmpty()) {
            result.append("❌ Email: Missing username or password\n");
        } else {
            result.append("✅ Email: Configuration looks valid\n");
        }
        
        result.append("\nNote: This is a basic configuration check.\nActual connectivity testing would require network access.");
        
        JOptionPane.showMessageDialog(this,
            result.toString(),
            "Connection Test Results",
            JOptionPane.INFORMATION_MESSAGE);
    }

    // Database Management Methods
    private Connection getConnection() throws SQLException {
        String baseUrl = dbUrlField.getText().trim();
        String user = dbUserField.getText().trim();
        String password = dbPassField.getText().trim();
        String dbName = databaseNameField.getText().trim();
        
        // Extract base URL without database name and append the specific database
        String url;
        if (baseUrl.contains("/")) {
            int lastSlash = baseUrl.lastIndexOf("/");
            String baseWithoutDB = baseUrl.substring(0, lastSlash + 1);
            url = baseWithoutDB + dbName;
        } else {
            url = baseUrl + "/" + dbName;
        }
        
        return DriverManager.getConnection(url, user, password);
    }

    private Connection getConnectionWithoutDB() throws SQLException {
        String baseUrl = dbUrlField.getText().trim();
        String user = dbUserField.getText().trim();
        String password = dbPassField.getText().trim();
        
        // Get connection without specific database
        String url;
        if (baseUrl.contains("/")) {
            int lastSlash = baseUrl.lastIndexOf("/");
            url = baseUrl.substring(0, lastSlash);
        } else {
            url = baseUrl;
        }
        
        return DriverManager.getConnection(url, user, password);
    }

    private void createDatabaseIfNotExists() {
        try (Connection conn = getConnectionWithoutDB(); Statement stmt = conn.createStatement()) {
            String dbName = databaseNameField.getText().trim();
            stmt.execute("CREATE DATABASE IF NOT EXISTS " + dbName);
            System.out.println("Database created or already exists: " + dbName);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error creating database: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewDatabaseSchema(JTextArea schemaArea) {
        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection()) {
                DatabaseMetaData metaData = conn.getMetaData();
                String dbName = databaseNameField.getText().trim();
                
                // Get all tables from the specific database only
                ResultSet tables = metaData.getTables(dbName, null, "%", new String[]{"TABLE"});
                StringBuilder schemaInfo = new StringBuilder();
                schemaInfo.append("DATABASE: " + dbName + "\n");
                schemaInfo.append("TABLES:\n");
                schemaInfo.append("+-----------------------+\n");
                schemaInfo.append("| Tables                |\n");
                schemaInfo.append("+-----------------------+\n");
                
                List<String> tableNames = new ArrayList<>();
                while (tables.next()) {
                    String tableName = tables.getString("TABLE_NAME");
                    tableNames.add(tableName);
                    schemaInfo.append(String.format("| %-21s |\n", tableName));
                }
                schemaInfo.append("+-----------------------+\n");
                schemaInfo.append(tableNames.size() + " rows in set\n\n");
                
                if (tableNames.isEmpty()) {
                    schemaInfo.append("No tables found in database '" + dbName + "'. Click 'Create Tables' to create the tables.\n");
                } else {
                    // Get schema for each table from the specific database
                    for (String tableName : tableNames) {
                        schemaInfo.append("mysql> desc " + tableName + ";\n");
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        schemaInfo.append("| Field                    | Type                                                  | Null | Key | Default           | Extra             |\n");
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        
                        ResultSet columns = metaData.getColumns(dbName, null, tableName, null);
                        while (columns.next()) {
                            String field = columns.getString("COLUMN_NAME");
                            String type = columns.getString("TYPE_NAME");
                            int size = columns.getInt("COLUMN_SIZE");
                            String typeWithSize = type + (size > 0 ? "(" + size + ")" : "");
                            String nullable = columns.getString("IS_NULLABLE").equals("YES") ? "YES" : "NO";
                            String key = "";
                            String defaultValue = columns.getString("COLUMN_DEF") != null ? columns.getString("COLUMN_DEF") : "NULL";
                            String extra = "";
                            
                            // Get primary key information from the specific database
                            ResultSet primaryKeys = metaData.getPrimaryKeys(dbName, null, tableName);
                            while (primaryKeys.next()) {
                                if (primaryKeys.getString("COLUMN_NAME").equals(field)) {
                                    key = "PRI";
                                    break;
                                }
                            }
                            primaryKeys.close();
                            
                            schemaInfo.append(String.format("| %-24s | %-53s | %-4s | %-3s | %-17s | %-17s |\n", 
                                field, typeWithSize, nullable, key, defaultValue, extra));
                        }
                        columns.close();
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        schemaInfo.append("\n");
                    }
                }
                
                schemaArea.setText(schemaInfo.toString());
                
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error viewing database schema: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createTables() {
        String dbName = databaseNameField.getText().trim();
        int confirm = JOptionPane.showConfirmDialog(this,
            "This will create all database tables in database: " + dbName + ". Continue?",
            "Create Tables",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
                
                // Create tables SQL (same as before)
                String[] createTableSQLs = {
                    // admins table
                    "CREATE TABLE IF NOT EXISTS admins (" +
                    "admin_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "mobile VARCHAR(15) NOT NULL UNIQUE, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // organizers table
                    "CREATE TABLE IF NOT EXISTS organizers (" +
                    "organizer_id VARCHAR(10) PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "mobile VARCHAR(15) NOT NULL UNIQUE, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "company_name VARCHAR(100), " +
                    "address TEXT, " +
                    "verified TINYINT(1) DEFAULT 0, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // members table
                    "CREATE TABLE IF NOT EXISTS members (" +
                    "member_id VARCHAR(10) PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "dob DATE, " +
                    "gender ENUM('Male','Female','Other'), " +
                    "password VARCHAR(255) NOT NULL, " +
                    "address TEXT, " +
                    "mobile VARCHAR(15), " +
                    "email VARCHAR(100), " +
                    "active TINYINT(1) DEFAULT 1, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // events table
                    "CREATE TABLE IF NOT EXISTS events (" +
                    "event_id VARCHAR(10) PRIMARY KEY, " +
                    "title VARCHAR(100) NOT NULL, " +
                    "description TEXT, " +
                    "venue VARCHAR(100) NOT NULL, " +
                    "price DECIMAL(10,2) DEFAULT 0.00, " +
                    "capacity INT NOT NULL, " +
                    "available_tickets INT NOT NULL, " +
                    "category VARCHAR(50), " +
                    "organizer_id VARCHAR(10) NOT NULL, " +
                    "event_date DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                    "tickets_sold INT DEFAULT 0, " +
                    "revenue DECIMAL(10,2) DEFAULT 0.00, " +
                    "status ENUM('Pending','Approved','Rejected','Cancelled') DEFAULT 'Pending', " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "break_even_tickets INT DEFAULT 0, " +
                    "start_date DATETIME NOT NULL, " +
                    "end_date DATETIME NOT NULL, " +
                    "event_code VARCHAR(10) UNIQUE NOT NULL)",

                    // bookings table
                    "CREATE TABLE IF NOT EXISTS bookings (" +
                    "booking_id VARCHAR(10) PRIMARY KEY, " +
                    "event_id VARCHAR(10) NOT NULL, " +
                    "user_id VARCHAR(10), " +
                    "ticket_count INT NOT NULL, " +
                    "total_amount DECIMAL(10,2) NOT NULL, " +
                    "status ENUM('Confirmed','Pending','Cancelled','Refunded') DEFAULT 'Confirmed', " +
                    "booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "event_code VARCHAR(10))",

                    // payments table
                    "CREATE TABLE IF NOT EXISTS payments (" +
                    "payment_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "booking_id VARCHAR(10) NOT NULL, " +
                    "amount DECIMAL(10,2) NOT NULL, " +
                    "total_amount DECIMAL(10,2) NOT NULL, " +
                    "payment_method VARCHAR(50) NOT NULL, " +
                    "payment_status ENUM('Success','Failed','Pending') DEFAULT 'Pending', " +
                    "transaction_id VARCHAR(100), " +
                    "payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // chat_rooms table
                    "CREATE TABLE IF NOT EXISTS chat_rooms (" +
                    "room_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "room_type ENUM('ADMIN_ORGANIZER','ORGANIZER_CUSTOMER','ADMIN_CUSTOMER') NOT NULL, " +
                    "organizer_id VARCHAR(10), " +
                    "customer_id VARCHAR(10), " +
                    "admin_id INT DEFAULT 1, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // messages table
                    "CREATE TABLE IF NOT EXISTS messages (" +
                    "message_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "room_id INT NOT NULL, " +
                    "sender_type ENUM('ADMIN','ORGANIZER','CUSTOMER') NOT NULL, " +
                    "sender_id VARCHAR(50) NOT NULL, " +
                    "message_text TEXT NOT NULL, " +
                    "message_type ENUM('TEXT','IMAGE','FILE') DEFAULT 'TEXT', " +
                    "is_read TINYINT(1) DEFAULT 0, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // id_sequences table
                    "CREATE TABLE IF NOT EXISTS id_sequences (" +
                    "sequence_name VARCHAR(50) PRIMARY KEY, " +
                    "next_value INT DEFAULT 1, " +
                    "prefix VARCHAR(10) NOT NULL, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // systemsettings table
                    "CREATE TABLE IF NOT EXISTS systemsettings (" +
                    "id INT PRIMARY KEY DEFAULT 1, " +
                    "system_name VARCHAR(100) DEFAULT 'Event Management System', " +
                    "commission_rate DECIMAL(5,2) DEFAULT 0.00, " +
                    "auto_approve_events TINYINT(1) DEFAULT 0, " +
                    "max_events_per_organizer INT DEFAULT 10)",

                    // booking_payments_view view
                    "CREATE OR REPLACE VIEW booking_payments_view AS " +
                    "SELECT b.booking_id, b.event_id, b.user_id, b.ticket_count, b.total_amount, " +
                    "b.status as booking_status, p.payment_status, p.transaction_id, b.booking_date " +
                    "FROM bookings b LEFT JOIN payments p ON b.booking_id = p.booking_id"
                };

                for (String sql : createTableSQLs) {
                    stmt.execute(sql);
                }

                JOptionPane.showMessageDialog(this,
                    "All tables created successfully in database: " + dbName,
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error creating tables: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertSampleData() {
        String dbName = databaseNameField.getText().trim();
        int confirm = JOptionPane.showConfirmDialog(this,
            "This will insert sample data with admin details from Admin Details tab, Naruto members, One Piece organizers, and 50 events into database: " + dbName + ". Continue?",
            "Insert Sample Data",
            JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

                // Admin
                String adminFirstName = adminFirstNameField.getText().trim();
                String adminLastName = adminLastNameField.getText().trim();
                String adminMobile = adminMobileField.getText().trim();
                String adminEmail = adminEmailField.getText().trim();
                String adminPassword = adminPasswordField.getText().trim();

                stmt.execute("INSERT IGNORE INTO admins (firstname, lastname, mobile, email, password) VALUES " +
                    "('" + adminFirstName + "', '" + adminLastName + "', '" + adminMobile + "', '" + adminEmail + "', '" + adminPassword + "')");

                // System defaults
                stmt.execute("INSERT IGNORE INTO systemsettings (id) VALUES (1)");

                // ID sequences aligned to new formats
                stmt.execute("DELETE FROM id_sequences");
                stmt.execute("INSERT INTO id_sequences (sequence_name, prefix, next_value) VALUES " +
                    "('organizer', 'ORG', 1), " +
                    "('member', 'CUST', 1), " +
                    "('event', 'EVNT', 1), " +
                    "('booking', 'BOOK', 1)");

                // --- Organizers (One Piece Crew) ---
                String[][] organizers = {
                    {"ORG001", "Monkey D", "Luffy", "9000000001", "luffy@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG002", "Roronoa", "Zoro", "9000000002", "zoro@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG003", "Nami", "", "9000000003", "nami@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG004", "Sanji", "Vinsmoke", "9000000004", "sanji@baratie.com", "password", "Baratie Events", "North Blue", "1"},
                    {"ORG005", "Tony Tony", "Chopper", "9000000005", "chopper@drum.com", "password", "Medical Expo", "Drum Island", "1"},
                    {"ORG006", "Nico", "Robin", "9000000006", "robin@ohara.com", "password", "History Foundation", "Ohara", "1"},
                    {"ORG007", "Franky", "", "9000000007", "franky@sunny.com", "password", "Franky Works", "Water 7", "1"},
                    {"ORG008", "Brook", "", "9000000008", "brook@soulking.com", "password", "Soul Music", "West Blue", "1"},
                    {"ORG009", "Shanks", "", "9000000009", "shanks@redhair.com", "password", "Red Hair Pirates", "Grand Line", "1"},
                    {"ORG010", "Marshall D", "Teach", "9000000010", "teach@blackbeard.com", "password", "Blackbeard Pirates", "Grand Line", "0"}
                };

                for (String[] o : organizers) {
                    stmt.execute(String.format(
                        "INSERT IGNORE INTO organizers (organizer_id, firstname, lastname, mobile, email, password, company_name, address, verified) " +
                        "VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',%s)",
                        o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7], o[8]
                    ));
                }

                // --- Members (Naruto characters as customers) ---
                String[][] members = {
                    {"CUST001", "Naruto", "Uzumaki", "naruto", "2000-10-10", "Male", "password", "Hidden Leaf Village", "9100000001", "naruto@leaf.com"},
                    {"CUST002", "Sasuke", "Uchiha", "sasuke", "2000-07-23", "Male", "password", "Hidden Leaf Village", "9100000002", "sasuke@uchiha.com"},
                    {"CUST003", "Sakura", "Haruno", "sakura", "2000-03-28", "Female", "password", "Hidden Leaf Village", "9100000003", "sakura@leaf.com"},
                    {"CUST004", "Kakashi", "Hatake", "kakashi", "1985-09-15", "Male", "password", "Hidden Leaf Village", "9100000004", "kakashi@leaf.com"},
                    {"CUST005", "Hinata", "Hyuga", "hinata", "2000-12-27", "Female", "password", "Hidden Leaf Village", "9100000005", "hinata@leaf.com"},
                    {"CUST006", "Gaara", "", "gaara", "2000-01-19", "Male", "password", "Hidden Sand Village", "9100000006", "gaara@sand.com"},
                    {"CUST007", "Rock", "Lee", "rocklee", "2000-11-27", "Male", "password", "Hidden Leaf Village", "9100000007", "rocklee@leaf.com"},
                    {"CUST008", "Shikamaru", "Nara", "shikamaru", "2000-09-22", "Male", "password", "Hidden Leaf Village", "9100000008", "shikamaru@leaf.com"},
                    {"CUST009", "Ino", "Yamanaka", "ino", "2000-09-23", "Female", "password", "Hidden Leaf Village", "9100000009", "ino@leaf.com"},
                    {"CUST010", "Neji", "Hyuga", "neji", "2000-07-03", "Male", "password", "Hidden Leaf Village", "9100000010", "neji@leaf.com"}
                };

                for (String[] m : members) {
                    stmt.execute(String.format(
                        "INSERT IGNORE INTO members (member_id, firstname, lastname, username, dob, gender, password, address, mobile, email) " +
                        "VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                        m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9]
                    ));
                }

                // --- Optional Events ---
                for (int i = 1; i <= 10; i++) {
                    String eventId = String.format("EVNT%03d", i);
                    String organizerId = String.format("ORG%03d", (i % 10) + 1);
                    stmt.execute(String.format(
                        "INSERT IGNORE INTO events (event_id, title, description, venue, price, capacity, available_tickets, category, organizer_id, start_date, end_date, event_code) " +
                        "VALUES ('%s','Festival %d','Annual Celebration %d','Hidden Leaf Arena', 150.00, 200, 200, 'Festival', '%s', NOW(), DATE_ADD(NOW(), INTERVAL 2 DAY), 'CODE%d')",
                        eventId, i, i, organizerId, i
                    ));
                }

                JOptionPane.showMessageDialog(this,
                    "✅ Sample data inserted successfully!\nOrganizers (One Piece), Members (Naruto), Events generated.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "❌ Error inserting sample data: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

}