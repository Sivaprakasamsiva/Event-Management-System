package Chat;



import javax.swing.*;
import java.awt.*;

public class AdminChat extends RealTimeChatFrame {
    
    public AdminChat() {
        super("Admin Chat", "1", "ADMIN");
    }
    
    @Override
    protected Color getUserColor() {
        return ADMIN_COLOR;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminChat());
        
    }
}