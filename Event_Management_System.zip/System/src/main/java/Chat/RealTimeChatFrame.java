package Chat;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public abstract class RealTimeChatFrame extends JFrame {
    protected ChatService chatService;
    protected ScheduledExecutorService scheduler;
    protected ScheduledFuture<?> refreshTask;
    
    protected String currentUserId;
    protected String currentUserType;
    protected int currentRoomId = -1;
    protected String currentChatName = "";
    
    protected JList<String> chatList;
    protected DefaultListModel<String> chatListModel;
    protected JPanel messagesPanel;
    protected JTextField messageField;
    protected JButton sendButton;
    protected JLabel statusLabel;
    protected JLabel notificationLabel;
    
    // Track the mapping between list indices and actual chat data
    protected List<Map<String, String>> availableChats;
    protected List<Integer> chatListToDataMapping;
    
    // Track last message count for notifications
    private int lastMessageCount = 0;
    
    // Role colors with better styling
    protected static final Color ADMIN_COLOR = new Color(65, 105, 225);    // Royal Blue
    protected static final Color ORGANIZER_COLOR = new Color(102, 51, 153); // Purple
    protected static final Color CUSTOMER_COLOR = new Color(40, 167, 69);   // Green

    public RealTimeChatFrame(String title, String userId, String userType) {
        super(title);
        this.currentUserId = userId;
        this.currentUserType = userType;
        this.chatService = new ChatService();
        this.availableChats = new ArrayList<>();
        this.chatListToDataMapping = new ArrayList<>();
        
        setupUI();
        startAutoRefresh();
        loadAvailableChats();
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopAutoRefresh();
            }
        });
        
        setVisible(true);
    }

    private void setupUI() {
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(248, 249, 250));
        
        // Header with notifications
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Split pane for chat list and messages
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(300);
        splitPane.setLeftComponent(createChatListPanel());
        splitPane.setRightComponent(createChatArea());
        splitPane.setBorder(BorderFactory.createEmptyBorder());
        mainPanel.add(splitPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(getUserColor());
        header.setPreferredSize(new Dimension(1000, 70));
        header.setBorder(new CompoundBorder(
            new LineBorder(getUserColor().darker(), 1),
            new EmptyBorder(15, 20, 15, 20)
        ));

        // Title with icon
        JLabel titleLabel = new JLabel(getWindowTitle(), SwingConstants.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        header.add(titleLabel, BorderLayout.WEST);

        // Status with better styling
        statusLabel = new JLabel("> Select a chat to start messaging");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        statusLabel.setForeground(Color.YELLOW);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setBorder(new EmptyBorder(0, 10, 0, 10));
        header.add(statusLabel, BorderLayout.CENTER);

        // Notification badge with better styling
        notificationLabel = createNotificationBadge(0);
        JPanel notifPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        notifPanel.setOpaque(false);
        notifPanel.add(notificationLabel);
        header.add(notifPanel, BorderLayout.EAST);

        return header;
    }

    private String getWindowTitle() {
        switch(currentUserType) {
            case "ADMIN": return "Admin Chat Console";
            case "ORGANIZER": return "Organizer Chat";
            case "CUSTOMER": return "Customer Support";
            default: return "Chat";
        }
    }

    private JPanel createChatListPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new CompoundBorder(
            new TitledBorder(
                new LineBorder(new Color(200, 200, 200), 1),
                "Available Chats",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                getUserColor()
            ),
            new EmptyBorder(5, 5, 5, 5)
        ));
        panel.setBackground(Color.WHITE);
        
        chatListModel = new DefaultListModel<>();
        chatList = new JList<>(chatListModel);
        chatList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        chatList.setFont(new Font("Arial", Font.PLAIN, 13));
        chatList.setCellRenderer(new ChatListCellRenderer());
        chatList.setBackground(new Color(250, 250, 250));
        chatList.setBorder(new EmptyBorder(5, 5, 5, 5));
        chatList.setFixedCellHeight(50);
        
        chatList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                handleChatSelection();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(chatList);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }

    // Enhanced custom cell renderer for chat list
    private class ChatListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                                                     int index, boolean isSelected, boolean cellHasFocus) {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(new EmptyBorder(8, 10, 8, 10));
            
            if (isSelected) {
                panel.setBackground(getUserColor().brighter());
                panel.setBorder(new CompoundBorder(
                    new LineBorder(getUserColor(), 2),
                    new EmptyBorder(7, 9, 7, 9)
                ));
            } else {
                panel.setBackground(index % 2 == 0 ? new Color(250, 250, 250) : Color.WHITE);
            }
            
            String text = value.toString();
            JLabel label = new JLabel(text);
            label.setFont(new Font("Arial", Font.PLAIN, 13));
            
            // Style based on content
            if (text.contains("(new)")) {
                label.setFont(new Font("Arial", Font.BOLD, 13));
                label.setForeground(Color.RED);
            } else if (text.contains("ORGANIZERS") || text.contains("CUSTOMERS") || text.contains("ADMINS")) {
                label.setFont(new Font("Arial", Font.BOLD, 12));
                label.setForeground(getUserColor().darker());
                panel.setBackground(new Color(240, 240, 240));
            } else if (text.contains("No ") || text.contains("No chats")) {
                label.setFont(new Font("Arial", Font.ITALIC, 12));
                label.setForeground(Color.GRAY);
                label.setHorizontalAlignment(SwingConstants.CENTER);
            } else {
                label.setForeground(Color.BLACK);
            }
            
            panel.add(label, BorderLayout.CENTER);
            
            return panel;
        }
    }

    private JPanel createChatArea() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new CompoundBorder(
            new TitledBorder(
                new LineBorder(new Color(200, 200, 200), 1),
                "Chat Messages",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                getUserColor()
            ),
            new EmptyBorder(5, 5, 5, 5)
        ));
        panel.setBackground(Color.WHITE);
        
        // Messages area with better styling
        messagesPanel = new JPanel();
        messagesPanel.setLayout(new BoxLayout(messagesPanel, BoxLayout.Y_AXIS));
        messagesPanel.setBackground(new Color(248, 249, 250));
        messagesPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(messagesPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(new Color(248, 249, 250));
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Input area with better styling
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 220), 1),
            new EmptyBorder(15, 15, 15, 15)
        ));
        inputPanel.setBackground(Color.WHITE);
        
        messageField = new JTextField();
        messageField.setFont(new Font("Arial", Font.PLAIN, 14));
        messageField.setBorder(new CompoundBorder(
            new LineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(12, 15, 12, 15)
        ));
        messageField.addActionListener(e -> sendMessage());
        messageField.setEnabled(false);
        
        sendButton = new JButton("Send");
        sendButton.setBackground(getUserColor());
        sendButton.setForeground(Color.WHITE);
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));
        sendButton.setBorder(new CompoundBorder(
            new LineBorder(getUserColor().darker(), 1),
            new EmptyBorder(10, 20, 10, 20)
        ));
        sendButton.setFocusPainted(false);
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendButton.addActionListener(e -> sendMessage());
        sendButton.setEnabled(false);
        
        // Add hover effects to send button
        sendButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (sendButton.isEnabled()) {
                    sendButton.setBackground(getUserColor().brighter());
                }
            }
            public void mouseExited(MouseEvent e) {
                if (sendButton.isEnabled()) {
                    sendButton.setBackground(getUserColor());
                }
            }
        });
        
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        panel.add(inputPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private JLabel createNotificationBadge(int count) {
        JLabel badge = new JLabel(count > 0 ? String.valueOf(count) : "");
        badge.setOpaque(true);
        badge.setBackground(Color.RED);
        badge.setForeground(Color.WHITE);
        badge.setFont(new Font("Arial", Font.BOLD, 12));
        badge.setBorder(new CompoundBorder(
            new LineBorder(Color.WHITE, 2),
            new EmptyBorder(4, 8, 4, 8)
        ));
        badge.setVisible(count > 0);
        return badge;
    }

    private void startAutoRefresh() {
        scheduler = Executors.newScheduledThreadPool(1);
        refreshTask = scheduler.scheduleAtFixedRate(() -> {
            SwingUtilities.invokeLater(() -> {
                refreshChat();
                updateNotifications();
                checkForNewMessages();
            });
        }, 0, 3, TimeUnit.SECONDS);
    }

    private void stopAutoRefresh() {
        if (refreshTask != null) {
            refreshTask.cancel(false);
        }
        if (scheduler != null) {
            scheduler.shutdown();
        }
    }

    protected void loadAvailableChats() {
        chatListModel.clear();
        chatListToDataMapping.clear();
        availableChats = chatService.getAvailableChats(currentUserId, currentUserType);
        
        if (availableChats.isEmpty()) {
            chatListModel.addElement("No active chats available");
            return;
        }
        
        // Organize chats by type
        List<Map<String, String>> organizers = new ArrayList<>();
        List<Map<String, String>> customers = new ArrayList<>();
        List<Map<String, String>> admins = new ArrayList<>();
        
        for (Map<String, String> chat : availableChats) {
            String chatType = chat.get("type");
            if ("INFO".equals(chatType)) {
                // Add info messages directly
                chatListModel.addElement(chat.get("name"));
                chatListToDataMapping.add(-1); // -1 indicates info message
                continue;
            }
            
            switch(chatType) {
                case "ORGANIZER": organizers.add(chat); break;
                case "CUSTOMER": customers.add(chat); break;
                case "ADMIN": admins.add(chat); break;
            }
        }
        
        // Add organizers section
        if (!organizers.isEmpty()) {
            chatListModel.addElement("ORGANIZERS");
            chatListToDataMapping.add(-1); // -1 indicates header
            
            for (Map<String, String> chat : organizers) {
                String display = formatChatItem(chat);
                chatListModel.addElement(display);
                chatListToDataMapping.add(availableChats.indexOf(chat));
            }
        }
        
        // Add customers section
        if (!customers.isEmpty()) {
            if (!organizers.isEmpty()) {
                chatListModel.addElement(" "); // Spacer
                chatListToDataMapping.add(-1);
            }
            chatListModel.addElement("CUSTOMERS");
            chatListToDataMapping.add(-1);
            
            for (Map<String, String> chat : customers) {
                String display = formatChatItem(chat);
                chatListModel.addElement(display);
                chatListToDataMapping.add(availableChats.indexOf(chat));
            }
        }
        
        // Add admins section
        if (!admins.isEmpty()) {
            if (!organizers.isEmpty() || !customers.isEmpty()) {
                chatListModel.addElement(" "); // Spacer
                chatListToDataMapping.add(-1);
            }
            chatListModel.addElement("ADMINS");
            chatListToDataMapping.add(-1);
            
            for (Map<String, String> chat : admins) {
                String display = formatChatItem(chat);
                chatListModel.addElement(display);
                chatListToDataMapping.add(availableChats.indexOf(chat));
            }
        }
    }

    private String formatChatItem(Map<String, String> chat) {
        String display = chat.get("name");
        
        // Add unread count indicator
        int unread = Integer.parseInt(chat.getOrDefault("unread", "0"));
        if (unread > 0) {
            display = "(new) " + display + " (" + unread + ")";
        }
        
        // Add status info if available
        if (chat.get("info") != null && !chat.get("info").isEmpty()) {
            display += " - " + chat.get("info");
        }
        
        return display;
    }

    protected void handleChatSelection() {
        int selectedIndex = chatList.getSelectedIndex();
        if (selectedIndex == -1 || selectedIndex >= chatListToDataMapping.size()) return;
        
        int dataIndex = chatListToDataMapping.get(selectedIndex);
        
        // Skip headers, spacers, and info messages
        if (dataIndex == -1) {
            chatList.clearSelection();
            return;
        }
        
        if (dataIndex < 0 || dataIndex >= availableChats.size()) {
            chatList.clearSelection();
            return;
        }
        
        Map<String, String> selectedChat = availableChats.get(dataIndex);
        String chatType = selectedChat.get("type");
        
        // Skip info messages
        if ("INFO".equals(chatType)) {
            chatList.clearSelection();
            return;
        }
        
        String targetId = selectedChat.get("id");
        currentChatName = selectedChat.get("name");
        
        String roomType = determineRoomType(chatType);
        String organizerId = null;
        String customerId = null;
        
        switch (currentUserType) {
            case "ADMIN":
                if ("ORGANIZER".equals(chatType)) {
                    organizerId = targetId;
                } else if ("CUSTOMER".equals(chatType)) {
                    customerId = targetId;
                }
                break;
            case "ORGANIZER":
                if ("CUSTOMER".equals(chatType)) {
                    organizerId = currentUserId;
                    customerId = targetId;
                } else if ("ADMIN".equals(chatType)) {
                    organizerId = currentUserId;
                }
                break;
            case "CUSTOMER":
                if ("ORGANIZER".equals(chatType)) {
                    organizerId = targetId;
                    customerId = currentUserId;
                } else if ("ADMIN".equals(chatType)) {
                    customerId = currentUserId;
                }
                break;
        }
        
        currentRoomId = chatService.getOrCreateRoom(roomType, organizerId, customerId);
        
        // Validate room access
        if (!chatService.canAccessRoom(currentRoomId, currentUserId, currentUserType)) {
            JOptionPane.showMessageDialog(this, "Access denied to this chat room.", "Security Error", JOptionPane.ERROR_MESSAGE);
            chatList.clearSelection();
            currentRoomId = -1;
            return;
        }
        
        statusLabel.setText("Chatting with: " + currentChatName);
        loadMessages();
        messageField.setEnabled(true);
        sendButton.setEnabled(true);
        messageField.requestFocus();
        
        chatService.markMessagesAsRead(currentRoomId, currentUserType, currentUserId);
        lastMessageCount = chatService.getMessages(currentRoomId).size();
    }

    private String determineRoomType(String chatType) {
        switch (currentUserType) {
            case "ADMIN":
                return chatType.equals("ORGANIZER") ? "ADMIN_ORGANIZER" : "ADMIN_CUSTOMER";
            case "ORGANIZER":
                return chatType.equals("CUSTOMER") ? "ORGANIZER_CUSTOMER" : "ADMIN_ORGANIZER";
            case "CUSTOMER":
                return chatType.equals("ORGANIZER") ? "ORGANIZER_CUSTOMER" : "ADMIN_CUSTOMER";
            default:
                return "ADMIN_ORGANIZER";
        }
    }

    protected void loadMessages() {
        if (currentRoomId == -1) return;
        
        messagesPanel.removeAll();
        
        List<Message> messages = chatService.getMessages(currentRoomId);
        
        if (messages.isEmpty()) {
            JPanel emptyPanel = new JPanel(new BorderLayout());
            emptyPanel.setBackground(new Color(248, 249, 250));
            
            JLabel noMessages = new JLabel("No messages yet. Start the conversation!", SwingConstants.CENTER);
            noMessages.setFont(new Font("Arial", Font.ITALIC, 16));
            noMessages.setForeground(new Color(108, 117, 125));
            noMessages.setBorder(new EmptyBorder(50, 20, 50, 20));
            
            emptyPanel.add(noMessages, BorderLayout.CENTER);
            messagesPanel.add(emptyPanel);
        } else {
            for (Message message : messages) {
                addMessageToPanel(message);
            }
        }
        
        messagesPanel.revalidate();
        messagesPanel.repaint();
        scrollToBottom();
    }

    protected void addMessageToPanel(Message message) {
        boolean isOwnMessage = message.isSentByCurrentUser(currentUserId, currentUserType);
        
        JPanel messageWrapper = new JPanel(new BorderLayout());
        messageWrapper.setBorder(new EmptyBorder(8, 15, 8, 15));
        messageWrapper.setOpaque(false);
        
        JPanel bubble = createMessageBubble(message, isOwnMessage);
        
        if (isOwnMessage) {
            messageWrapper.add(bubble, BorderLayout.EAST);
        } else {
            messageWrapper.add(bubble, BorderLayout.WEST);
        }
        
        messagesPanel.add(messageWrapper);
        messagesPanel.add(Box.createRigidArea(new Dimension(0, 8)));
    }

    private JPanel createMessageBubble(Message message, boolean isOwnMessage) {
        JPanel bubble = new JPanel(new BorderLayout());
        
        Color bubbleColor = isOwnMessage ? getUserColor() : Color.WHITE;
        Color textColor = isOwnMessage ? Color.WHITE : Color.BLACK;
        
        bubble.setBackground(bubbleColor);
        bubble.setBorder(new CompoundBorder(
            new LineBorder(isOwnMessage ? getUserColor().darker() : new Color(200, 200, 200), 1),
            new EmptyBorder(12, 16, 12, 16)
        ));
        
        // Message text
        JTextArea textArea = new JTextArea(message.getMessageText());
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(bubbleColor);
        textArea.setForeground(textColor);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBorder(new EmptyBorder(0, 0, 5, 0));
        
        // Timestamp and sender info
        String time = new java.text.SimpleDateFormat("HH:mm").format(message.getCreatedAt());
        String info = isOwnMessage ? "You • " + time : message.getSenderName() + " • " + time;
        
        JLabel infoLabel = new JLabel(info);
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 11));
        infoLabel.setForeground(isOwnMessage ? new Color(220, 220, 220) : new Color(108, 117, 125));
        
        bubble.add(textArea, BorderLayout.CENTER);
        bubble.add(infoLabel, BorderLayout.SOUTH);
        
        // Set maximum width
        bubble.setMaximumSize(new Dimension(400, Integer.MAX_VALUE));
        
        return bubble;
    }

    private void scrollToBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollPane scrollPane = (JScrollPane) messagesPanel.getParent().getParent();
            JScrollBar vertical = scrollPane.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        });
    }

    protected void refreshChat() {
        if (currentRoomId != -1) {
            loadMessages();
        }
    }

    protected void updateNotifications() {
        int totalUnread = chatService.getTotalUnreadCount(currentUserId, currentUserType);
        
        notificationLabel.setText(totalUnread > 0 ? String.valueOf(totalUnread) : "");
        notificationLabel.setVisible(totalUnread > 0);
        
        // Update window title with notification
        String baseTitle = getWindowTitle();
        if (totalUnread > 0) {
            setTitle(baseTitle + " (" + totalUnread + " new messages)");
        } else {
            setTitle(baseTitle);
        }
    }

    protected void checkForNewMessages() {
        if (currentRoomId != -1) {
            List<Message> messages = chatService.getMessages(currentRoomId);
            int currentMessageCount = messages.size();
            
            if (currentMessageCount > lastMessageCount && !isWindowFocused()) { // FIXED: use correct method name
                Message latestMessage = messages.get(messages.size() - 1);
                if (!latestMessage.isSentByCurrentUser(currentUserId, currentUserType)) {
                    chatService.showNewMessageNotification(
                        latestMessage.getSenderName(),
                        latestMessage.getMessageText()
                    );
                }
            }
            lastMessageCount = currentMessageCount;
        }
    }
    

 // FIXED: Correct method name and implementation
    private boolean isWindowFocused() {
        return this.isActive() || (messageField != null && messageField.isFocusOwner());
    }
    
    
    protected void sendMessage() {
        String text = messageField.getText().trim();
        if (text.isEmpty() || currentRoomId == -1) return;
        
        if (chatService.sendMessage(currentRoomId, currentUserType, currentUserId, text)) {
            messageField.setText("");
            loadMessages();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to send message. Please try again.", 
                "Send Error", 
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    protected abstract Color getUserColor();
}