package Chat;

import Connectors.*;

import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatService {
    private Connection connection;

    public ChatService() {
        this.connection = DBConnection.getConnection();
    }

    /**
     * Get or create chat room automatically - FIXED VERSION
     */
    /**
     * Get or create chat room automatically - ENHANCED VERSION with debugging
     */
    public int getOrCreateRoom(String roomType, String organizerId, String customerId) {
        System.out.println("DEBUG: Creating room - Type: " + roomType + 
                          ", Organizer: " + organizerId + ", Customer: " + customerId);
        
        try {
            // First try to find existing room - SIMPLIFIED QUERY
            String findSql = "SELECT room_id FROM chat_rooms WHERE room_type = ? " +
                           "AND (organizer_id = ? OR (organizer_id IS NULL AND ? IS NULL)) " +
                           "AND (customer_id = ? OR (customer_id IS NULL AND ? IS NULL))";
            
            PreparedStatement findStmt = connection.prepareStatement(findSql);
            findStmt.setString(1, roomType);
            
            // Handle organizer_id
            if (organizerId != null && !organizerId.isEmpty()) {
                findStmt.setString(2, organizerId);
                findStmt.setString(3, organizerId);
            } else {
                findStmt.setNull(2, Types.VARCHAR);
                findStmt.setNull(3, Types.VARCHAR);
            }
            
            // Handle customer_id
            if (customerId != null && !customerId.isEmpty()) {
                findStmt.setString(4, customerId);
                findStmt.setString(5, customerId);
            } else {
                findStmt.setNull(4, Types.VARCHAR);
                findStmt.setNull(5, Types.VARCHAR);
            }
            
            ResultSet rs = findStmt.executeQuery();
            if (rs.next()) {
                int roomId = rs.getInt("room_id");
                System.out.println("DEBUG: Found existing room: " + roomId);
                return roomId;
            }
            
            // Create new room if doesn't exist
            String insertSql = "INSERT INTO chat_rooms (room_type, organizer_id, customer_id) VALUES (?, ?, ?)";
            PreparedStatement insertStmt = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
            insertStmt.setString(1, roomType);
            
            if (organizerId != null && !organizerId.isEmpty()) {
                insertStmt.setString(2, organizerId);
            } else {
                insertStmt.setNull(2, Types.VARCHAR);
            }
            
            if (customerId != null && !customerId.isEmpty()) {
                insertStmt.setString(3, customerId);
            } else {
                insertStmt.setNull(3, Types.VARCHAR);
            }
            
            int affectedRows = insertStmt.executeUpdate();
            System.out.println("DEBUG: Inserted room, affected rows: " + affectedRows);
            
            ResultSet generatedKeys = insertStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int newRoomId = generatedKeys.getInt(1);
                System.out.println("DEBUG: Created new room with ID: " + newRoomId);
                return newRoomId;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error creating chat room: " + e.getMessage());
        }
        return -1;
    }
    /**
     * Send message to room
     */
    public boolean sendMessage(int roomId, String senderType, String senderId, String messageText) {
        if (roomId == -1) {
            JOptionPane.showMessageDialog(null, "Cannot send message: Invalid chat room");
            return false;
        }
        
        String sql = "INSERT INTO messages (room_id, sender_type, sender_id, message_text) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, roomId);
            ps.setString(2, senderType);
            ps.setString(3, senderId);
            ps.setString(4, messageText);
            
            int affected = ps.executeUpdate();
            if (affected > 0) {
                // Update last message time
                updateLastMessageTime(roomId);
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error sending message: " + e.getMessage());
        }
        return false;
    }

    private void updateLastMessageTime(int roomId) {
        String updateSql = "UPDATE chat_rooms SET last_message_at = CURRENT_TIMESTAMP WHERE room_id = ?";
        try (PreparedStatement updatePs = connection.prepareStatement(updateSql)) {
            updatePs.setInt(1, roomId);
            updatePs.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Get messages for room with sender names - FIXED VERSION
     */
    /**
     * Get messages for room with sender names - FIXED VERSION with type handling
     */
    public List<Message> getMessages(int roomId) {
        List<Message> messages = new ArrayList<>();
        if (roomId == -1) return messages;
        
        // FIXED: Use CAST to handle VARCHAR to VARCHAR comparisons properly
        String sql = "SELECT m.*, " +
                     "CASE " +
                     "  WHEN m.sender_type = 'ADMIN' THEN 'Admin Support' " +
                     "  WHEN m.sender_type = 'ORGANIZER' THEN COALESCE(CONCAT(o.firstname, ' ', o.lastname), 'Organizer') " +
                     "  WHEN m.sender_type = 'CUSTOMER' THEN COALESCE(CONCAT(mem.firstname, ' ', mem.lastname), 'Customer') " +
                     "END as sender_name " +
                     "FROM messages m " +
                     "LEFT JOIN organizers o ON m.sender_type = 'ORGANIZER' AND m.sender_id = o.organizer_id " +
                     "LEFT JOIN members mem ON m.sender_type = 'CUSTOMER' AND m.sender_id = mem.member_id " +
                     "WHERE m.room_id = ? ORDER BY m.created_at ASC";
        
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, roomId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Message message = new Message();
                message.setMessageId(rs.getInt("message_id"));
                message.setRoomId(rs.getInt("room_id"));
                message.setSenderType(rs.getString("sender_type"));
                message.setSenderId(rs.getString("sender_id"));
                message.setMessageText(rs.getString("message_text"));
                message.setMessageType(rs.getString("message_type"));
                message.setRead(rs.getBoolean("is_read"));
                message.setCreatedAt(rs.getTimestamp("created_at"));
                message.setSenderName(rs.getString("sender_name"));
                messages.add(message);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading messages: " + e.getMessage());
        }
        return messages;
    }
    
    /**
     * Get unread count for notifications - ENHANCED VERSION
     */
    public int getUnreadCount(int roomId, String receiverType, String receiverId) {
        if (roomId == -1) return 0;
        
        String sql = "SELECT COUNT(*) as unread_count FROM messages " +
                     "WHERE room_id = ? AND is_read = 0 AND NOT (sender_type = ? AND sender_id = ?)";
        
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, roomId);
            ps.setString(2, receiverType);
            ps.setString(3, receiverId);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("unread_count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Get total unread messages count for user - FIXED METHOD
     */
    public int getTotalUnreadCount(String userId, String userType) {
        int totalUnread = 0;
        try {
            // Get all rooms where user is participant
            String sql = "SELECT room_id FROM chat_rooms WHERE " +
                        "(? = 'ADMIN') OR " +
                        "(organizer_id = ? AND ? = 'ORGANIZER') OR " +
                        "(customer_id = ? AND ? = 'CUSTOMER')";
            
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, userType);
            ps.setString(2, userId);
            ps.setString(3, userType);
            ps.setString(4, userId);
            ps.setString(5, userType);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int roomId = rs.getInt("room_id");
                totalUnread += getUnreadCount(roomId, userType, userId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return totalUnread;
    }

    /**
     * Mark messages as read when chat is opened
     */
    public void markMessagesAsRead(int roomId, String receiverType, String receiverId) {
        if (roomId == -1) return;
        
        String sql = "UPDATE messages SET is_read = 1 " +
                     "WHERE room_id = ? AND is_read = 0 AND NOT (sender_type = ? AND sender_id = ?)";
        
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, roomId);
            ps.setString(2, receiverType);
            ps.setString(3, receiverId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * AUTO-DISCOVER available chats based on existing database relationships - FIXED VERSION
     */
    public List<Map<String, String>> getAvailableChats(String userId, String userType) {
        List<Map<String, String>> chats = new ArrayList<>();
        
        try {
            switch (userType) {
                case "ADMIN":
                    loadAdminChats(chats);
                    break;
                case "ORGANIZER":
                    loadOrganizerChats(chats, userId);
                    break;
                case "CUSTOMER":
                    loadCustomerChats(chats, userId);
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading chats: " + e.getMessage());
        }
        
        return chats;
    }

    private void loadAdminChats(List<Map<String, String>> chats) throws SQLException {
        // Admin can chat with all organizers
        String organizersSql = "SELECT organizer_id, CONCAT(firstname, ' ', lastname) as name, " +
                              "COALESCE(company_name, 'Organizer') as info FROM organizers ORDER BY firstname, lastname";
        PreparedStatement ps = connection.prepareStatement(organizersSql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            Map<String, String> chat = new HashMap<>();
            chat.put("type", "ORGANIZER");
            chat.put("id", rs.getString("organizer_id"));
            chat.put("name", rs.getString("name"));
            chat.put("info", rs.getString("info"));
            
            // Get existing room ID
            int roomId = getOrCreateRoom("ADMIN_ORGANIZER", rs.getString("organizer_id"), null);
            chat.put("room_id", String.valueOf(roomId));
            
            // Add unread count for notification
            int unread = getUnreadCount(roomId, "ADMIN", "1"); // Use "1" for admin instead of "ADMIN_1"
            chat.put("unread", String.valueOf(unread));
            
            chats.add(chat);
        }
        
        // Admin can also chat with customers
        String customersSql = "SELECT member_id, CONCAT(firstname, ' ', lastname) as name, " +
                             "'Customer' as info FROM members ORDER BY firstname, lastname";
        ps = connection.prepareStatement(customersSql);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Map<String, String> chat = new HashMap<>();
            chat.put("type", "CUSTOMER");
            chat.put("id", rs.getString("member_id"));
            chat.put("name", rs.getString("name"));
            chat.put("info", rs.getString("info"));
            
            // Get existing room ID
            int roomId = getOrCreateRoom("ADMIN_CUSTOMER", null, rs.getString("member_id"));
            chat.put("room_id", String.valueOf(roomId));
            
            // Add unread count for notification
            int unread = getUnreadCount(roomId, "ADMIN", "1");
            chat.put("unread", String.valueOf(unread));
            
            chats.add(chat);
        }
    }

    private void loadOrganizerChats(List<Map<String, String>> chats, String organizerId) throws SQLException {
        // Organizer can chat with Admin
        Map<String, String> adminChat = new HashMap<>();
        adminChat.put("type", "ADMIN");
        adminChat.put("id", "1"); // Use "1" instead of "ADMIN_1"
        adminChat.put("name", "Admin Support");
        adminChat.put("info", "System Administrator");
        
        int adminRoomId = getOrCreateRoom("ADMIN_ORGANIZER", organizerId, null);
        adminChat.put("room_id", String.valueOf(adminRoomId));
        
        int adminUnread = getUnreadCount(adminRoomId, "ORGANIZER", organizerId);
        adminChat.put("unread", String.valueOf(adminUnread));
        
        chats.add(adminChat);
        
        // Organizer can chat with customers who booked their events
        String customersSql = "SELECT m.member_id, " +
                             "CONCAT(m.firstname, ' ', m.lastname) as name, " +
                             "m.email as info " +
                             "FROM members m " +
                             "JOIN bookings b ON m.member_id = b.user_id " +
                             "JOIN events e ON b.event_code = e.event_code " +
                             "WHERE e.organizer_id = ? AND b.status = 'Confirmed' " +
                             "GROUP BY m.member_id, m.firstname, m.lastname, m.email " +
                             "ORDER BY m.firstname, m.lastname";
        
        PreparedStatement ps = connection.prepareStatement(customersSql);
        ps.setString(1, organizerId);
        ResultSet rs = ps.executeQuery();
        
        boolean hasCustomers = false;
        while (rs.next()) {
            hasCustomers = true;
            Map<String, String> chat = new HashMap<>();
            chat.put("type", "CUSTOMER");
            chat.put("id", rs.getString("member_id"));
            chat.put("name", rs.getString("name"));
            chat.put("info", rs.getString("info"));
            
            int roomId = getOrCreateRoom("ORGANIZER_CUSTOMER", organizerId, rs.getString("member_id"));
            chat.put("room_id", String.valueOf(roomId));
            
            int unread = getUnreadCount(roomId, "ORGANIZER", organizerId);
            chat.put("unread", String.valueOf(unread));
            
            chats.add(chat);
        }
        
        if (!hasCustomers) {
            Map<String, String> noCustomers = new HashMap<>();
            noCustomers.put("type", "INFO");
            noCustomers.put("id", "INFO");
            noCustomers.put("name", "No customers found");
            noCustomers.put("info", "Create events and get bookings to chat with customers");
            noCustomers.put("unread", "0");
            chats.add(noCustomers);
        }
    }

    private void loadCustomerChats(List<Map<String, String>> chats, String customerId) throws SQLException {
        // Customer can chat with Admin
        Map<String, String> adminChat = new HashMap<>();
        adminChat.put("type", "ADMIN");
        adminChat.put("id", "1"); // Use "1" instead of "ADMIN_1"
        adminChat.put("name", "Admin Support");
        adminChat.put("info", "System Administrator");
        
        int adminRoomId = getOrCreateRoom("ADMIN_CUSTOMER", null, customerId);
        adminChat.put("room_id", String.valueOf(adminRoomId));
        
        int adminUnread = getUnreadCount(adminRoomId, "CUSTOMER", customerId);
        adminChat.put("unread", String.valueOf(adminUnread));
        
        chats.add(adminChat);
        
        // Customer can chat with organizers of events they booked
        String organizersSql = "SELECT o.organizer_id, " +
                              "CONCAT(o.firstname, ' ', o.lastname) as name, " +
                              "COALESCE(o.company_name, 'Organizer') as info " +
                              "FROM organizers o " +
                              "JOIN events e ON o.organizer_id = e.organizer_id " +
                              "JOIN bookings b ON e.event_code = b.event_code " +
                              "WHERE b.user_id = ? AND b.status = 'Confirmed' " +
                              "GROUP BY o.organizer_id, o.firstname, o.lastname, o.company_name " +
                              "ORDER BY o.firstname, o.lastname";
        
        PreparedStatement ps = connection.prepareStatement(organizersSql);
        ps.setString(1, customerId);
        ResultSet rs = ps.executeQuery();
        
        boolean hasOrganizers = false;
        while (rs.next()) {
            hasOrganizers = true;
            Map<String, String> chat = new HashMap<>();
            chat.put("type", "ORGANIZER");
            chat.put("id", rs.getString("organizer_id"));
            chat.put("name", rs.getString("name"));
            chat.put("info", rs.getString("info"));
            
            int roomId = getOrCreateRoom("ORGANIZER_CUSTOMER", rs.getString("organizer_id"), customerId);
            chat.put("room_id", String.valueOf(roomId));
            
            int unread = getUnreadCount(roomId, "CUSTOMER", customerId);
            chat.put("unread", String.valueOf(unread));
            
            chats.add(chat);
        }
        
        if (!hasOrganizers) {
            Map<String, String> noOrganizers = new HashMap<>();
            noOrganizers.put("type", "INFO");
            noOrganizers.put("id", "INFO");
            noOrganizers.put("name", "No organizers found");
            noOrganizers.put("info", "Book events to chat with organizers");
            noOrganizers.put("unread", "0");
            chats.add(noOrganizers);
        }
    }
    /**
     * Check if user exists in database
     */
    public boolean userExists(String userId, String userType) {
        if (userId == null || userId.isEmpty()) return false;
        
        try {
            String sql = "";
            if ("CUSTOMER".equals(userType)) {
                sql = "SELECT 1 FROM members WHERE member_id = ?";
            } else if ("ORGANIZER".equals(userType)) {
                sql = "SELECT 1 FROM organizers WHERE organizer_id = ?";
            } else if ("ADMIN".equals(userType)) {
                sql = "SELECT 1 FROM admins WHERE admin_id = ?";
            } else {
                return false;
            }
            
            PreparedStatement ps = connection.prepareStatement(sql);
            
            // Handle admin ID conversion (INT to String)
            if ("ADMIN".equals(userType)) {
                ps.setInt(1, Integer.parseInt(userId));
            } else {
                ps.setString(1, userId);
            }
            
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Get available customer IDs for debugging
     */
    public List<String> getAvailableCustomerIds() {
        List<String> customerIds = new ArrayList<>();
        try {
            String sql = "SELECT member_id FROM members ORDER BY member_id";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                customerIds.add(rs.getString("member_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customerIds;
    }
    
    /**
     * Show notification for new messages - IMPROVED METHOD
     */
    public void showNewMessageNotification(String userName, String messagePreview) {
        // System tray notification
        if (SystemTray.isSupported()) {
            try {
                SystemTray tray = SystemTray.getSystemTray();
                
                // Create a default image if no icon available
                java.awt.Image image = new java.awt.image.BufferedImage(16, 16, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = (Graphics2D) image.getGraphics();
                g2d.setColor(Color.BLUE);
                g2d.fillRect(0, 0, 16, 16);
                g2d.dispose();
                
                TrayIcon trayIcon = new TrayIcon(image);
                tray.add(trayIcon);
                
                trayIcon.displayMessage("New Message from " + userName, 
                                      messagePreview.length() > 50 ? messagePreview.substring(0, 50) + "..." : messagePreview,
                                      TrayIcon.MessageType.INFO);
                
                // Remove the tray icon after showing notification
                tray.remove(trayIcon);
            } catch (Exception e) {
                // Fallback to JOptionPane if system tray not available
                showFallbackNotification(userName, messagePreview);
            }
        } else {
            showFallbackNotification(userName, messagePreview);
        }
    }

    private void showFallbackNotification(String userName, String messagePreview) {
        JOptionPane.showMessageDialog(null, 
            "New message from " + userName + ":\n" + messagePreview,
            "New Message", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Validate if user can access the room - NEW SECURITY METHOD
     */
    public boolean canAccessRoom(int roomId, String userId, String userType) {
        if (roomId == -1) return false;
        
        try {
            String sql = "SELECT room_id FROM chat_rooms WHERE room_id = ? AND " +
                        "(? = 'ADMIN' OR organizer_id = ? OR customer_id = ?)";
            
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, roomId);
            ps.setString(2, userType);
            ps.setString(3, userId);
            ps.setString(4, userId);
            
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * DEBUG METHOD: Check current chat rooms
     */
    public void debugChatRooms() {
        try {
            String sql = "SELECT * FROM chat_rooms ORDER BY room_id";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            System.out.println("=== CURRENT CHAT ROOMS ===");
            while (rs.next()) {
                System.out.println("Room ID: " + rs.getInt("room_id") +
                                 ", Type: " + rs.getString("room_type") +
                                 ", Organizer: " + rs.getString("organizer_id") +
                                 ", Customer: " + rs.getString("customer_id") +
                                 ", Admin: " + rs.getInt("admin_id"));
            }
            System.out.println("===========================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

// Message class should be defined
class Message {
    private int messageId;
    private int roomId;
    private String senderType;
    private String senderId;
    private String messageText;
    private String messageType;
    private boolean isRead;
    private java.sql.Timestamp createdAt;
    private String senderName;

    // Getters and setters
    public int getMessageId() { return messageId; }
    public void setMessageId(int messageId) { this.messageId = messageId; }
    
    public int getRoomId() { return roomId; }
    public void setRoomId(int roomId) { this.roomId = roomId; }
    
    public String getSenderType() { return senderType; }
    public void setSenderType(String senderType) { this.senderType = senderType; }
    
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }
    
    public String getMessageText() { return messageText; }
    public void setMessageText(String messageText) { this.messageText = messageText; }
    
    public String getMessageType() { return messageType; }
    public void setMessageType(String messageType) { this.messageType = messageType; }
    
    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }
    
    public java.sql.Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.sql.Timestamp createdAt) { this.createdAt = createdAt; }
    
    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }
    
    public boolean isSentByCurrentUser(String userId, String userType) {
        return this.senderId.equals(userId) && this.senderType.equals(userType);
    }
}