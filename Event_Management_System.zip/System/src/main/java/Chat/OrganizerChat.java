package Chat;


import javax.swing.*;
import java.awt.*;

public class OrganizerChat extends RealTimeChatFrame {
    
    public OrganizerChat(String organizerId) {
        super("Organizer Chat", organizerId, "ORGANIZER");
    }
    
    @Override
    protected Color getUserColor() {
        return ORGANIZER_COLOR;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrganizerChat("ORG003"));
    }
}