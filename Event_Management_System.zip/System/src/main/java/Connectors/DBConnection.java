package Connectors;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import Config.*;
public class DBConnection {
    static ConfigManager cfg = new ConfigManager();
    
    static final String URL = cfg.get("DB_URL");
    static final String USER = cfg.get("DB_USER");    
    static final String PASS = cfg.get("DB_PASS"); 

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database connection failed: " + e.getMessage());
            return null;
        }
    }
    
    // Helper method to close connections properly
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}