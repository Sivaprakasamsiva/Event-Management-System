package Connectors;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class PDF_Generator {
    private Connection con;
    private DecimalFormat currencyFormat;
    private DecimalFormat percentFormat;
    
    // Font definitions for consistent styling
    private static final Font TITLE_FONT = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
    private static final Font HEADER_FONT = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.BLACK);
    private static final Font SUBHEADER_FONT = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.DARK_GRAY);
    private static final Font NORMAL_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
    private static final Font BOLD_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
    private static final Font HIGHLIGHT_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.RED);
    
    public PDF_Generator(Connection connection) {
        this.con = connection;
        this.currencyFormat = new DecimalFormat("#,##0.00");
        this.percentFormat = new DecimalFormat("0.00%");
    }
    
    /**
     * Generate full financial report with past events, loss calculations, charts and rankings
     */
    public boolean generateFullFinancialReport(String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Complete Financial Report - Event Management System");
            
            // Title page
            addTitlePage(document, "COMPLETE FINANCIAL INSIGHTS REPORT", 
                       "Event Management System - Revenue & Loss Analysis");
            
            // Executive Summary
            addExecutiveSummary(document);
            
            // Past Events with Loss Calculations
            addPastEventsAnalysis(document);
            
            // Revenue vs Loss Analysis
            addRevenueLossAnalysis(document);
            
            // Event Rankings
            addEventRankings(document);
            
            // Organizer Performance
            addOrganizerRankings(document);
            
            // Financial Charts Summary
            addFinancialChartsSummary(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }
    
    /**
     * Generate PDF report for selected events only - UPDATED TO USE List<String>
     */
    public boolean generateSelectedEventsReport(List<String> eventIds, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Selected Events Financial Report");
            
            // Title page
            addTitlePage(document, "SELECTED EVENTS FINANCIAL REPORT", 
                       "Custom Report for " + eventIds.size() + " Selected Events");
            
            // Selected Events Analysis
            addSelectedEventsAnalysis(document, eventIds);
            
            // Individual Event Details
            addIndividualEventDetails(document, eventIds);
            
            // Financial Summary for Selected Events
            addSelectedEventsSummary(document, eventIds);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }
    
    /**
     * Generate organizer PDF report for selected organizer with custom file path
     */
    public boolean generateOrganizerPDF(String organizerId, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Organizer Report - " + organizerId);
            
            // Get organizer details
            String organizerSql = "SELECT * FROM organizers WHERE organizer_id = ?";
            PreparedStatement organizerStmt = con.prepareStatement(organizerSql);
            organizerStmt.setString(1, organizerId);
            ResultSet organizerRs = organizerStmt.executeQuery();
            
            if (organizerRs.next()) {
                // Add title with organizer name
                String organizerName = organizerRs.getString("firstname") + " " + organizerRs.getString("lastname");
                addTitlePage(document, "ORGANIZER REPORT - " + organizerName.toUpperCase(), 
                           "Organizer ID: " + organizerId);
                
                // Organizer information section
                addOrganizerInfoSection(document, organizerRs);
                
                // Events summary section
                addOrganizerEventsSummarySection(document, organizerId);
                
                // Detailed events table
                addOrganizerEventsTable(document, organizerId);
                
                // Financial performance
                addOrganizerFinancialPerformance(document, organizerId);
                
            } else {
                addErrorMessage(document, "Organizer not found with ID: " + organizerId);
                return false;
            }
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }
    
    /**
     * Generate customer PDF report for selected customer with custom file path
     */
    public boolean generateCustomerPDF(String memberId, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Customer Report - " + memberId);
            
            // Get customer details
            String customerSql = "SELECT * FROM members WHERE member_id = ?";
            PreparedStatement customerStmt = con.prepareStatement(customerSql);
            customerStmt.setString(1, memberId);
            ResultSet customerRs = customerStmt.executeQuery();
            
            if (customerRs.next()) {
                // Add title with customer name
                String customerName = customerRs.getString("firstname") + " " + customerRs.getString("lastname");
                addTitlePage(document, "CUSTOMER REPORT - " + customerName.toUpperCase(), 
                           "Customer ID: " + memberId);
                
                // Customer information section
                addCustomerInfoSection(document, customerRs);
                
                // Booking history section
                addCustomerBookingHistorySection(document, memberId);
                
            } else {
                addErrorMessage(document, "Customer not found with ID: " + memberId);
                return false;
            }
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }
    
    /**
     * Generate comprehensive organizers report with all organizers
     */
    public boolean generateOrganizersReport(String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Organizers Master Report");
            
            // Add title and timestamp
            addTitlePage(document, "ORGANIZERS MASTER REPORT");
            
            // Get all organizers
            String organizersSql = "SELECT * FROM organizers ORDER BY created_at DESC";
            PreparedStatement organizersStmt = con.prepareStatement(organizersSql);
            ResultSet organizersRs = organizersStmt.executeQuery();
            
            // Summary statistics
            addOrganizersSummarySection(document);
            
            // Detailed organizers table
            addOrganizersTable(document, organizersRs);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }
    
    /**
     * Generate comprehensive users report with all users
     */
    public boolean generateUsersReport(String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // Add metadata
            addMetadata(document, "Users Master Report");
            
            // Add title and timestamp
            addTitlePage(document, "USERS MASTER REPORT");
            
            // Get all users
            String usersSql = "SELECT * FROM members ORDER BY created_at DESC";
            PreparedStatement usersStmt = con.prepareStatement(usersSql);
            ResultSet usersRs = usersStmt.executeQuery();
            
            // Summary statistics
            addUsersSummarySection(document);
            
            // Detailed users table
            addUsersTable(document, usersRs);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (document.isOpen()) document.close();
            } catch (Exception ex) {}
            return false;
        }
    }

    // NEW: Executive Summary Section
    private void addExecutiveSummary(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Executive Summary", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        // Get overall statistics
        String statsSql = "SELECT " +
            "COUNT(*) as total_events, " +
            "SUM(CASE WHEN event_date < CURDATE() THEN 1 ELSE 0 END) as past_events, " +
            "SUM(CASE WHEN event_date >= CURDATE() THEN 1 ELSE 0 END) as future_events, " +
            "SUM(tickets_sold) as total_tickets_sold, " +
            "SUM(revenue) as total_revenue, " +
            "AVG(revenue) as avg_revenue_per_event " +
            "FROM events WHERE status = 'Approved'";
        
        PreparedStatement statsStmt = con.prepareStatement(statsSql);
        ResultSet statsRs = statsStmt.executeQuery();
        
        if (statsRs.next()) {
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingBefore(10f);
            summaryTable.setSpacingAfter(20f);
            summaryTable.setWidths(new float[]{1, 2});
            
            addTableRow(summaryTable, "Total Events:", String.valueOf(statsRs.getInt("total_events")));
            addTableRow(summaryTable, "Past Events:", String.valueOf(statsRs.getInt("past_events")));
            addTableRow(summaryTable, "Future Events:", String.valueOf(statsRs.getInt("future_events")));
            addTableRow(summaryTable, "Total Tickets Sold:", String.valueOf(statsRs.getInt("total_tickets_sold")));
            addTableRow(summaryTable, "Total Revenue:", "₹" + currencyFormat.format(statsRs.getDouble("total_revenue")));
            addTableRow(summaryTable, "Avg Revenue/Event:", 
                "₹" + currencyFormat.format(statsRs.getDouble("avg_revenue_per_event")));
            
            document.add(summaryTable);
        }
        
        // Add financial highlights
        addFinancialHighlights(document);
    }
    
    // NEW: Past Events Analysis with Loss Calculations
    private void addPastEventsAnalysis(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Past Events - Revenue & Loss Analysis", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        String pastEventsSql = "SELECT e.*, o.firstname, o.lastname, " +
            "e.capacity - e.tickets_sold as unsold_tickets, " +
            "(e.capacity - e.tickets_sold) * e.price as potential_loss, " +
            "e.tickets_sold * e.price as potential_revenue, " +
            "e.revenue as actual_revenue, " +
            "(e.tickets_sold * e.price) - e.revenue as revenue_gap " +
            "FROM events e " +
            "JOIN organizers o ON e.organizer_id = o.organizer_id " +
            "WHERE e.event_date < CURDATE() AND e.status = 'Approved' " +
            "ORDER BY e.event_date DESC";
        
        PreparedStatement pastEventsStmt = con.prepareStatement(pastEventsSql);
        ResultSet pastEventsRs = pastEventsStmt.executeQuery();
        
        if (!pastEventsRs.isBeforeFirst()) {
            Paragraph noData = new Paragraph("No past events found for analysis.", NORMAL_FONT);
            document.add(noData);
            return;
        }
        
        PdfPTable pastEventsTable = new PdfPTable(10);
        pastEventsTable.setWidthPercentage(100);
        pastEventsTable.setSpacingBefore(10f);
        
        // Set column widths
        pastEventsTable.setWidths(new float[]{1, 2, 1.5f, 1, 1, 1, 1, 1, 1, 1});
        
        // Add table headers
        addTableHeader(pastEventsTable, "Event ID");
        addTableHeader(pastEventsTable, "Event Title");
        addTableHeader(pastEventsTable, "Organizer");
        addTableHeader(pastEventsTable, "Date");
        addTableHeader(pastEventsTable, "Capacity");
        addTableHeader(pastEventsTable, "Sold");
        addTableHeader(pastEventsTable, "Unsold");
        addTableHeader(pastEventsTable, "Actual Revenue");
        addTableHeader(pastEventsTable, "Potential Loss");
        addTableHeader(pastEventsTable, "Revenue Gap");
        
        double totalActualRevenue = 0;
        double totalPotentialLoss = 0;
        double totalRevenueGap = 0;
        
        while (pastEventsRs.next()) {
            // FIXED: Use getString for event_id since it's VARCHAR
            pastEventsTable.addCell(createTableCell(pastEventsRs.getString("event_id")));
            pastEventsTable.addCell(createTableCell(pastEventsRs.getString("title")));
            pastEventsTable.addCell(createTableCell(
                pastEventsRs.getString("firstname") + " " + pastEventsRs.getString("lastname")));
            
            String eventDate = new SimpleDateFormat("MMM dd, yyyy")
                .format(pastEventsRs.getTimestamp("event_date"));
            pastEventsTable.addCell(createTableCell(eventDate));
            
            pastEventsTable.addCell(createTableCell(String.valueOf(pastEventsRs.getInt("capacity"))));
            pastEventsTable.addCell(createTableCell(String.valueOf(pastEventsRs.getInt("tickets_sold"))));
            
            int unsold = pastEventsRs.getInt("unsold_tickets");
            pastEventsTable.addCell(createTableCell(String.valueOf(unsold)));
            
            double actualRevenue = pastEventsRs.getDouble("actual_revenue");
            pastEventsTable.addCell(createTableCell("₹" + currencyFormat.format(actualRevenue)));
            
            double potentialLoss = pastEventsRs.getDouble("potential_loss");
            PdfPCell lossCell = createTableCell("₹" + currencyFormat.format(potentialLoss));
            if (potentialLoss > 0) lossCell.setBackgroundColor(new BaseColor(255, 230, 230));
            pastEventsTable.addCell(lossCell);
            
            double revenueGap = pastEventsRs.getDouble("revenue_gap");
            PdfPCell gapCell = createTableCell("₹" + currencyFormat.format(revenueGap));
            if (revenueGap > 0) gapCell.setBackgroundColor(new BaseColor(255, 240, 240));
            pastEventsTable.addCell(gapCell);
            
            totalActualRevenue += actualRevenue;
            totalPotentialLoss += potentialLoss;
            totalRevenueGap += revenueGap;
        }
        
        document.add(pastEventsTable);
        
        // Add summary
        addEmptyLine(document, 1);
        Paragraph summary = new Paragraph("Past Events Financial Summary:", BOLD_FONT);
        summary.setSpacingAfter(5f);
        document.add(summary);
        
        PdfPTable summaryTable = new PdfPTable(2);
        summaryTable.setWidthPercentage(50);
        summaryTable.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        addTableRow(summaryTable, "Total Actual Revenue:", "₹" + currencyFormat.format(totalActualRevenue));
        addTableRow(summaryTable, "Total Potential Loss:", "₹" + currencyFormat.format(totalPotentialLoss));
        addTableRow(summaryTable, "Total Revenue Gap:", "₹" + currencyFormat.format(totalRevenueGap));
        addTableRow(summaryTable, "Efficiency Rate:", 
            percentFormat.format((totalActualRevenue / (totalActualRevenue + totalPotentialLoss))));
        
        document.add(summaryTable);
    }
    
    // NEW: Revenue vs Loss Analysis
    private void addRevenueLossAnalysis(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Revenue vs Loss Analysis", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        String analysisSql = "SELECT " +
            "DATE_FORMAT(event_date, '%Y-%m') as month, " +
            "COUNT(*) as event_count, " +
            "SUM(revenue) as total_revenue, " +
            "SUM((capacity - tickets_sold) * price) as total_potential_loss, " +
            "SUM(tickets_sold * price) as total_potential_revenue, " +
            "AVG(revenue) as avg_revenue_per_event " +
            "FROM events " +
            "WHERE status = 'Approved' " +
            "GROUP BY DATE_FORMAT(event_date, '%Y-%m') " +
            "ORDER BY month DESC LIMIT 12";
        
        PreparedStatement analysisStmt = con.prepareStatement(analysisSql);
        ResultSet analysisRs = analysisStmt.executeQuery();
        
        PdfPTable analysisTable = new PdfPTable(6);
        analysisTable.setWidthPercentage(100);
        analysisTable.setSpacingBefore(10f);
        
        // Set column widths
        analysisTable.setWidths(new float[]{1.5f, 1, 1.5f, 1.5f, 1.5f, 1.5f});
        
        // Add table headers
        addTableHeader(analysisTable, "Month");
        addTableHeader(analysisTable, "Events");
        addTableHeader(analysisTable, "Actual Revenue");
        addTableHeader(analysisTable, "Potential Loss");
        addTableHeader(analysisTable, "Potential Revenue");
        addTableHeader(analysisTable, "Revenue Efficiency");
        
        while (analysisRs.next()) {
            analysisTable.addCell(createTableCell(analysisRs.getString("month")));
            analysisTable.addCell(createTableCell(String.valueOf(analysisRs.getInt("event_count"))));
            
            double actualRevenue = analysisRs.getDouble("total_revenue");
            analysisTable.addCell(createTableCell("₹" + currencyFormat.format(actualRevenue)));
            
            double potentialLoss = analysisRs.getDouble("total_potential_loss");
            analysisTable.addCell(createTableCell("₹" + currencyFormat.format(potentialLoss)));
            
            double potentialRevenue = analysisRs.getDouble("total_potential_revenue");
            analysisTable.addCell(createTableCell("₹" + currencyFormat.format(potentialRevenue)));
            
            double efficiency = (actualRevenue / potentialRevenue) * 100;
            PdfPCell efficiencyCell = createTableCell(percentFormat.format(efficiency / 100));
            if (efficiency < 50) efficiencyCell.setBackgroundColor(new BaseColor(255, 200, 200));
            else if (efficiency < 75) efficiencyCell.setBackgroundColor(new BaseColor(255, 255, 200));
            else efficiencyCell.setBackgroundColor(new BaseColor(200, 255, 200));
            analysisTable.addCell(efficiencyCell);
        }
        
        document.add(analysisTable);
    }
    
    // NEW: Event Rankings by Revenue
    private void addEventRankings(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Top Performing Events - Revenue Rankings", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        String rankingsSql = "SELECT e.*, o.firstname, o.lastname, " +
            "e.tickets_sold * e.price as potential_revenue, " +
            "(e.tickets_sold * e.price) - e.revenue as revenue_gap, " +
            "(e.tickets_sold / e.capacity) * 100 as occupancy_rate " +
            "FROM events e " +
            "JOIN organizers o ON e.organizer_id = o.organizer_id " +
            "WHERE e.status = 'Approved' " +
            "ORDER BY e.revenue DESC LIMIT 15";
        
        PreparedStatement rankingsStmt = con.prepareStatement(rankingsSql);
        ResultSet rankingsRs = rankingsStmt.executeQuery();
        
        PdfPTable rankingsTable = new PdfPTable(8);
        rankingsTable.setWidthPercentage(100);
        rankingsTable.setSpacingBefore(10f);
        
        // Set column widths
        rankingsTable.setWidths(new float[]{0.5f, 2, 1.5f, 1, 1, 1, 1, 1});
        
        // Add table headers
        addTableHeader(rankingsTable, "Rank");
        addTableHeader(rankingsTable, "Event Title");
        addTableHeader(rankingsTable, "Organizer");
        addTableHeader(rankingsTable, "Tickets Sold");
        addTableHeader(rankingsTable, "Capacity");
        addTableHeader(rankingsTable, "Occupancy Rate");
        addTableHeader(rankingsTable, "Actual Revenue");
        addTableHeader(rankingsTable, "Revenue Gap");
        
        int rank = 1;
        while (rankingsRs.next()) {
            rankingsTable.addCell(createTableCell(String.valueOf(rank++)));
            rankingsTable.addCell(createTableCell(rankingsRs.getString("title")));
            rankingsTable.addCell(createTableCell(
                rankingsRs.getString("firstname") + " " + rankingsRs.getString("lastname")));
            
            int ticketsSold = rankingsRs.getInt("tickets_sold");
            rankingsTable.addCell(createTableCell(String.valueOf(ticketsSold)));
            
            int capacity = rankingsRs.getInt("capacity");
            rankingsTable.addCell(createTableCell(String.valueOf(capacity)));
            
            double occupancyRate = rankingsRs.getDouble("occupancy_rate");
            PdfPCell occupancyCell = createTableCell(percentFormat.format(occupancyRate / 100));
            if (occupancyRate < 50) occupancyCell.setBackgroundColor(new BaseColor(255, 200, 200));
            else if (occupancyRate < 75) occupancyCell.setBackgroundColor(new BaseColor(255, 255, 200));
            else occupancyCell.setBackgroundColor(new BaseColor(200, 255, 200));
            rankingsTable.addCell(occupancyCell);
            
            double revenue = rankingsRs.getDouble("revenue");
            rankingsTable.addCell(createTableCell("₹" + currencyFormat.format(revenue)));
            
            double revenueGap = rankingsRs.getDouble("revenue_gap");
            rankingsTable.addCell(createTableCell("₹" + currencyFormat.format(revenueGap)));
        }
        
        document.add(rankingsTable);
    }
    
    // NEW: Organizer Performance Rankings
    private void addOrganizerRankings(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Organizer Performance Rankings", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        String organizerRankingsSql = "SELECT o.organizer_id, o.firstname, o.lastname, o.company_name, " +
            "COUNT(e.event_id) as total_events, " +
            "SUM(e.tickets_sold) as total_tickets_sold, " +
            "SUM(e.revenue) as total_revenue, " +
            "AVG(e.revenue) as avg_revenue_per_event, " +
            "SUM((e.capacity - e.tickets_sold) * e.price) as total_potential_loss " +
            "FROM organizers o " +
            "LEFT JOIN events e ON o.organizer_id = e.organizer_id AND e.status = 'Approved' " +
            "GROUP BY o.organizer_id, o.firstname, o.lastname, o.company_name " +
            "HAVING total_events > 0 " +
            "ORDER BY total_revenue DESC";
        
        PreparedStatement organizerRankingsStmt = con.prepareStatement(organizerRankingsSql);
        ResultSet organizerRankingsRs = organizerRankingsStmt.executeQuery();
        
        PdfPTable organizerTable = new PdfPTable(7);
        organizerTable.setWidthPercentage(100);
        organizerTable.setSpacingBefore(10f);
        
        // Set column widths
        organizerTable.setWidths(new float[]{0.5f, 1.5f, 1.5f, 2, 1, 1, 1});
        
        // Add table headers
        addTableHeader(organizerTable, "Rank");
        addTableHeader(organizerTable, "Organizer ID");
        addTableHeader(organizerTable, "Name");
        addTableHeader(organizerTable, "Company");
        addTableHeader(organizerTable, "Total Events");
        addTableHeader(organizerTable, "Total Revenue");
        addTableHeader(organizerTable, "Potential Loss");
        
        int rank = 1;
        while (organizerRankingsRs.next()) {
            organizerTable.addCell(createTableCell(String.valueOf(rank++)));
            organizerTable.addCell(createTableCell(organizerRankingsRs.getString("organizer_id")));
            organizerTable.addCell(createTableCell(
                organizerRankingsRs.getString("firstname") + " " + organizerRankingsRs.getString("lastname")));
            organizerTable.addCell(createTableCell(
                organizerRankingsRs.getString("company_name") != null ? 
                organizerRankingsRs.getString("company_name") : "N/A"));
            organizerTable.addCell(createTableCell(String.valueOf(organizerRankingsRs.getInt("total_events"))));
            
            double totalRevenue = organizerRankingsRs.getDouble("total_revenue");
            organizerTable.addCell(createTableCell("₹" + currencyFormat.format(totalRevenue)));
            
            double potentialLoss = organizerRankingsRs.getDouble("total_potential_loss");
            PdfPCell lossCell = createTableCell("₹" + currencyFormat.format(potentialLoss));
            if (potentialLoss > totalRevenue * 0.3) lossCell.setBackgroundColor(new BaseColor(255, 230, 230));
            organizerTable.addCell(lossCell);
        }
        
        document.add(organizerTable);
    }
    
    // NEW: Financial Charts Summary (text-based)
    private void addFinancialChartsSummary(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Financial Performance Insights", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        // Get key performance indicators
        String kpiSql = "SELECT " +
            "SUM(revenue) as total_revenue, " +
            "SUM((capacity - tickets_sold) * price) as total_potential_loss, " +
            "AVG((tickets_sold / capacity) * 100) as avg_occupancy_rate, " +
            "AVG(revenue) as avg_revenue_per_event, " +
            "MAX(revenue) as max_revenue, " +
            "MIN(revenue) as min_revenue " +
            "FROM events WHERE status = 'Approved'";
        
        PreparedStatement kpiStmt = con.prepareStatement(kpiSql);
        ResultSet kpiRs = kpiStmt.executeQuery();
        
        if (kpiRs.next()) {
            PdfPTable kpiTable = new PdfPTable(2);
            kpiTable.setWidthPercentage(100);
            kpiTable.setSpacingBefore(10f);
            kpiTable.setWidths(new float[]{1, 2});
            
            double totalRevenue = kpiRs.getDouble("total_revenue");
            double totalLoss = kpiRs.getDouble("total_potential_loss");
            double avgOccupancy = kpiRs.getDouble("avg_occupancy_rate");
            double avgRevenue = kpiRs.getDouble("avg_revenue_per_event");
            
            addTableRow(kpiTable, "Total System Revenue:", "₹" + currencyFormat.format(totalRevenue));
            addTableRow(kpiTable, "Total Potential Loss:", "₹" + currencyFormat.format(totalLoss));
            addTableRow(kpiTable, "Revenue Efficiency:", 
                percentFormat.format((totalRevenue / (totalRevenue + totalLoss))));
            addTableRow(kpiTable, "Average Occupancy Rate:", percentFormat.format(avgOccupancy / 100));
            addTableRow(kpiTable, "Average Revenue per Event:", "₹" + currencyFormat.format(avgRevenue));
            addTableRow(kpiTable, "Highest Revenue Event:", "₹" + currencyFormat.format(kpiRs.getDouble("max_revenue")));
            addTableRow(kpiTable, "Lowest Revenue Event:", "₹" + currencyFormat.format(kpiRs.getDouble("min_revenue")));
            
            document.add(kpiTable);
        }
        
        // Add recommendations based on data
        addFinancialRecommendations(document);
    }
    
    // NEW: Selected Events Analysis - UPDATED TO USE List<String>
    private void addSelectedEventsAnalysis(Document document, List<String> eventIds) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Selected Events Financial Analysis", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (eventIds.isEmpty()) {
            document.add(new Paragraph("No events selected for analysis.", NORMAL_FONT));
            return;
        }
        
        // Create SQL placeholders for IN clause
        String placeholders = String.join(",", Collections.nCopies(eventIds.size(), "?"));
        String selectedSql = "SELECT e.*, o.firstname, o.lastname, " +
            "e.capacity - e.tickets_sold as unsold_tickets, " +
            "(e.capacity - e.tickets_sold) * e.price as potential_loss, " +
            "e.tickets_sold * e.price as potential_revenue, " +
            "(e.tickets_sold / e.capacity) * 100 as occupancy_rate " +
            "FROM events e " +
            "JOIN organizers o ON e.organizer_id = o.organizer_id " +
            "WHERE e.event_id IN (" + placeholders + ") " +
            "ORDER BY e.revenue DESC";
        
        PreparedStatement selectedStmt = con.prepareStatement(selectedSql);
        for (int i = 0; i < eventIds.size(); i++) {
            selectedStmt.setString(i + 1, eventIds.get(i)); // Changed to setString
        }
        
        ResultSet selectedRs = selectedStmt.executeQuery();
        
        PdfPTable selectedTable = new PdfPTable(9);
        selectedTable.setWidthPercentage(100);
        selectedTable.setSpacingBefore(10f);
        
        // Set column widths
        selectedTable.setWidths(new float[]{1, 2, 1.5f, 1, 1, 1, 1, 1, 1});
        
        // Add table headers
        addTableHeader(selectedTable, "Event ID");
        addTableHeader(selectedTable, "Title");
        addTableHeader(selectedTable, "Organizer");
        addTableHeader(selectedTable, "Date");
        addTableHeader(selectedTable, "Sold");
        addTableHeader(selectedTable, "Unsold");
        addTableHeader(selectedTable, "Occupancy");
        addTableHeader(selectedTable, "Revenue");
        addTableHeader(selectedTable, "Potential Loss");
        
        while (selectedRs.next()) {
            // FIXED: Use getString for event_id
            selectedTable.addCell(createTableCell(selectedRs.getString("event_id")));
            selectedTable.addCell(createTableCell(selectedRs.getString("title")));
            selectedTable.addCell(createTableCell(
                selectedRs.getString("firstname") + " " + selectedRs.getString("lastname")));
            
            String eventDate = new SimpleDateFormat("MMM dd, yyyy")
                .format(selectedRs.getTimestamp("event_date"));
            selectedTable.addCell(createTableCell(eventDate));
            
            selectedTable.addCell(createTableCell(String.valueOf(selectedRs.getInt("tickets_sold"))));
            selectedTable.addCell(createTableCell(String.valueOf(selectedRs.getInt("unsold_tickets"))));
            
            double occupancy = selectedRs.getDouble("occupancy_rate");
            PdfPCell occupancyCell = createTableCell(percentFormat.format(occupancy / 100));
            if (occupancy < 50) occupancyCell.setBackgroundColor(new BaseColor(255, 200, 200));
            else if (occupancy < 75) occupancyCell.setBackgroundColor(new BaseColor(255, 255, 200));
            else occupancyCell.setBackgroundColor(new BaseColor(200, 255, 200));
            selectedTable.addCell(occupancyCell);
            
            selectedTable.addCell(createTableCell("₹" + currencyFormat.format(selectedRs.getDouble("revenue"))));
            selectedTable.addCell(createTableCell("₹" + currencyFormat.format(selectedRs.getDouble("potential_loss"))));
        }
        
        document.add(selectedTable);
    }
    
    // NEW: Individual Event Details for Selected Events - UPDATED TO USE List<String>
    private void addIndividualEventDetails(Document document, List<String> eventIds) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Individual Event Details", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        for (String eventId : eventIds) {
            String detailSql = "SELECT e.*, o.firstname, o.lastname, o.email, o.mobile, " +
                "e.capacity - e.tickets_sold as unsold_tickets, " +
                "(e.capacity - e.tickets_sold) * e.price as potential_loss, " +
                "e.tickets_sold * e.price as potential_revenue, " +
                "(e.tickets_sold / e.capacity) * 100 as occupancy_rate, " +
                "e.revenue as actual_revenue, " +
                "(e.tickets_sold * e.price) - e.revenue as revenue_gap " +
                "FROM events e " +
                "JOIN organizers o ON e.organizer_id = o.organizer_id " +
                "WHERE e.event_id = ?";
            
            PreparedStatement detailStmt = con.prepareStatement(detailSql);
            detailStmt.setString(1, eventId); // Changed to setString
            ResultSet detailRs = detailStmt.executeQuery();
            
            if (detailRs.next()) {
                // Event header
                Paragraph eventHeader = new Paragraph("Event: " + detailRs.getString("title"), SUBHEADER_FONT);
                eventHeader.setSpacingAfter(5f);
                document.add(eventHeader);
                
                PdfPTable detailTable = new PdfPTable(2);
                detailTable.setWidthPercentage(100);
                detailTable.setSpacingBefore(5f);
                detailTable.setSpacingAfter(10f);
                detailTable.setWidths(new float[]{1, 2});
                
                addTableRow(detailTable, "Event ID:", eventId); // Changed to use String directly
                addTableRow(detailTable, "Organizer:", 
                    detailRs.getString("firstname") + " " + detailRs.getString("lastname"));
                addTableRow(detailTable, "Contact:", 
                    detailRs.getString("email") + " / " + detailRs.getString("mobile"));
                addTableRow(detailTable, "Venue:", detailRs.getString("venue"));
                addTableRow(detailTable, "Event Date:", 
                    new SimpleDateFormat("MMM dd, yyyy HH:mm")
                        .format(detailRs.getTimestamp("event_date")));
                addTableRow(detailTable, "Ticket Price:", 
                    "₹" + currencyFormat.format(detailRs.getDouble("price")));
                addTableRow(detailTable, "Capacity:", String.valueOf(detailRs.getInt("capacity")));
                addTableRow(detailTable, "Tickets Sold:", String.valueOf(detailRs.getInt("tickets_sold")));
                addTableRow(detailTable, "Unsold Tickets:", String.valueOf(detailRs.getInt("unsold_tickets")));
                addTableRow(detailTable, "Occupancy Rate:", 
                    percentFormat.format(detailRs.getDouble("occupancy_rate") / 100));
                addTableRow(detailTable, "Actual Revenue:", 
                    "₹" + currencyFormat.format(detailRs.getDouble("actual_revenue")));
                addTableRow(detailTable, "Potential Revenue:", 
                    "₹" + currencyFormat.format(detailRs.getDouble("potential_revenue")));
                addTableRow(detailTable, "Potential Loss:", 
                    "₹" + currencyFormat.format(detailRs.getDouble("potential_loss")));
                addTableRow(detailTable, "Revenue Gap:", 
                    "₹" + currencyFormat.format(detailRs.getDouble("revenue_gap")));
                addTableRow(detailTable, "Status:", detailRs.getString("status"));
                
                document.add(detailTable);
                addEmptyLine(document, 1);
            }
        }
    }
    
    // NEW: Selected Events Summary - UPDATED TO USE List<String>
    private void addSelectedEventsSummary(Document document, List<String> eventIds) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Selected Events Financial Summary", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (eventIds.isEmpty()) {
            document.add(new Paragraph("No events selected for summary.", NORMAL_FONT));
            return;
        }
        
        String placeholders = String.join(",", Collections.nCopies(eventIds.size(), "?"));
        String summarySql = "SELECT " +
            "COUNT(*) as event_count, " +
            "SUM(tickets_sold) as total_tickets_sold, " +
            "SUM(capacity - tickets_sold) as total_unsold_tickets, " +
            "SUM(revenue) as total_actual_revenue, " +
            "SUM((capacity - tickets_sold) * price) as total_potential_loss, " +
            "SUM(tickets_sold * price) as total_potential_revenue, " +
            "AVG((tickets_sold / capacity) * 100) as avg_occupancy_rate " +
            "FROM events WHERE event_id IN (" + placeholders + ")";
        
        PreparedStatement summaryStmt = con.prepareStatement(summarySql);
        for (int i = 0; i < eventIds.size(); i++) {
            summaryStmt.setString(i + 1, eventIds.get(i)); // Changed to setString
        }
        
        ResultSet summaryRs = summaryStmt.executeQuery();
        
        if (summaryRs.next()) {
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingBefore(10f);
            summaryTable.setWidths(new float[]{1, 2});
            
            int eventCount = summaryRs.getInt("event_count");
            int totalSold = summaryRs.getInt("total_tickets_sold");
            int totalUnsold = summaryRs.getInt("total_unsold_tickets");
            double totalActual = summaryRs.getDouble("total_actual_revenue");
            double totalLoss = summaryRs.getDouble("total_potential_loss");
            double totalPotential = summaryRs.getDouble("total_potential_revenue");
            double avgOccupancy = summaryRs.getDouble("avg_occupancy_rate");
            
            addTableRow(summaryTable, "Number of Events:", String.valueOf(eventCount));
            addTableRow(summaryTable, "Total Tickets Sold:", String.valueOf(totalSold));
            addTableRow(summaryTable, "Total Unsold Tickets:", String.valueOf(totalUnsold));
            addTableRow(summaryTable, "Total Actual Revenue:", "₹" + currencyFormat.format(totalActual));
            addTableRow(summaryTable, "Total Potential Loss:", "₹" + currencyFormat.format(totalLoss));
            addTableRow(summaryTable, "Total Potential Revenue:", "₹" + currencyFormat.format(totalPotential));
            addTableRow(summaryTable, "Average Occupancy Rate:", percentFormat.format(avgOccupancy / 100));
            addTableRow(summaryTable, "Revenue Efficiency:", 
                percentFormat.format((totalActual / totalPotential)));
            addTableRow(summaryTable, "Loss Percentage:", 
                percentFormat.format((totalLoss / totalPotential)));
            
            document.add(summaryTable);
        }
    }
    
    // NEW: Financial Highlights
    private void addFinancialHighlights(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Key Financial Highlights", SUBHEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        // Get top performing events
        String topEventsSql = "SELECT title, revenue FROM events WHERE status = 'Approved' ORDER BY revenue DESC LIMIT 3";
        PreparedStatement topEventsStmt = con.prepareStatement(topEventsSql);
        ResultSet topEventsRs = topEventsStmt.executeQuery();
        
        Paragraph highlights = new Paragraph();
        highlights.add(new Chunk("Top Performing Events:\n", BOLD_FONT));
        
        int count = 1;
        while (topEventsRs.next()) {
            highlights.add(new Chunk(String.format("%d. %s - ₹%s\n", 
                count++, topEventsRs.getString("title"), currencyFormat.format(topEventsRs.getDouble("revenue"))), NORMAL_FONT));
        }
        
        highlights.setSpacingAfter(10f);
        document.add(highlights);
    }
    
    // NEW: Financial Recommendations
    private void addFinancialRecommendations(Document document) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("Strategic Recommendations", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        // Analyze data for recommendations
        String recSql = "SELECT " +
            "AVG((tickets_sold / capacity) * 100) as overall_occupancy, " +
            "SUM(CASE WHEN (tickets_sold / capacity) * 100 < 50 THEN 1 ELSE 0 END) as low_occupancy_events, " +
            "COUNT(*) as total_events " +
            "FROM events WHERE status = 'Approved'";
        
        PreparedStatement recStmt = con.prepareStatement(recSql);
        ResultSet recRs = recStmt.executeQuery();
        
        if (recRs.next()) {
            double overallOccupancy = recRs.getDouble("overall_occupancy");
            int lowOccupancyEvents = recRs.getInt("low_occupancy_events");
            int totalEvents = recRs.getInt("total_events");
            double lowOccupancyPercentage = (lowOccupancyEvents / (double) totalEvents) * 100;
            
            Paragraph recommendations = new Paragraph();
            recommendations.add(new Chunk("Based on the financial analysis:\n\n", BOLD_FONT));
            
            if (overallOccupancy < 60) {
                recommendations.add(new Chunk("• Consider revising pricing strategies for underperforming events\n", NORMAL_FONT));
            }
            
            if (lowOccupancyPercentage > 30) {
                recommendations.add(new Chunk("• " + String.format("%.1f%%", lowOccupancyPercentage) + 
                    " of events have occupancy below 50% - review marketing strategies\n", NORMAL_FONT));
            }
            
            recommendations.add(new Chunk("• Focus on events with proven high occupancy rates for future planning\n", NORMAL_FONT));
            recommendations.add(new Chunk("• Implement dynamic pricing for popular events to maximize revenue\n", NORMAL_FONT));
            recommendations.add(new Chunk("• Consider package deals or promotions for low-occupancy time slots\n", NORMAL_FONT));
            
            document.add(recommendations);
        }
    }
    
    // NEW: Organizer Financial Performance
    private void addOrganizerFinancialPerformance(Document document, String organizerId) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Financial Performance Analysis", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        String financialSql = "SELECT " +
            "COUNT(*) as total_events, " +
            "SUM(tickets_sold) as total_tickets_sold, " +
            "SUM(capacity) as total_capacity, " +
            "SUM(revenue) as total_revenue, " +
            "AVG((tickets_sold / capacity) * 100) as avg_occupancy_rate, " +
            "SUM((capacity - tickets_sold) * price) as total_potential_loss, " +
            "MAX(revenue) as highest_revenue, " +
            "MIN(revenue) as lowest_revenue " +
            "FROM events " +
            "WHERE organizer_id = ? AND status = 'Approved'";
        
        PreparedStatement financialStmt = con.prepareStatement(financialSql);
        financialStmt.setString(1, organizerId);
        ResultSet financialRs = financialStmt.executeQuery();
        
        if (financialRs.next()) {
            PdfPTable financialTable = new PdfPTable(2);
            financialTable.setWidthPercentage(100);
            financialTable.setSpacingBefore(10f);
            financialTable.setWidths(new float[]{1, 2});
            
            addTableRow(financialTable, "Total Events:", String.valueOf(financialRs.getInt("total_events")));
            addTableRow(financialTable, "Total Tickets Sold:", String.valueOf(financialRs.getInt("total_tickets_sold")));
            addTableRow(financialTable, "Total Capacity:", String.valueOf(financialRs.getInt("total_capacity")));
            addTableRow(financialTable, "Total Revenue:", "₹" + currencyFormat.format(financialRs.getDouble("total_revenue")));
            addTableRow(financialTable, "Average Occupancy Rate:", 
                percentFormat.format(financialRs.getDouble("avg_occupancy_rate") / 100));
            addTableRow(financialTable, "Total Potential Loss:", 
                "₹" + currencyFormat.format(financialRs.getDouble("total_potential_loss")));
            addTableRow(financialTable, "Highest Revenue Event:", 
                "₹" + currencyFormat.format(financialRs.getDouble("highest_revenue")));
            addTableRow(financialTable, "Lowest Revenue Event:", 
                "₹" + currencyFormat.format(financialRs.getDouble("lowest_revenue")));
            addTableRow(financialTable, "Revenue Efficiency:", 
                percentFormat.format(
                    (financialRs.getDouble("total_revenue") / 
                     (financialRs.getDouble("total_revenue") + financialRs.getDouble("total_potential_loss")))));
            
            document.add(financialTable);
        }
    }

    // Helper methods
    private void addMetadata(Document document, String title) {
        document.addTitle(title);
        document.addSubject("Generated Report");
        document.addKeywords("Event Management, Report, PDF, Financial Analysis");
        document.addAuthor("Event Management System");
        document.addCreator("Event Management System");
    }
    
    private void addTitlePage(Document document, String title) throws DocumentException {
        addTitlePage(document, title, "");
    }
    
    private void addTitlePage(Document document, String title, String subtitle) throws DocumentException {
        // Main title
        Paragraph mainTitle = new Paragraph(title, TITLE_FONT);
        mainTitle.setAlignment(Element.ALIGN_CENTER);
        mainTitle.setSpacingAfter(10f);
        document.add(mainTitle);
        
        // Subtitle
        if (!subtitle.isEmpty()) {
            Paragraph subTitle = new Paragraph(subtitle, SUBHEADER_FONT);
            subTitle.setAlignment(Element.ALIGN_CENTER);
            subTitle.setSpacingAfter(20f);
            document.add(subTitle);
        }
        
        // Timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        Paragraph timeParagraph = new Paragraph("Generated on: " + timestamp, NORMAL_FONT);
        timeParagraph.setAlignment(Element.ALIGN_CENTER);
        timeParagraph.setSpacingAfter(30f);
        document.add(timeParagraph);
        
        addEmptyLine(document, 2);
    }
    
    private void addOrganizerInfoSection(Document document, ResultSet organizerRs) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Organizer Information", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        // Create organizer info table
        PdfPTable infoTable = new PdfPTable(2);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10f);
        infoTable.setSpacingAfter(20f);
        
        // Set column widths
        infoTable.setWidths(new float[]{1, 2});
        
        addTableRow(infoTable, "Organizer ID:", organizerRs.getString("organizer_id"));
        addTableRow(infoTable, "Name:", organizerRs.getString("firstname") + " " + organizerRs.getString("lastname"));
        addTableRow(infoTable, "Email:", organizerRs.getString("email"));
        addTableRow(infoTable, "Mobile:", organizerRs.getString("mobile"));
        addTableRow(infoTable, "Company:", 
            organizerRs.getString("company_name") != null ? organizerRs.getString("company_name") : "N/A");
        addTableRow(infoTable, "Address:", 
            organizerRs.getString("address") != null ? organizerRs.getString("address") : "N/A");
        addTableRow(infoTable, "Verified:", organizerRs.getBoolean("verified") ? "Yes" : "No");
        addTableRow(infoTable, "Registration Date:", 
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(organizerRs.getTimestamp("created_at")));
        
        document.add(infoTable);
    }
    
    private void addOrganizerEventsSummarySection(Document document, String organizerId) 
            throws SQLException, DocumentException {
        
        String summarySql = "SELECT " +
            "COUNT(*) as total_events, " +
            "SUM(tickets_sold) as total_tickets, " +
            "SUM(revenue) as total_revenue, " +
            "AVG(revenue) as avg_revenue, " +
            "SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved_events, " +
            "SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_events " +
            "FROM events WHERE organizer_id = ?";
        
        PreparedStatement summaryStmt = con.prepareStatement(summarySql);
        summaryStmt.setString(1, organizerId);
        ResultSet summaryRs = summaryStmt.executeQuery();
        
        if (summaryRs.next()) {
            Paragraph sectionHeader = new Paragraph("Events Summary", HEADER_FONT);
            sectionHeader.setSpacingAfter(10f);
            document.add(sectionHeader);
            
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingBefore(10f);
            summaryTable.setSpacingAfter(20f);
            summaryTable.setWidths(new float[]{1, 2});
            
            addTableRow(summaryTable, "Total Events:", String.valueOf(summaryRs.getInt("total_events")));
            addTableRow(summaryTable, "Approved Events:", String.valueOf(summaryRs.getInt("approved_events")));
            addTableRow(summaryTable, "Pending Events:", String.valueOf(summaryRs.getInt("pending_events")));
            addTableRow(summaryTable, "Total Tickets Sold:", String.valueOf(summaryRs.getInt("total_tickets")));
            addTableRow(summaryTable, "Total Revenue:", "₹" + currencyFormat.format(summaryRs.getDouble("total_revenue")));
            addTableRow(summaryTable, "Average Revenue per Event:", 
                "₹" + currencyFormat.format(summaryRs.getDouble("avg_revenue")));
            
            document.add(summaryTable);
        }
    }
    
    private void addOrganizerEventsTable(Document document, String organizerId) 
            throws SQLException, DocumentException {
        
        String eventsSql = "SELECT * FROM events WHERE organizer_id = ? ORDER BY event_date DESC";
        PreparedStatement eventsStmt = con.prepareStatement(eventsSql);
        eventsStmt.setString(1, organizerId);
        ResultSet eventsRs = eventsStmt.executeQuery();
        
        Paragraph sectionHeader = new Paragraph("Event Details", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (!eventsRs.isBeforeFirst()) {
            Paragraph noData = new Paragraph("No events found for this organizer.", NORMAL_FONT);
            document.add(noData);
            return;
        }
        
        // Create events table
        PdfPTable eventsTable = new PdfPTable(8);
        eventsTable.setWidthPercentage(100);
        eventsTable.setSpacingBefore(10f);
        
        // Set column widths
        eventsTable.setWidths(new float[]{1, 2, 1.5f, 1.5f, 1, 1, 1, 1});
        
        // Add table headers
        addTableHeader(eventsTable, "Event ID");
        addTableHeader(eventsTable, "Title");
        addTableHeader(eventsTable, "Venue");
        addTableHeader(eventsTable, "Category");
        addTableHeader(eventsTable, "Event Date");
        addTableHeader(eventsTable, "Price");
        addTableHeader(eventsTable, "Tickets Sold");
        addTableHeader(eventsTable, "Revenue");
        
        double totalRevenue = 0;
        int totalTickets = 0;
        
        while (eventsRs.next()) {
            eventsTable.addCell(createTableCell(eventsRs.getString("event_id")));
            eventsTable.addCell(createTableCell(eventsRs.getString("title")));
            eventsTable.addCell(createTableCell(eventsRs.getString("venue")));
            
            // Category - assuming you have a category field
            String category = eventsRs.getString("category");
            eventsTable.addCell(createTableCell(category != null ? category : "General"));
            
            String eventDate = new SimpleDateFormat("MMM dd, yyyy HH:mm")
                .format(eventsRs.getTimestamp("event_date"));
            eventsTable.addCell(createTableCell(eventDate));
            
            eventsTable.addCell(createTableCell("₹" + currencyFormat.format(eventsRs.getDouble("price"))));
            
            int ticketsSold = eventsRs.getInt("tickets_sold");
            eventsTable.addCell(createTableCell(String.valueOf(ticketsSold)));
            
            double revenue = eventsRs.getDouble("revenue");
            eventsTable.addCell(createTableCell("₹" + currencyFormat.format(revenue)));
            
            totalTickets += ticketsSold;
            totalRevenue += revenue;
        }
        
        document.add(eventsTable);
        
        // Add summary
        addEmptyLine(document, 1);
        Paragraph summary = new Paragraph();
        summary.add(new Chunk("Summary: ", BOLD_FONT));
        summary.add(new Chunk(String.format("Total Tickets Sold: %d | Total Revenue: ₹%s", 
            totalTickets, currencyFormat.format(totalRevenue)), NORMAL_FONT));
        document.add(summary);
    }
    
    private void addCustomerInfoSection(Document document, ResultSet customerRs) 
            throws SQLException, DocumentException {
        
        Paragraph sectionHeader = new Paragraph("Customer Information", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        PdfPTable infoTable = new PdfPTable(2);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10f);
        infoTable.setSpacingAfter(20f);
        infoTable.setWidths(new float[]{1, 2});
        
        addTableRow(infoTable, "Customer ID:", customerRs.getString("member_id"));
        addTableRow(infoTable, "Username:", customerRs.getString("username"));
        addTableRow(infoTable, "Full Name:", customerRs.getString("firstname") + " " + customerRs.getString("lastname"));
        addTableRow(infoTable, "Gender:", customerRs.getString("gender") != null ? customerRs.getString("gender") : "N/A");
        addTableRow(infoTable, "Email:", customerRs.getString("email"));
        addTableRow(infoTable, "Mobile:", customerRs.getString("mobile"));
        addTableRow(infoTable, "Address:", 
            customerRs.getString("address") != null ? customerRs.getString("address") : "N/A");
        addTableRow(infoTable, "Account Active:", customerRs.getBoolean("active") ? "Yes" : "No");
        addTableRow(infoTable, "Registered On:", 
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(customerRs.getTimestamp("created_at")));
        
        document.add(infoTable);
    }
    
    private void addCustomerBookingHistorySection(Document document, String memberId) 
            throws SQLException, DocumentException {
        
        String bookingsSql = "SELECT b.*, e.title, e.event_date, e.venue, e.status as event_status, " +
                           "p.payment_status, p.payment_method " +
                           "FROM bookings b " +
                           "JOIN events e ON b.event_id = e.event_id " +
                           "LEFT JOIN payments p ON b.booking_id = p.booking_id " +
                           "WHERE b.user_id = ? ORDER BY b.booking_date DESC";
        
        PreparedStatement bookingsStmt = con.prepareStatement(bookingsSql);
        bookingsStmt.setString(1, memberId);
        ResultSet bookingsRs = bookingsStmt.executeQuery();
        
        Paragraph sectionHeader = new Paragraph("Booking History", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (!bookingsRs.isBeforeFirst()) {
            Paragraph noData = new Paragraph("No booking history found for this customer.", NORMAL_FONT);
            document.add(noData);
            return;
        }
        
        PdfPTable bookingsTable = new PdfPTable(7);
        bookingsTable.setWidthPercentage(100);
        bookingsTable.setSpacingBefore(10f);
        bookingsTable.setWidths(new float[]{1, 2, 1.5f, 1, 1, 1.5f, 1.5f});
        
        // Add table headers
        addTableHeader(bookingsTable, "Booking ID");
        addTableHeader(bookingsTable, "Event Name");
        addTableHeader(bookingsTable, "Venue");
        addTableHeader(bookingsTable, "Tickets Booked");
        addTableHeader(bookingsTable, "Total Amount");
        addTableHeader(bookingsTable, "Booking Date");
        addTableHeader(bookingsTable, "Payment Status");
        
        int totalBookings = 0;
        double totalSpent = 0;
        int totalTickets = 0;
        
        while (bookingsRs.next()) {
            // FIXED: Use getString for booking_id since it's likely VARCHAR
            bookingsTable.addCell(createTableCell(bookingsRs.getString("booking_id")));
            bookingsTable.addCell(createTableCell(bookingsRs.getString("title")));
            bookingsTable.addCell(createTableCell(bookingsRs.getString("venue")));
            
            int ticketCount = bookingsRs.getInt("ticket_count");
            bookingsTable.addCell(createTableCell(String.valueOf(ticketCount)));
            
            double amount = bookingsRs.getDouble("total_amount");
            bookingsTable.addCell(createTableCell("₹" + currencyFormat.format(amount)));
            
            String bookingDate = new SimpleDateFormat("MMM dd, yyyy HH:mm")
                .format(bookingsRs.getTimestamp("booking_date"));
            bookingsTable.addCell(createTableCell(bookingDate));
            
            String paymentStatus = bookingsRs.getString("payment_status");
            bookingsTable.addCell(createTableCell(paymentStatus != null ? paymentStatus : "Pending"));
            
            totalBookings++;
            totalTickets += ticketCount;
            totalSpent += amount;
        }
        
        document.add(bookingsTable);
        
        // Add summary
        addEmptyLine(document, 1);
        Paragraph summary = new Paragraph();
        summary.add(new Chunk("Summary: ", BOLD_FONT));
        summary.add(new Chunk(String.format("Total Bookings: %d | Total Tickets: %d | Total Spent: ₹%s", 
            totalBookings, totalTickets, currencyFormat.format(totalSpent)), NORMAL_FONT));
        document.add(summary);
    }
    
    
    private void addOrganizersSummarySection(Document document) throws SQLException, DocumentException {
        String summarySql = "SELECT " +
            "COUNT(*) as total_organizers, " +
            "SUM(verified) as verified_organizers, " +
            "COUNT(*) - SUM(verified) as unverified_organizers " +
            "FROM organizers";
        
        PreparedStatement summaryStmt = con.prepareStatement(summarySql);
        ResultSet summaryRs = summaryStmt.executeQuery();
        
        if (summaryRs.next()) {
            Paragraph sectionHeader = new Paragraph("Organizers Summary", HEADER_FONT);
            sectionHeader.setSpacingAfter(10f);
            document.add(sectionHeader);
            
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingBefore(10f);
            summaryTable.setSpacingAfter(20f);
            summaryTable.setWidths(new float[]{1, 2});
            
            addTableRow(summaryTable, "Total Organizers:", String.valueOf(summaryRs.getInt("total_organizers")));
            addTableRow(summaryTable, "Verified Organizers:", String.valueOf(summaryRs.getInt("verified_organizers")));
            addTableRow(summaryTable, "Unverified Organizers:", String.valueOf(summaryRs.getInt("unverified_organizers")));
            
            document.add(summaryTable);
        }
    }
    
    private void addOrganizersTable(Document document, ResultSet organizersRs) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("All Organizers", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (!organizersRs.isBeforeFirst()) {
            Paragraph noData = new Paragraph("No organizers found in the system.", NORMAL_FONT);
            document.add(noData);
            return;
        }
        
        // Create organizers table
        PdfPTable organizersTable = new PdfPTable(8);
        organizersTable.setWidthPercentage(100);
        organizersTable.setSpacingBefore(10f);
        
        // Set column widths
        organizersTable.setWidths(new float[]{1, 1.5f, 1.5f, 2, 1.5f, 2, 1, 1.5f});
        
        // Add table headers
        addTableHeader(organizersTable, "Organizer ID");
        addTableHeader(organizersTable, "First Name");
        addTableHeader(organizersTable, "Last Name");
        addTableHeader(organizersTable, "Email");
        addTableHeader(organizersTable, "Mobile");
        addTableHeader(organizersTable, "Company");
        addTableHeader(organizersTable, "Verified");
        addTableHeader(organizersTable, "Created Date");
        
        int totalOrganizers = 0;
        int verifiedCount = 0;
        
        while (organizersRs.next()) {
            organizersTable.addCell(createTableCell(organizersRs.getString("organizer_id")));
            organizersTable.addCell(createTableCell(organizersRs.getString("firstname")));
            organizersTable.addCell(createTableCell(organizersRs.getString("lastname")));
            organizersTable.addCell(createTableCell(organizersRs.getString("email")));
            organizersTable.addCell(createTableCell(organizersRs.getString("mobile")));
            
            String company = organizersRs.getString("company_name");
            organizersTable.addCell(createTableCell(company != null ? company : "N/A"));
            
            boolean verified = organizersRs.getBoolean("verified");
            organizersTable.addCell(createTableCell(verified ? "Yes" : "No"));
            
            String createdDate = new SimpleDateFormat("yyyy-MM-dd")
                .format(organizersRs.getTimestamp("created_at"));
            organizersTable.addCell(createTableCell(createdDate));
            
            totalOrganizers++;
            if (verified) verifiedCount++;
        }
        
        document.add(organizersTable);
        
        // Add summary
        addEmptyLine(document, 1);
        Paragraph summary = new Paragraph();
        summary.add(new Chunk("Summary: ", BOLD_FONT));
        summary.add(new Chunk(String.format("Total Organizers: %d | Verified: %d | Unverified: %d", 
            totalOrganizers, verifiedCount, totalOrganizers - verifiedCount), NORMAL_FONT));
        document.add(summary);
    }
    
    private void addUsersSummarySection(Document document) throws SQLException, DocumentException {
        String summarySql = "SELECT " +
            "COUNT(*) as total_users, " +
            "SUM(active) as active_users, " +
            "COUNT(*) - SUM(active) as inactive_users " +
            "FROM members";
        
        PreparedStatement summaryStmt = con.prepareStatement(summarySql);
        ResultSet summaryRs = summaryStmt.executeQuery();
        
        if (summaryRs.next()) {
            Paragraph sectionHeader = new Paragraph("Users Summary", HEADER_FONT);
            sectionHeader.setSpacingAfter(10f);
            document.add(sectionHeader);
            
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setSpacingBefore(10f);
            summaryTable.setSpacingAfter(20f);
            summaryTable.setWidths(new float[]{1, 2});
            
            addTableRow(summaryTable, "Total Users:", String.valueOf(summaryRs.getInt("total_users")));
            addTableRow(summaryTable, "Active Users:", String.valueOf(summaryRs.getInt("active_users")));
            addTableRow(summaryTable, "Inactive Users:", String.valueOf(summaryRs.getInt("inactive_users")));
            
            document.add(summaryTable);
        }
    }
    
    private void addUsersTable(Document document, ResultSet usersRs) throws SQLException, DocumentException {
        Paragraph sectionHeader = new Paragraph("All Users", HEADER_FONT);
        sectionHeader.setSpacingAfter(10f);
        document.add(sectionHeader);
        
        if (!usersRs.isBeforeFirst()) {
            Paragraph noData = new Paragraph("No users found in the system.", NORMAL_FONT);
            document.add(noData);
            return;
        }
        
        // Create users table
        PdfPTable usersTable = new PdfPTable(7);
        usersTable.setWidthPercentage(100);
        usersTable.setSpacingBefore(10f);
        
        // Set column widths
        usersTable.setWidths(new float[]{1, 1.5f, 2, 1.5f, 1, 1, 1.5f});
        
        // Add table headers
        addTableHeader(usersTable, "User ID");
        addTableHeader(usersTable, "Username");
        addTableHeader(usersTable, "Email");
        addTableHeader(usersTable, "Mobile");
        addTableHeader(usersTable, "Gender");
        addTableHeader(usersTable, "Active");
        addTableHeader(usersTable, "Join Date");
        
        int totalUsers = 0;
        int activeCount = 0;
        
        while (usersRs.next()) {
            usersTable.addCell(createTableCell(usersRs.getString("member_id")));
            usersTable.addCell(createTableCell(usersRs.getString("username")));
            usersTable.addCell(createTableCell(usersRs.getString("email")));
            usersTable.addCell(createTableCell(usersRs.getString("mobile")));
            usersTable.addCell(createTableCell(usersRs.getString("gender") != null ? usersRs.getString("gender") : "N/A"));
            
            boolean active = usersRs.getBoolean("active");
            usersTable.addCell(createTableCell(active ? "Yes" : "No"));
            
            String joinDate = new SimpleDateFormat("yyyy-MM-dd")
                .format(usersRs.getTimestamp("created_at"));
            usersTable.addCell(createTableCell(joinDate));
            
            totalUsers++;
            if (active) activeCount++;
        }
        
        document.add(usersTable);
        
        // Add summary
        addEmptyLine(document, 1);
        Paragraph summary = new Paragraph();
        summary.add(new Chunk("Summary: ", BOLD_FONT));
        summary.add(new Chunk(String.format("Total Users: %d | Active: %d | Inactive: %d", 
            totalUsers, activeCount, totalUsers - activeCount), NORMAL_FONT));
        document.add(summary);
    }
    
    // Helper methods
    private void addTableHeader(PdfPTable table, String header) {
        PdfPCell headerCell = new PdfPCell(new Phrase(header, BOLD_FONT));
        headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerCell.setPadding(5);
        table.addCell(headerCell);
    }
    
    private void addTableRow(PdfPTable table, String label, String value) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, BOLD_FONT));
        labelCell.setBackgroundColor(new BaseColor(240, 240, 240));
        labelCell.setPadding(5);
        
        PdfPCell valueCell = new PdfPCell(new Phrase(value != null ? value : "N/A", NORMAL_FONT));
        valueCell.setPadding(5);
        
        table.addCell(labelCell);
        table.addCell(valueCell);
    }
    
    private PdfPCell createTableCell(String content) {
        PdfPCell cell = new PdfPCell(new Phrase(content, NORMAL_FONT));
        cell.setPadding(5);
        return cell;
    }
    
    private void addEmptyLine(Document document, int number) throws DocumentException {
        for (int i = 0; i < number; i++) {
            document.add(new Paragraph(" "));
        }
    }
    
    private void addErrorMessage(Document document, String message) throws DocumentException {
        Font errorFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.RED);
        Paragraph error = new Paragraph(message, errorFont);
        error.setAlignment(Element.ALIGN_CENTER);
        document.add(error);
    }
}