package Connectors;



import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import javax.swing.*;
import java.util.Properties;
import java.util.Random;

import Config.*;
public class OTPCheck {
	ConfigManager cfg = new ConfigManager();

    // Twilio credentials
	String ACCOUNT_SID = cfg.get("ACCOUNT_SID");
	String AUTH_TOKEN = cfg.get("AUTH_TOKEN");
	String TWILIO_NUMBER = cfg.get("TWILIO_NUMBER");
    // Gmail credentials
	String EMAIL_USER = cfg.get("EMAIL_USER");
	String EMAIL_APP_PASSWORD = cfg.get("EMAIL_APP_PASSWORD");
	String EMAIL_HOST = cfg.get("EMAIL_HOST");

    private String generatedOtp;

    public OTPCheck() {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        generatedOtp = String.format("%06d", new Random().nextInt(1000000));
        System.out.println(generatedOtp);
    }

    // Send OTP via mobile
    public boolean sendOtpMobile(String mobileNumber) {
        try {
            Message.creator(new PhoneNumber(mobileNumber), new PhoneNumber(TWILIO_NUMBER),
                    "Your OTP is: " + generatedOtp).create();
            System.out.println("✅ OTP sent to mobile: " + mobileNumber);
            return true;
        } catch (Exception e) {
            System.out.println("❌ Failed mobile OTP: " + e.getMessage());
            return false;
        }
    }

    // Send OTP via email
    public boolean sendOtpEmail(String email) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", EMAIL_HOST);
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");

            Session session = Session.getInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_USER, EMAIL_APP_PASSWORD);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_USER));
            message.addRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(email));
            message.setSubject("Your OTP Code");
            message.setText("Your OTP is: " + generatedOtp);
            //System.out.println(generatedOtp);

            Transport.send(message);
            System.out.println("✅ OTP sent to email: " + email);
            return true;
        } catch (Exception e) {
            System.out.println("❌ Failed email OTP: " + e.getMessage());
            return false;
        }
    }

    // Show floating OTP input dialog
    public boolean verifyOtp() {
        String enteredOtp = JOptionPane.showInputDialog(null,
        		"Enter the OTP "+generatedOtp+" sent to your mobile/email:",
                "OTP Verification",
                JOptionPane.PLAIN_MESSAGE);
                //System.out.println(generatedOtp);

        if (enteredOtp == null) {
            JOptionPane.showMessageDialog(null, "OTP verification cancelled.", "Cancelled",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (enteredOtp.equals(generatedOtp)) {
            JOptionPane.showMessageDialog(null, "✅ OTP Verified Successfully!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "❌ Wrong OTP. Please try again!", "Failed",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    public boolean verifyOtpWithDialog() {
        String enteredOtp = JOptionPane.showInputDialog(null,
                "Enter the OTP "+generatedOtp+" sent to your mobile/email:",
                "OTP Verification",
                JOptionPane.PLAIN_MESSAGE);

        if (enteredOtp == null) {
            JOptionPane.showMessageDialog(null,
                    "OTP verification cancelled.",
                    "Cancelled",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (enteredOtp.equals(generatedOtp)) {
            JOptionPane.showMessageDialog(null,
                    "✅ OTP Verified Successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            return true;
        } else {
            JOptionPane.showMessageDialog(null,
                    "❌ Wrong OTP. Please try again!",
                    "Failed",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }


    // Test main
    public static void main(String[] args) {
        OTPCheck otpService = new OTPCheck();

        String mobile = "+91XXXXXXXXXX";  // Replace with verified number
        String email = "user@example.com"; // Replace with actual email

        boolean mobileSent = false;
        if (!mobile.isEmpty()) {
            mobileSent = otpService.sendOtpMobile(mobile);
        }

        // If mobile fails, fallback to email
        if (!mobileSent && !email.isEmpty()) {
            otpService.sendOtpEmail(email);
        }

        // Show OTP verification dialog
        otpService.verifyOtp();
    }
}

