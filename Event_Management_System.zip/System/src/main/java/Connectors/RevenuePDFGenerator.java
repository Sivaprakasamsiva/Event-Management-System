package Connectors;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.sql.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class RevenuePDFGenerator {
    private Connection con;
    private DecimalFormat currencyFormat;
    private DecimalFormat percentFormat;
    private DecimalFormat numberFormat;

    public RevenuePDFGenerator(Connection con) {
        this.con = con;
        this.currencyFormat = new DecimalFormat("#,##0.00");
        this.percentFormat = new DecimalFormat("0.00%");
        this.numberFormat = new DecimalFormat("#,##0");
    }
    

    // NEW: Comprehensive Analytics Report
    public boolean generateAnalyticsReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            AnalyticsPageEventHandler eventHandler = new AnalyticsPageEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            // 1. Title Page
            addTitlePage(document, "Comprehensive System Analytics Report");
            
            // 2. Executive Summary
            addExecutiveSummary(document);
            
            document.newPage();
            
            // 3. Financial Deep Dive
            addFinancialDeepDive(document);
            
            document.newPage();
            
            // 4. Event Performance Analytics
            addEventPerformanceAnalytics(document);
            
            document.newPage();
            
            // 5. User & Organizer Insights
            addUserOrganizerInsights(document);
            
            document.newPage();
            
            // 6. Booking & Payment Analysis
            addBookingPaymentAnalysis(document);
            
            document.newPage();
            
            // 7. System Usage & Engagement
            addSystemEngagementMetrics(document);
            
            document.newPage();
            
            // 8. Risk Assessment & Recommendations
            addRiskAssessmentRecommendations(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 1. Title Page
    private void addTitlePage(Document document, String title) throws DocumentException {
        // Title
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 28, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph mainTitle = new Paragraph(title, titleFont);
        mainTitle.setAlignment(Element.ALIGN_CENTER);
        mainTitle.setSpacingAfter(30);
        document.add(mainTitle);
        
        // Subtitle
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 16, Font.ITALIC, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Complete Business Intelligence Dashboard", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(40);
        document.add(subtitle);
        
        // Generation Date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(50);
        document.add(date);
        
        // Report Summary
        Font summaryFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.BLACK);
        Paragraph summary = new Paragraph();
        summary.add(new Chunk("This comprehensive report provides detailed insights into:\n\n", summaryFont));
        summary.add(new Chunk("• Financial Performance & Revenue Trends\n", summaryFont));
        summary.add(new Chunk("• Event Success Metrics & Category Analysis\n", summaryFont));
        summary.add(new Chunk("• User Behavior & Organizer Performance\n", summaryFont));
        summary.add(new Chunk("• Booking Patterns & Payment Analytics\n", summaryFont));
        summary.add(new Chunk("• System Engagement & Strategic Recommendations\n", summaryFont));
        summary.setAlignment(Element.ALIGN_LEFT);
        summary.setSpacingAfter(30);
        document.add(summary);
    }

    // 2. Executive Summary
    private void addExecutiveSummary(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Executive Summary Dashboard", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        // Key Metrics Overview
        addKeyMetricsOverview(document);
        
        // Performance Scorecard
        addPerformanceScorecard(document);
        
        // Quick Insights
        addQuickInsights(document);
    }

    private void addKeyMetricsOverview(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Key Performance Indicators", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "(SELECT COUNT(*) FROM events) as total_events, " +
                    "(SELECT COUNT(*) FROM events WHERE status = 'Approved') as approved_events, " +
                    "(SELECT COUNT(*) FROM members) as total_users, " +
                    "(SELECT COUNT(*) FROM organizers) as total_organizers, " +
                    "(SELECT SUM(total_amount) FROM payments WHERE payment_status = 'Success') as total_revenue, " +
                    "(SELECT AVG(tickets_sold * 100.0 / capacity) FROM events WHERE event_date < CURDATE()) as avg_occupancy, " +
                    "(SELECT COUNT(*) FROM bookings WHERE booking_date >= CURDATE() - INTERVAL 30 DAY) as recent_bookings, " +
                    "(SELECT SUM(total_amount) FROM payments WHERE payment_status = 'Success' AND payment_date >= CURDATE() - INTERVAL 30 DAY) as monthly_revenue";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(4);
                table.setWidthPercentage(100);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                // Row 1
                addKpiCell(table, "Total Events", numberFormat.format(rs.getInt("total_events")), "E");
                addKpiCell(table, "Approved Events", numberFormat.format(rs.getInt("approved_events")), "A");
                addKpiCell(table, "Total Users", numberFormat.format(rs.getInt("total_users")), "U");
                addKpiCell(table, "Total Organizers", numberFormat.format(rs.getInt("total_organizers")), "O");
                
                // Row 2 - CHANGED: $ to ₹
                addKpiCell(table, "Total Revenue", "₹" + currencyFormat.format(rs.getDouble("total_revenue")), "₹");
                addKpiCell(table, "Avg Occupancy", percentFormat.format(rs.getDouble("avg_occupancy") / 100), "%");
                addKpiCell(table, "Recent Bookings (30d)", numberFormat.format(rs.getInt("recent_bookings")), "B");
                addKpiCell(table, "Monthly Revenue", "₹" + currencyFormat.format(rs.getDouble("monthly_revenue")), "M");
                
                document.add(table);
            }
        }
    }

    private void addPerformanceScorecard(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Performance Scorecard", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "ROUND((SELECT COUNT(*) FROM events WHERE status = 'Approved') * 100.0 / COUNT(*), 2) as approval_rate, " +
                    "ROUND((SELECT COUNT(*) FROM payments WHERE payment_status = 'Success') * 100.0 / COUNT(*), 2) as payment_success_rate, " +
                    "ROUND(AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)), 2) as overall_occupancy_rate, " +
                    "ROUND((SELECT COUNT(DISTINCT user_id) FROM bookings WHERE booking_date >= CURDATE() - INTERVAL 90 DAY) * 100.0 / NULLIF((SELECT COUNT(*) FROM members), 0), 2) as user_engagement_rate, " +
                    "ROUND((SELECT COUNT(*) FROM organizers WHERE verified = 1) * 100.0 / NULLIF((SELECT COUNT(*) FROM organizers), 0), 2) as organizer_verification_rate " +
                    "FROM events";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(80);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addScorecardRow(table, "Event Approval Rate", rs.getDouble("approval_rate"), "%");
                addScorecardRow(table, "Payment Success Rate", rs.getDouble("payment_success_rate"), "%");
                addScorecardRow(table, "Overall Occupancy Rate", rs.getDouble("overall_occupancy_rate"), "%");
                addScorecardRow(table, "User Engagement Rate", rs.getDouble("user_engagement_rate"), "%");
                addScorecardRow(table, "Organizer Verification Rate", rs.getDouble("organizer_verification_rate"), "%");
                
                document.add(table);
            }
        }
    }

    private void addQuickInsights(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Quick Insights", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        List<String> insights = generateQuickInsights();
        
        for (String insight : insights) {
            Font insightFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
            Paragraph insightPara = new Paragraph("• " + insight, insightFont);
            insightPara.setSpacingAfter(5);
            document.add(insightPara);
        }
    }

    // 3. Financial Deep Dive
    private void addFinancialDeepDive(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Financial Deep Dive Analysis", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        // Revenue Trends
        addRevenueTrends(document);
        
        // Category Performance
        addCategoryPerformance(document);
        
        // Profit & Loss Analysis
        addProfitLossAnalysis(document);
    }

    private void addRevenueTrends(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Revenue Trends & Patterns", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DATE_FORMAT(p.payment_date, '%Y-%m') as month, " +
                    "SUM(p.total_amount) as revenue, " +
                    "COUNT(DISTINCT p.booking_id) as successful_transactions, " +
                    "AVG(p.total_amount) as avg_transaction_value, " +
                    "COUNT(DISTINCT b.user_id) as unique_customers " +
                    "FROM payments p " +
                    "JOIN bookings b ON p.booking_id = b.booking_id " +
                    "WHERE p.payment_status = 'Success' " +
                    "GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m') " +
                    "ORDER BY month DESC " +
                    "LIMIT 12";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Month");
        addTableHeader(table, "Revenue");
        addTableHeader(table, "Transactions");
        addTableHeader(table, "Avg Transaction");
        addTableHeader(table, "Unique Customers");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("month")));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("successful_transactions")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_transaction_value")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("unique_customers")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    private void addCategoryPerformance(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Event Category Performance", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "category, " +
                    "COUNT(*) as event_count, " +
                    "SUM(revenue) as total_revenue, " +
                    "AVG(revenue) as avg_revenue_per_event, " +
                    "AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)) as avg_occupancy_rate, " +
                    "SUM(tickets_sold) as total_tickets_sold " +
                    "FROM events " +
                    "WHERE category IS NOT NULL " +
                    "GROUP BY category " +
                    "ORDER BY total_revenue DESC";
        
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Category");
        addTableHeader(table, "Events");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Revenue");
        addTableHeader(table, "Avg Occupancy");
        addTableHeader(table, "Tickets Sold");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("category")));
                table.addCell(createCell(numberFormat.format(rs.getInt("event_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_revenue_per_event")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(rs.getDouble("avg_occupancy_rate") / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("total_tickets_sold")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    private void addProfitLossAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Profit & Loss Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DATE_FORMAT(p.payment_date, '%Y-%m') as month, " +
                    "SUM(p.total_amount) as revenue, " +
                    "SUM(CASE WHEN e.event_date < CURDATE() THEN (e.capacity - e.tickets_sold) * e.price ELSE 0 END) as potential_loss, " +
                    "SUM(p.total_amount) - SUM(CASE WHEN e.event_date < CURDATE() THEN (e.capacity - e.tickets_sold) * e.price ELSE 0 END) as net_profit, " +
                    "CASE WHEN SUM(p.total_amount) > 0 THEN " +
                    "    (SUM(p.total_amount) - SUM(CASE WHEN e.event_date < CURDATE() THEN (e.capacity - e.tickets_sold) * e.price ELSE 0 END)) * 100.0 / SUM(p.total_amount) " +
                    "ELSE 0 END as profit_margin " +
                    "FROM payments p " +
                    "LEFT JOIN bookings b ON p.booking_id = b.booking_id " +
                    "LEFT JOIN events e ON b.event_code = e.event_code " +
                    "WHERE p.payment_status = 'Success' " +
                    "GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m') " +
                    "ORDER BY month DESC " +
                    "LIMIT 12";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Month");
        addTableHeader(table, "Revenue");
        addTableHeader(table, "Potential Loss");
        addTableHeader(table, "Net Profit");
        addTableHeader(table, "Profit Margin");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                double revenue = rs.getDouble("revenue");
                double loss = rs.getDouble("potential_loss");
                double netProfit = rs.getDouble("net_profit");
                double margin = rs.getDouble("profit_margin");
                
                BaseColor profitColor = netProfit >= 0 ? new BaseColor(220, 255, 220) : new BaseColor(255, 220, 220);
                BaseColor marginColor = margin >= 20 ? new BaseColor(220, 255, 220) : 
                                      margin >= 10 ? new BaseColor(255, 255, 220) : new BaseColor(255, 220, 220);
                
                table.addCell(createCell(rs.getString("month")));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(revenue), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(loss), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(netProfit), Element.ALIGN_RIGHT, profitColor));
                table.addCell(createCell(percentFormat.format(margin / 100), Element.ALIGN_RIGHT, marginColor));
            }
        }
        
        document.add(table);
    }

    // 4. Event Performance Analytics
    private void addEventPerformanceAnalytics(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Event Performance Analytics", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        addEventSuccessMetrics(document);
        addTopPerformingEvents(document);
        addBreakEvenAnalysis(document);
    }

    private void addEventSuccessMetrics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Event Success Metrics", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "status, " +
                    "COUNT(*) as count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM events), 2) as percentage, " +
                    "SUM(revenue) as total_revenue, " +
                    "AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)) as avg_occupancy " +
                    "FROM events " +
                    "GROUP BY status " +
                    "ORDER BY count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Count");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Occupancy");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("status");
                BaseColor color = getStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_revenue")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("avg_occupancy") / 100), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }

    private void addTopPerformingEvents(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Top Performing Events", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT e.event_code, e.title, CONCAT(o.firstname, ' ', o.lastname) as organizer, " +
                    "e.revenue, e.tickets_sold, e.capacity, " +
                    "ROUND(e.tickets_sold * 100.0 / NULLIF(e.capacity, 0), 2) as occupancy_rate, " +
                    "e.status, e.category " +
                    "FROM events e " +
                    "JOIN organizers o ON e.organizer_id = o.organizer_id " +
                    "WHERE e.status = 'Approved' AND e.revenue > 0 " +
                    "ORDER BY e.revenue DESC " +
                    "LIMIT 15";
        
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Event Code");
        addTableHeader(table, "Title");
        addTableHeader(table, "Organizer");
        addTableHeader(table, "Category");
        addTableHeader(table, "Revenue");
        addTableHeader(table, "Tickets Sold");
        addTableHeader(table, "Occupancy Rate");
        addTableHeader(table, "Status");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            int rank = 1;
            while (rs.next()) {
                double occupancy = rs.getDouble("occupancy_rate");
                BaseColor occupancyColor = occupancy >= 80 ? new BaseColor(220, 255, 220) : 
                                         occupancy >= 50 ? new BaseColor(255, 255, 220) : new BaseColor(255, 220, 220);
                
                table.addCell(createCell(rs.getString("event_code")));
                table.addCell(createCell(rs.getString("title")));
                table.addCell(createCell(rs.getString("organizer")));
                table.addCell(createCell(rs.getString("category")));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("tickets_sold")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(occupancy / 100), Element.ALIGN_RIGHT, occupancyColor));
                table.addCell(createCell(rs.getString("status"), Element.ALIGN_CENTER, getStatusColor(rs.getString("status"))));
                
                rank++;
            }
        }
        
        document.add(table);
    }

    private void addBreakEvenAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Break-even Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "COUNT(*) as total_events, " +
                    "SUM(CASE WHEN tickets_sold >= break_even_tickets THEN 1 ELSE 0 END) as profitable_events, " +
                    "SUM(CASE WHEN tickets_sold < break_even_tickets THEN 1 ELSE 0 END) as loss_events, " +
                    "ROUND(SUM(CASE WHEN tickets_sold >= break_even_tickets THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as profitability_rate, " +
                    "AVG(CASE WHEN break_even_tickets > 0 THEN tickets_sold * 100.0 / break_even_tickets ELSE 0 END) as avg_break_even_performance " +
                    "FROM events " +
                    "WHERE break_even_tickets > 0 AND event_date < CURDATE()";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(60);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addFinancialMetricRow(table, "Total Events Analyzed", numberFormat.format(rs.getInt("total_events")));
                addFinancialMetricRow(table, "Profitable Events", numberFormat.format(rs.getInt("profitable_events")));
                addFinancialMetricRow(table, "Loss Events", numberFormat.format(rs.getInt("loss_events")));
                addFinancialMetricRow(table, "Profitability Rate", percentFormat.format(rs.getDouble("profitability_rate") / 100));
                addFinancialMetricRow(table, "Avg Break-even Performance", percentFormat.format(rs.getDouble("avg_break_even_performance") / 100));
                
                document.add(table);
            }
        }
    }

    // 5. User & Organizer Insights
    private void addUserOrganizerInsights(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("User & Organizer Insights", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        addUserDemographics(document);
        addOrganizerPerformance(document);
        addUserEngagementMetrics(document);
    }

    private void addUserDemographics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("User Demographics & Behavior", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "gender, " +
                    "COUNT(*) as user_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM members), 2) as percentage, " +
                    "COUNT(CASE WHEN created_at >= CURDATE() - INTERVAL 30 DAY THEN 1 END) as new_users_30d, " +
                    "COUNT(CASE WHEN active = 1 THEN 1 END) as active_users " +
                    "FROM members " +
                    "WHERE gender IS NOT NULL " +
                    "GROUP BY gender " +
                    "ORDER BY user_count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Gender");
        addTableHeader(table, "Total Users");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "New Users (30d)");
        addTableHeader(table, "Active Users");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("gender")));
                table.addCell(createCell(numberFormat.format(rs.getInt("user_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("new_users_30d")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("active_users")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    private void addOrganizerPerformance(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Organizer Performance Rankings", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT o.organizer_id, CONCAT(o.firstname, ' ', o.lastname) as name, o.verified, " +
                    "COUNT(e.event_id) as total_events, " +
                    "SUM(e.revenue) as total_revenue, " +
                    "ROUND(AVG(e.tickets_sold * 100.0 / NULLIF(e.capacity, 0)), 2) as avg_occupancy, " +
                    "ROUND(SUM(CASE WHEN e.status = 'Approved' THEN 1 ELSE 0 END) * 100.0 / COUNT(e.event_id), 2) as success_rate " +
                    "FROM organizers o " +
                    "LEFT JOIN events e ON o.organizer_id = e.organizer_id " +
                    "GROUP BY o.organizer_id, o.firstname, o.lastname, o.verified " +
                    "HAVING total_events > 0 " +
                    "ORDER BY total_revenue DESC " +
                    "LIMIT 15";
        
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Organizer");
        addTableHeader(table, "Verified");
        addTableHeader(table, "Total Events");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Occupancy");
        addTableHeader(table, "Success Rate");
        addTableHeader(table, "Performance Tier");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            int rank = 1;
            while (rs.next()) {
                double revenue = rs.getDouble("total_revenue");
                double successRate = rs.getDouble("success_rate");
                String performanceTier = getPerformanceTier(revenue, successRate);
                BaseColor tierColor = getTierColor(performanceTier);
                
                table.addCell(createCell(rs.getString("name")));
                table.addCell(createCell(rs.getBoolean("verified") ? "Yes" : "No", Element.ALIGN_CENTER, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("total_events")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(revenue), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(rs.getDouble("avg_occupancy") / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(successRate / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(performanceTier, Element.ALIGN_CENTER, tierColor));
                
                rank++;
            }
        }
        
        document.add(table);
    }

    private void addUserEngagementMetrics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("User Engagement Metrics", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "COUNT(*) as total_users, " +
                    "COUNT(DISTINCT b.user_id) as users_with_bookings, " +
                    "ROUND(COUNT(DISTINCT b.user_id) * 100.0 / COUNT(*), 2) as booking_engagement_rate, " +
                    "AVG(booking_count) as avg_bookings_per_user, " +
                    "MAX(booking_count) as max_bookings " +
                    "FROM members m " +
                    "LEFT JOIN (SELECT user_id, COUNT(*) as booking_count FROM bookings GROUP BY user_id) b ON m.member_id = b.user_id";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(60);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addFinancialMetricRow(table, "Total Users", numberFormat.format(rs.getInt("total_users")));
                addFinancialMetricRow(table, "Users with Bookings", numberFormat.format(rs.getInt("users_with_bookings")));
                addFinancialMetricRow(table, "Booking Engagement Rate", percentFormat.format(rs.getDouble("booking_engagement_rate") / 100));
                addFinancialMetricRow(table, "Avg Bookings per User", numberFormat.format(rs.getDouble("avg_bookings_per_user")));
                addFinancialMetricRow(table, "Max Bookings by Single User", numberFormat.format(rs.getInt("max_bookings")));
                
                document.add(table);
            }
        }
    }

    // 6. Booking & Payment Analysis
    private void addBookingPaymentAnalysis(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Booking & Payment Analysis", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        addBookingPatterns(document);
        addPaymentAnalytics(document);
        addCancellationAnalysis(document);
    }

    private void addBookingPatterns(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Booking Patterns & Trends", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DAYNAME(booking_date) as day_of_week, " +
                    "COUNT(*) as booking_count, " +
                    "AVG(ticket_count) as avg_tickets_per_booking, " +
                    "AVG(total_amount) as avg_booking_value, " +
                    "COUNT(DISTINCT user_id) as unique_customers " +
                    "FROM bookings " +
                    "GROUP BY DAYNAME(booking_date), DAYOFWEEK(booking_date) " +
                    "ORDER BY DAYOFWEEK(booking_date)";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Day of Week");
        addTableHeader(table, "Booking Count");
        addTableHeader(table, "Avg Tickets");
        addTableHeader(table, "Avg Value");
        addTableHeader(table, "Unique Customers");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("day_of_week")));
                table.addCell(createCell(numberFormat.format(rs.getInt("booking_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getDouble("avg_tickets_per_booking")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_booking_value")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("unique_customers")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    private void addPaymentAnalytics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Payment Analytics", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "payment_status, " +
                    "COUNT(*) as transaction_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM payments), 2) as percentage, " +
                    "SUM(total_amount) as total_amount, " +
                    "AVG(total_amount) as avg_amount " +
                    "FROM payments " +
                    "GROUP BY payment_status " +
                    "ORDER BY transaction_count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Transactions");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Amount");
        addTableHeader(table, "Avg Amount");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("payment_status");
                BaseColor color = getPaymentStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("transaction_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }
    

    private void addCancellationAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Cancellation & Refund Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "b.status, " +
                    "COUNT(*) as booking_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM bookings), 2) as percentage, " +
                    "SUM(b.total_amount) as total_amount, " +
                    "AVG(b.total_amount) as avg_amount " +
                    "FROM bookings b " +
                    "GROUP BY b.status " +
                    "ORDER BY booking_count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Booking Count");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Amount");
        addTableHeader(table, "Avg Amount");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("status");
                BaseColor color = getBookingStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("booking_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }
    

    // 7. System Usage & Engagement
    private void addSystemEngagementMetrics(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("System Usage & Engagement", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        addChatSystemMetrics(document);
        addPlatformEngagement(document);
    }

    private void addChatSystemMetrics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Chat System Engagement", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "room_type, " +
                    "COUNT(*) as room_count, " +
                    "COUNT(DISTINCT organizer_id) as unique_organizers, " +
                    "COUNT(DISTINCT customer_id) as unique_customers " +
                    "FROM chat_rooms " +
                    "GROUP BY room_type";
        
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Room Type");
        addTableHeader(table, "Room Count");
        addTableHeader(table, "Unique Organizers");
        addTableHeader(table, "Unique Customers");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("room_type")));
                table.addCell(createCell(numberFormat.format(rs.getInt("room_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("unique_organizers")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("unique_customers")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
        
        // Add total messages separately
        addTotalMessagesCount(document);
    }

    // NEW: Separate method to get total messages count
    private void addTotalMessagesCount(Document document) throws DocumentException, SQLException {
        String sql = "SELECT COUNT(*) as total_messages FROM messages";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                Font messageFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.DARK_GRAY);
                Paragraph messageCount = new Paragraph("Total Messages in System: " + numberFormat.format(rs.getInt("total_messages")), messageFont);
                messageCount.setSpacingAfter(10);
                document.add(messageCount);
            }
        }
    }
    
    private void addPlatformEngagement(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Platform Engagement Overview", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "(SELECT COUNT(*) FROM events WHERE created_at >= CURDATE() - INTERVAL 30 DAY) as new_events_30d, " +
                    "(SELECT COUNT(*) FROM bookings WHERE booking_date >= CURDATE() - INTERVAL 30 DAY) as new_bookings_30d, " +
                    "(SELECT COUNT(*) FROM members WHERE created_at >= CURDATE() - INTERVAL 30 DAY) as new_users_30d, " +
                    "(SELECT COUNT(*) FROM organizers WHERE created_at >= CURDATE() - INTERVAL 30 DAY) as new_organizers_30d, " +
                    "(SELECT COUNT(*) FROM messages WHERE created_at >= CURDATE() - INTERVAL 30 DAY) as new_messages_30d";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(60);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addFinancialMetricRow(table, "New Events (30 days)", numberFormat.format(rs.getInt("new_events_30d")));
                addFinancialMetricRow(table, "New Bookings (30 days)", numberFormat.format(rs.getInt("new_bookings_30d")));
                addFinancialMetricRow(table, "New Users (30 days)", numberFormat.format(rs.getInt("new_users_30d")));
                addFinancialMetricRow(table, "New Organizers (30 days)", numberFormat.format(rs.getInt("new_organizers_30d")));
                addFinancialMetricRow(table, "New Messages (30 days)", numberFormat.format(rs.getInt("new_messages_30d")));
                
                document.add(table);
            }
        }
    }

    // 8. Risk Assessment & Recommendations
    private void addRiskAssessmentRecommendations(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Risk Assessment & Strategic Recommendations", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        addRiskAssessment(document);
        addStrategicRecommendations(document);
        addActionPlan(document);
    }

    private void addRiskAssessment(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Risk Assessment", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "COUNT(CASE WHEN e.tickets_sold < e.break_even_tickets AND e.event_date < CURDATE() THEN 1 END) as loss_making_events, " +
                    "COUNT(CASE WHEN e.status = 'Rejected' THEN 1 END) as rejected_events, " +
                    "COUNT(CASE WHEN e.available_tickets = e.capacity AND e.event_date >= CURDATE() THEN 1 END) as risky_upcoming_events, " +
                    "COUNT(CASE WHEN p.payment_status = 'Failed' THEN 1 END) as failed_payments " +
                    "FROM events e " +
                    "LEFT JOIN bookings b ON e.event_code = b.event_code " +
                    "LEFT JOIN payments p ON b.booking_id = p.booking_id";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(60);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addRiskMetricRow(table, "Loss-Making Events", numberFormat.format(rs.getInt("loss_making_events")), true);
                addRiskMetricRow(table, "Rejected Events", numberFormat.format(rs.getInt("rejected_events")), true);
                addRiskMetricRow(table, "Risky Upcoming Events", numberFormat.format(rs.getInt("risky_upcoming_events")), true);
                addRiskMetricRow(table, "Failed Payments", numberFormat.format(rs.getInt("failed_payments")), true);
                
                document.add(table);
            }
        }
    }
    
    private void addStrategicRecommendations(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Strategic Recommendations", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        List<String> recommendations = generateRecommendations();
        
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Area");
        addTableHeader(table, "Recommendation");
        
        for (String recommendation : recommendations) {
            String[] parts = recommendation.split("\\|");
            if (parts.length == 2) {
                table.addCell(createCell(parts[0], Element.ALIGN_LEFT, new BaseColor(240, 248, 255)));
                table.addCell(createCell(parts[1], Element.ALIGN_LEFT, new BaseColor(255, 255, 240)));
            }
        }
        
        document.add(table);
    }

    private void addActionPlan(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Immediate Action Plan", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        List<String> actions = generateActionPlan();
        
        for (String action : actions) {
            Font actionFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
            Paragraph actionPara = new Paragraph("• " + action, actionFont);
            actionPara.setSpacingAfter(5);
            document.add(actionPara);
        }
    }

    // Helper Methods
    private void addKpiCell(PdfPTable table, String label, String value, String icon) {
        PdfPCell cell = new PdfPCell();
        cell.setBorder(Rectangle.BOX);
        cell.setBorderWidth(1);
        cell.setBorderColor(BaseColor.LIGHT_GRAY);
        cell.setPadding(10);
        cell.setBackgroundColor(new BaseColor(245, 248, 255));
        
        Paragraph content = new Paragraph();
        content.setAlignment(Element.ALIGN_CENTER);
        
        Font labelFont = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.DARK_GRAY);
        Font valueFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, new BaseColor(0, 100, 0));
        
        content.add(new Chunk(icon + "\n", labelFont));
        content.add(new Chunk(label + "\n", labelFont));
        content.add(new Chunk(value + "\n", valueFont));
        
        cell.addElement(content);
        table.addCell(cell);
    }

    private void addScorecardRow(PdfPTable table, String metric, double value, String unit) {
        BaseColor color;
        if (value >= 80) color = new BaseColor(200, 255, 200); // Green
        else if (value >= 60) color = new BaseColor(255, 255, 200); // Yellow
        else color = new BaseColor(255, 200, 200); // Red
        
        table.addCell(createCell(metric, Element.ALIGN_LEFT, color));
        table.addCell(createCell(value + unit, Element.ALIGN_RIGHT, color));
    }

    private void addRiskMetricRow(PdfPTable table, String metric, String value, boolean isRisk) {
        BaseColor color = isRisk ? new BaseColor(255, 200, 200) : new BaseColor(200, 255, 200);
        table.addCell(createCell(metric, Element.ALIGN_LEFT, color));
        table.addCell(createCell(value, Element.ALIGN_RIGHT, color));
    }

    private void addFinancialMetricRow(PdfPTable table, String label, String value) {
        table.addCell(createCell(label, Element.ALIGN_LEFT, new BaseColor(240, 248, 255)));
        table.addCell(createCell(value, Element.ALIGN_RIGHT, BaseColor.WHITE));
    }

    private List<String> generateQuickInsights() throws SQLException {
        List<String> insights = new ArrayList<>();
        
        // Add actual data-driven insights
        insights.add("Highest revenue generating category: " + getTopCategory());
        insights.add("Most active day for bookings: " + getBusiestDay());
        insights.add("Top performing organizer: " + getTopOrganizer());
        insights.add("Average event occupancy rate: " + getAvgOccupancy() + "%");
        insights.add("User growth trend: " + getUserGrowthTrend());
        insights.add("Payment success rate: " + getPaymentSuccessRate() + "%");
        
        return insights;
    }

    private List<String> generateRecommendations() throws SQLException {
        List<String> recommendations = new ArrayList<>();
        
        // Data-driven recommendations
        String topCategory = getTopCategory();
        String busyDay = getBusiestDay();
        double paymentSuccess = getPaymentSuccessRate();
        
        recommendations.add("Event Categories|Focus on " + topCategory + " events which generate the highest revenue");
        recommendations.add("Organizer Support|Provide additional training to organizers with low approval rates");
        recommendations.add("User Engagement|Implement loyalty program for repeat customers");
        recommendations.add("Payment Processing|Optimize payment flow to improve current " + paymentSuccess + "% success rate");
        recommendations.add("Marketing|Target promotions on " + busyDay + " when booking activity peaks");
        recommendations.add("Pricing Strategy|Adjust pricing for categories with low occupancy rates");
        recommendations.add("Risk Management|Monitor events with high break-even thresholds closely");
        recommendations.add("Customer Support|Enhance chat system engagement for better customer satisfaction");
        
        return recommendations;
    }

    private List<String> generateActionPlan() throws SQLException {
        List<String> actions = new ArrayList<>();
        
        actions.add("Review and optimize " + getTopCategory() + " event offerings");
        actions.add("Implement organizer training program for quality improvement");
        actions.add("Analyze and address payment failure reasons");
        actions.add("Develop marketing campaign for low-occupancy event categories");
        actions.add("Enhance user onboarding process to improve engagement");
        actions.add("Set up automated alerts for risky events");
        
        return actions;
    }

    // Data retrieval methods for insights
    private String getTopCategory() throws SQLException {
        String sql = "SELECT category FROM events WHERE revenue > 0 GROUP BY category ORDER BY SUM(revenue) DESC LIMIT 1";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString("category") : "N/A";
        }
    }

    private String getBusiestDay() throws SQLException {
        String sql = "SELECT DAYNAME(booking_date) as day FROM bookings GROUP BY DAYNAME(booking_date) ORDER BY COUNT(*) DESC LIMIT 1";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString("day") : "N/A";
        }
    }

    private String getTopOrganizer() throws SQLException {
        String sql = "SELECT CONCAT(o.firstname, ' ', o.lastname) as name FROM organizers o JOIN events e ON o.organizer_id = e.organizer_id GROUP BY o.organizer_id ORDER BY SUM(e.revenue) DESC LIMIT 1";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString("name") : "N/A";
        }
    }

    private String getAvgOccupancy() throws SQLException {
        String sql = "SELECT ROUND(AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)), 1) as avg_occ FROM events WHERE event_date < CURDATE()";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString("avg_occ") : "N/A";
        }
    }

    private String getUserGrowthTrend() throws SQLException {
        String sql = "SELECT ROUND((COUNT(CASE WHEN created_at >= CURDATE() - INTERVAL 30 DAY THEN 1 END) * 100.0 / NULLIF(COUNT(CASE WHEN created_at < CURDATE() - INTERVAL 30 DAY THEN 1 END), 0)), 1) as growth FROM members";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getDouble("growth") + "% monthly growth" : "Stable";
        }
    }

    private double getPaymentSuccessRate() throws SQLException {
        String sql = "SELECT ROUND(COUNT(CASE WHEN payment_status = 'Success' THEN 1 END) * 100.0 / COUNT(*), 1) as success_rate FROM payments";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getDouble("success_rate") : 0;
        }
    }

    private String getPerformanceTier(double revenue, double successRate) {
        if (revenue > 10000 && successRate > 80) return "Elite";
        if (revenue > 5000 && successRate > 70) return "Premium";
        if (revenue > 1000 && successRate > 60) return "Standard";
        return "Basic";
    }

    private BaseColor getTierColor(String tier) {
        switch (tier) {
            case "Elite": return new BaseColor(200, 255, 200);
            case "Premium": return new BaseColor(255, 255, 200);
            case "Standard": return new BaseColor(255, 230, 200);
            default: return new BaseColor(255, 200, 200);
        }
    }

    private BaseColor getStatusColor(String status) {
        if (status == null) return BaseColor.WHITE;
        
        switch (status) {
            case "Approved": return new BaseColor(220, 255, 220);
            case "Pending": return new BaseColor(255, 255, 220);
            case "Rejected": return new BaseColor(255, 220, 220);
            case "Cancelled": return new BaseColor(240, 240, 240);
            default: return BaseColor.WHITE;
        }
    }

    private BaseColor getPaymentStatusColor(String status) {
        if (status == null) return BaseColor.WHITE;
        
        switch (status) {
            case "Success":
                return new BaseColor(220, 255, 220); // Light green
            case "Pending":
                return new BaseColor(255, 255, 220); // Light yellow
            case "Failed":
                return new BaseColor(255, 220, 220); // Light red
            default:
                return BaseColor.WHITE;
        }
    }
    private BaseColor getBookingStatusColor(String status) {
        if (status == null) return BaseColor.WHITE;
        
        switch (status) {
            case "Confirmed":
                return new BaseColor(220, 255, 220); // Light green
            case "Pending":
                return new BaseColor(255, 255, 220); // Light yellow
            case "Cancelled":
                return new BaseColor(255, 220, 220); // Light red
            case "Refunded":
                return new BaseColor(240, 240, 240); // Light gray
            default:
                return BaseColor.WHITE;
        }
    }

    private void addTableHeader(PdfPTable table, String header) {
        PdfPCell cell = new PdfPCell(new Phrase(header));
        cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(8);
        cell.setBorderWidth(1);
        cell.setBorderColor(BaseColor.DARK_GRAY);
        table.addCell(cell);
    }

    private PdfPCell createCell(String content) {
        return createCell(content, Element.ALIGN_LEFT, BaseColor.WHITE);
    }

    private PdfPCell createCell(String content, int alignment, BaseColor backgroundColor) {
        PdfPCell cell = new PdfPCell(new Phrase(content));
        cell.setHorizontalAlignment(alignment);
        cell.setPadding(8);
        cell.setBorderWidth(1);
        cell.setBorderColor(BaseColor.LIGHT_GRAY);
        if (backgroundColor != BaseColor.WHITE) {
            cell.setBackgroundColor(backgroundColor);
        }
        return cell;
    }

    // Page Event Handler for Analytics Report
    private static class AnalyticsPageEventHandler extends PdfPageEventHelper {
        private int pageNumber = 0;
        
        @Override
        public void onStartPage(PdfWriter writer, Document document) {
            pageNumber++;
        }
        
        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            PdfContentByte cb = writer.getDirectContent();
            
            // Footer with page number
            Phrase footer = new Phrase("Page " + pageNumber + " - Comprehensive System Analytics", 
                new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.GRAY));
            
            ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, footer,
                (document.right() - document.left()) / 2 + document.leftMargin(),
                document.bottom() - 20, 0);
        }
    }

    // Keep all your existing methods for other report types
    public boolean generateRevenueReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            
            // Use the proper page event handler
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            // Add proper revenue report title
            addRevenueReportTitle(document);
            
            // Add revenue summary
            addRevenueSummary(document);
            
            document.newPage();
            
            // Add revenue trends
            addRevenueTrends(document);
            
            document.newPage();
            
            // Add financial analysis
            addFinancialAnalysis(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void addRevenueReportTitle(Document document) throws DocumentException {
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("Revenue Analytics Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Financial Performance and Revenue Analysis", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    private void addRevenueSummary(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Revenue Summary", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        String sql = "SELECT " +
                    "SUM(total_amount) as total_revenue, " +
                    "COUNT(*) as total_transactions, " +
                    "AVG(total_amount) as avg_transaction, " +
                    "COUNT(DISTINCT booking_id) as unique_bookings, " +
                    "SUM(CASE WHEN payment_status = 'Success' THEN total_amount ELSE 0 END) as successful_revenue, " +
                    "COUNT(CASE WHEN payment_status = 'Success' THEN 1 END) as successful_transactions " +
                    "FROM payments";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(80);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                // CHANGED: All $ to ₹
                addSummaryRow(table, "Total Revenue", "₹" + currencyFormat.format(rs.getDouble("total_revenue")));
                addSummaryRow(table, "Total Transactions", numberFormat.format(rs.getInt("total_transactions")));
                addSummaryRow(table, "Average Transaction", "₹" + currencyFormat.format(rs.getDouble("avg_transaction")));
                addSummaryRow(table, "Unique Bookings", numberFormat.format(rs.getInt("unique_bookings")));
                addSummaryRow(table, "Successful Revenue", "₹" + currencyFormat.format(rs.getDouble("successful_revenue")));
                addSummaryRow(table, "Successful Transactions", numberFormat.format(rs.getInt("successful_transactions")));
                
                document.add(table);
            }
        }
    }

   
    // NEW: Add monthly revenue trends method
    private void addMonthlyRevenueTrends(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Monthly Revenue Trends", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DATE_FORMAT(payment_date, '%Y-%m') as month, " +
                    "SUM(total_amount) as revenue, " +
                    "COUNT(*) as transaction_count " +
                    "FROM payments " +
                    "WHERE payment_status = 'Success' " +
                    "GROUP BY DATE_FORMAT(payment_date, '%Y-%m') " +
                    "ORDER BY month DESC " +
                    "LIMIT 12";
        
        PdfPTable table = new PdfPTable(3);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Month");
        addTableHeader(table, "Revenue");
        addTableHeader(table, "Transactions");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("month")));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("transaction_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }
    // NEW: Proper revenue report title
    
   
    // NEW: Financial analysis section
    private void addFinancialAnalysis(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Financial Analysis", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        // Add payment status distribution
        addPaymentStatusDistribution(document);
    }
 // Add this method to your RevenuePDFGenerator.java
    private void addPaymentStatusDistribution(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Payment Status Distribution", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "payment_status, " +
                    "COUNT(*) as transaction_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM payments), 2) as percentage, " +
                    "SUM(total_amount) as total_amount, " +
                    "AVG(total_amount) as avg_amount " +
                    "FROM payments " +
                    "GROUP BY payment_status " +
                    "ORDER BY transaction_count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Transactions");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Amount");
        addTableHeader(table, "Avg Amount");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("payment_status");
                BaseColor color = getPaymentStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("transaction_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }
    
    public boolean generateEventsReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            
            // Use the proper page event handler
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            // Add proper events report title
            addEventsReportTitle(document);
            
            // Add events summary
            addEventsSummary(document);
            
            document.newPage();
            
            // Add events table
            addEventsTable(document);
            
            document.newPage();
            
            // Add event performance analysis
            addEventPerformanceAnalysis(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // NEW: Proper events report title
    private void addEventsReportTitle(Document document) throws DocumentException {
        // Title
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("Events Management Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        // Subtitle
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Detailed Events Analysis and Performance Metrics", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        // Generation Date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    // NEW: Events summary section
    private void addEventsSummary(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Events Summary Overview", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        String sql = "SELECT " +
                    "COUNT(*) as total_events, " +
                    "COUNT(CASE WHEN status = 'Approved' THEN 1 END) as approved_events, " +
                    "COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_events, " +
                    "COUNT(CASE WHEN status = 'Rejected' THEN 1 END) as rejected_events, " +
                    "COUNT(CASE WHEN status = 'Cancelled' THEN 1 END) as cancelled_events, " +
                    "SUM(tickets_sold) as total_tickets_sold, " +
                    "SUM(revenue) as total_revenue, " +
                    "AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)) as avg_occupancy_rate " +
                    "FROM events";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(80);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addSummaryRow(table, "Total Events", numberFormat.format(rs.getInt("total_events")));
                addSummaryRow(table, "Approved Events", numberFormat.format(rs.getInt("approved_events")));
                addSummaryRow(table, "Pending Events", numberFormat.format(rs.getInt("pending_events")));
                addSummaryRow(table, "Rejected Events", numberFormat.format(rs.getInt("rejected_events")));
                addSummaryRow(table, "Cancelled Events", numberFormat.format(rs.getInt("cancelled_events")));
                addSummaryRow(table, "Total Tickets Sold", numberFormat.format(rs.getInt("total_tickets_sold")));
                
                double totalRevenue = rs.getDouble("total_revenue");
                // CHANGED: $ to ₹
                String revenueString = rs.wasNull() ? "₹0.00" : "₹" + currencyFormat.format(totalRevenue);
                addSummaryRow(table, "Total Revenue", revenueString);
                
                double avgOccupancy = rs.getDouble("avg_occupancy_rate");
                String occupancyString = rs.wasNull() ? "0%" : percentFormat.format(avgOccupancy / 100);
                addSummaryRow(table, "Average Occupancy Rate", occupancyString);
                
                document.add(table);
            }
        }
    }

    // NEW: Event performance analysis
    private void addEventPerformanceAnalysis(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("Event Performance Analysis", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        // Category performance
        addCategoryPerformance(document);
        
        // Status distribution
        addStatusDistribution(document);
    }

    // NEW: Status distribution
    private void addStatusDistribution(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Event Status Distribution", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "status, " +
                    "COUNT(*) as event_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM events), 2) as percentage, " +
                    "SUM(revenue) as total_revenue, " +
                    "AVG(tickets_sold * 100.0 / NULLIF(capacity, 0)) as avg_occupancy " +
                    "FROM events " +
                    "GROUP BY status " +
                    "ORDER BY event_count DESC";
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Event Count");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Occupancy");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("status");
                BaseColor color = getStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("event_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                // CHANGED: $ to ₹
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_revenue")), Element.ALIGN_RIGHT, color));
                
                double avgOccupancy = rs.getDouble("avg_occupancy");
                String occupancyString = rs.wasNull() ? "N/A" : percentFormat.format(avgOccupancy / 100);
                table.addCell(createCell(occupancyString, Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }

    // Update the existing addEventsTable method to ensure it's called
    private void addEventsTable(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph section = new Paragraph("All Events Details", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        // Table headers
        addTableHeader(table, "Event Code");
        addTableHeader(table, "Title");
        addTableHeader(table, "Organizer");
        addTableHeader(table, "Date");
        addTableHeader(table, "Venue");
        addTableHeader(table, "Tickets Sold");
        addTableHeader(table, "Revenue");
        addTableHeader(table, "Status");
        
        // Fetch events data
        String sql = "SELECT e.event_code, e.title, CONCAT(o.firstname, ' ', o.lastname) as organizer, " +
                     "e.event_date, e.venue, e.tickets_sold, e.revenue, e.status " +
                     "FROM events e " +
                     "JOIN organizers o ON e.organizer_id = o.organizer_id " +
                     "ORDER BY e.event_date DESC";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("event_code")));
                table.addCell(createCell(rs.getString("title")));
                table.addCell(createCell(rs.getString("organizer")));
                
                // Handle null dates gracefully
                java.sql.Timestamp eventDate = rs.getTimestamp("event_date");
                String dateString = eventDate != null ? dateFormat.format(eventDate) : "N/A";
                table.addCell(createCell(dateString));
                
                table.addCell(createCell(rs.getString("venue")));
                table.addCell(createCell(String.valueOf(rs.getInt("tickets_sold"))));
                
                // Handle null revenue gracefully
                double revenue = rs.getDouble("revenue");
                // CHANGED: $ to ₹
                String revenueString = rs.wasNull() ? "₹0.00" : "₹" + currencyFormat.format(revenue);
                table.addCell(createCell(revenueString, Element.ALIGN_RIGHT, BaseColor.WHITE));
                
                // Color code status
                String status = rs.getString("status");
                BaseColor statusColor = getStatusColor(status);
                
                PdfPCell statusCell = createCell(status, Element.ALIGN_CENTER, statusColor);
                table.addCell(statusCell);
            }
        }
        
        document.add(table);
    }

    // Helper method for summary rows
    private void addSummaryRow(PdfPTable table, String label, String value) {
        table.addCell(createCell(label, Element.ALIGN_LEFT, new BaseColor(240, 248, 255)));
        table.addCell(createCell(value, Element.ALIGN_RIGHT, BaseColor.WHITE));
    }
    

 
    

    // Existing Page Number Handler
    private static class PageNumberEventHandler extends PdfPageEventHelper {
        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            PdfContentByte cb = writer.getDirectContent();
            Phrase footer = new Phrase("Page " + writer.getPageNumber(), 
                new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.GRAY));
            
            ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, footer,
                (document.right() - document.left()) / 2 + document.leftMargin(),
                document.bottom() - 10, 0);
        }
    }

    // Add any other existing methods you had in your original RevenuePDFGenerator
    // ... (include all your existing data classes and methods)
    // Additional report generation methods
    public boolean generateUserReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            addUserReportTitle(document);
            addUserDemographics(document);
            
            document.newPage();
            addUserEngagementMetrics(document);
            addUserActivityAnalysis(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean generateOrganizerReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            addOrganizerReportTitle(document);
            addOrganizerPerformance(document);
            
            document.newPage();
            addOrganizerVerificationStatus(document);
            addOrganizerEventStatistics(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // User Report Methods
    private void addUserReportTitle(Document document) throws DocumentException {
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("User Analytics Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("User Demographics and Engagement Analysis", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    private void addUserActivityAnalysis(Document document) throws DocumentException, SQLException {
        Font sectionFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(0, 100, 0));
        Paragraph section = new Paragraph("User Activity Analysis", sectionFont);
        section.setSpacingAfter(20);
        document.add(section);
        
        String sql = "SELECT " +
                    "COUNT(*) as total_users, " +
                    "COUNT(CASE WHEN active = 1 THEN 1 END) as active_users, " +
                    "COUNT(CASE WHEN active = 0 THEN 1 END) as inactive_users, " +
                    "ROUND(COUNT(CASE WHEN active = 1 THEN 1 END) * 100.0 / COUNT(*), 2) as active_percentage, " +
                    "COUNT(CASE WHEN created_at >= CURDATE() - INTERVAL 30 DAY THEN 1 END) as new_users_30d, " +
                    "COUNT(CASE WHEN last_login >= CURDATE() - INTERVAL 30 DAY THEN 1 END) as recent_logins " +
                    "FROM members";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setWidthPercentage(80);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addSummaryRow(table, "Total Users", numberFormat.format(rs.getInt("total_users")));
                addSummaryRow(table, "Active Users", numberFormat.format(rs.getInt("active_users")));
                addSummaryRow(table, "Inactive Users", numberFormat.format(rs.getInt("inactive_users")));
                addSummaryRow(table, "Active Percentage", percentFormat.format(rs.getDouble("active_percentage") / 100));
                addSummaryRow(table, "New Users (30 days)", numberFormat.format(rs.getInt("new_users_30d")));
                addSummaryRow(table, "Recent Logins (30 days)", numberFormat.format(rs.getInt("recent_logins")));
                
                document.add(table);
            }
        }
    }

    // Organizer Report Methods
    private void addOrganizerReportTitle(Document document) throws DocumentException {
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("Organizer Performance Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Organizer Analytics and Event Performance", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    private void addOrganizerVerificationStatus(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Organizer Verification Status", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "verified, " +
                    "COUNT(*) as organizer_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM organizers), 2) as percentage " +
                    "FROM organizers " +
                    "GROUP BY verified " +
                    "ORDER BY organizer_count DESC";
        
        PdfPTable table = new PdfPTable(3);
        table.setWidthPercentage(80);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Verification Status");
        addTableHeader(table, "Count");
        addTableHeader(table, "Percentage");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                boolean verified = rs.getBoolean("verified");
                String status = verified ? "Verified" : "Not Verified";
                BaseColor color = verified ? new BaseColor(220, 255, 220) : new BaseColor(255, 220, 220);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("organizer_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }

    private void addOrganizerEventStatistics(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Organizer Event Statistics", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "o.organizer_id, " +
                    "CONCAT(o.firstname, ' ', o.lastname) as organizer_name, " +
                    "COUNT(e.event_id) as total_events, " +
                    "SUM(e.revenue) as total_revenue, " +
                    "AVG(e.tickets_sold * 100.0 / NULLIF(e.capacity, 0)) as avg_occupancy, " +
                    "SUM(CASE WHEN e.status = 'Approved' THEN 1 ELSE 0 END) as approved_events, " +
                    "SUM(CASE WHEN e.status = 'Pending' THEN 1 ELSE 0 END) as pending_events " +
                    "FROM organizers o " +
                    "LEFT JOIN events e ON o.organizer_id = e.organizer_id " +
                    "GROUP BY o.organizer_id, o.firstname, o.lastname " +
                    "HAVING total_events > 0 " +
                    "ORDER BY total_revenue DESC";
        
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Organizer");
        addTableHeader(table, "Total Events");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Occupancy");
        addTableHeader(table, "Approved Events");
        addTableHeader(table, "Pending Events");
        addTableHeader(table, "Approval Rate");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                int totalEvents = rs.getInt("total_events");
                int approvedEvents = rs.getInt("approved_events");
                double approvalRate = totalEvents > 0 ? (approvedEvents * 100.0 / totalEvents) : 0;
                
                table.addCell(createCell(rs.getString("organizer_name")));
                table.addCell(createCell(numberFormat.format(totalEvents), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(rs.getDouble("avg_occupancy") / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(approvedEvents), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("pending_events")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(percentFormat.format(approvalRate / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    // Booking Report Methods
    public boolean generateBookingReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            addBookingReportTitle(document);
            addBookingPatterns(document);
            
            document.newPage();
            addBookingStatusAnalysis(document);
            addBookingRevenueAnalysis(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void addBookingReportTitle(Document document) throws DocumentException {
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("Booking Analytics Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Booking Patterns and Revenue Analysis", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    private void addBookingStatusAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Booking Status Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "status, " +
                    "COUNT(*) as booking_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM bookings), 2) as percentage, " +
                    "SUM(total_amount) as total_amount, " +
                    "AVG(total_amount) as avg_amount, " +
                    "AVG(ticket_count) as avg_tickets " +
                    "FROM bookings " +
                    "GROUP BY status " +
                    "ORDER BY booking_count DESC";
        
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Status");
        addTableHeader(table, "Booking Count");
        addTableHeader(table, "Percentage");
        addTableHeader(table, "Total Amount");
        addTableHeader(table, "Avg Amount");
        addTableHeader(table, "Avg Tickets");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String status = rs.getString("status");
                BaseColor color = getBookingStatusColor(status);
                
                table.addCell(createCell(status, Element.ALIGN_LEFT, color));
                table.addCell(createCell(numberFormat.format(rs.getInt("booking_count")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, color));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, color));
                table.addCell(createCell(numberFormat.format(rs.getDouble("avg_tickets")), Element.ALIGN_RIGHT, color));
            }
        }
        
        document.add(table);
    }

    private void addBookingRevenueAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Booking Revenue Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DATE_FORMAT(booking_date, '%Y-%m') as month, " +
                    "COUNT(*) as booking_count, " +
                    "SUM(total_amount) as total_revenue, " +
                    "AVG(total_amount) as avg_booking_value, " +
                    "SUM(ticket_count) as total_tickets, " +
                    "COUNT(DISTINCT user_id) as unique_customers " +
                    "FROM bookings " +
                    "WHERE status = 'Confirmed' " +
                    "GROUP BY DATE_FORMAT(booking_date, '%Y-%m') " +
                    "ORDER BY month DESC " +
                    "LIMIT 12";
        
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Month");
        addTableHeader(table, "Bookings");
        addTableHeader(table, "Total Revenue");
        addTableHeader(table, "Avg Value");
        addTableHeader(table, "Total Tickets");
        addTableHeader(table, "Unique Customers");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("month")));
                table.addCell(createCell(numberFormat.format(rs.getInt("booking_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_revenue")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_booking_value")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("total_tickets")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("unique_customers")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    // Payment Report Methods
    public boolean generatePaymentReport(String filePath) {
        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));
            PageNumberEventHandler eventHandler = new PageNumberEventHandler();
            writer.setPageEvent(eventHandler);
            
            document.open();
            
            addPaymentReportTitle(document);
            addPaymentAnalytics(document);
            
            document.newPage();
            addPaymentTrends(document);
            addPaymentMethodAnalysis(document);
            
            document.close();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void addPaymentReportTitle(Document document) throws DocumentException {
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("Payment Analytics Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);
        
        Font subtitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.NORMAL, BaseColor.GRAY);
        Paragraph subtitle = new Paragraph("Payment Processing and Transaction Analysis", subtitleFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(30);
        document.add(subtitle);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy 'at' HH:mm");
        Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
        Paragraph date = new Paragraph("Generated on: " + dateFormat.format(new java.util.Date()), dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(40);
        document.add(date);
    }

    private void addPaymentTrends(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Payment Trends Over Time", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        String sql = "SELECT " +
                    "DATE_FORMAT(payment_date, '%Y-%m') as month, " +
                    "COUNT(*) as transaction_count, " +
                    "SUM(total_amount) as total_amount, " +
                    "AVG(total_amount) as avg_amount, " +
                    "COUNT(CASE WHEN payment_status = 'Success' THEN 1 END) as successful_transactions, " +
                    "COUNT(CASE WHEN payment_status = 'Failed' THEN 1 END) as failed_transactions " +
                    "FROM payments " +
                    "GROUP BY DATE_FORMAT(payment_date, '%Y-%m') " +
                    "ORDER BY month DESC " +
                    "LIMIT 12";
        
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(20);
        
        addTableHeader(table, "Month");
        addTableHeader(table, "Total Transactions");
        addTableHeader(table, "Total Amount");
        addTableHeader(table, "Avg Amount");
        addTableHeader(table, "Successful");
        addTableHeader(table, "Failed");
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                table.addCell(createCell(rs.getString("month")));
                table.addCell(createCell(numberFormat.format(rs.getInt("transaction_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("successful_transactions")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                table.addCell(createCell(numberFormat.format(rs.getInt("failed_transactions")), Element.ALIGN_RIGHT, BaseColor.WHITE));
            }
        }
        
        document.add(table);
    }

    private void addPaymentMethodAnalysis(Document document) throws DocumentException, SQLException {
        Font subsectionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph subsection = new Paragraph("Payment Method Analysis", subsectionFont);
        subsection.setSpacingAfter(15);
        document.add(subsection);
        
        // This assumes you have a payment_method column in your payments table
        // If not, you can remove this method or adapt it to your schema
        String sql = "SELECT " +
                    "payment_method, " +
                    "COUNT(*) as transaction_count, " +
                    "ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM payments), 2) as percentage, " +
                    "SUM(total_amount) as total_amount, " +
                    "AVG(total_amount) as avg_amount, " +
                    "COUNT(CASE WHEN payment_status = 'Success' THEN 1 END) as successful_count " +
                    "FROM payments " +
                    "WHERE payment_method IS NOT NULL " +
                    "GROUP BY payment_method " +
                    "ORDER BY transaction_count DESC";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                PdfPTable table = new PdfPTable(6);
                table.setWidthPercentage(100);
                table.setSpacingBefore(10);
                table.setSpacingAfter(20);
                
                addTableHeader(table, "Payment Method");
                addTableHeader(table, "Transactions");
                addTableHeader(table, "Percentage");
                addTableHeader(table, "Total Amount");
                addTableHeader(table, "Avg Amount");
                addTableHeader(table, "Successful");
                
                do {
                    String method = rs.getString("payment_method");
                    if (method != null) {
                        table.addCell(createCell(method));
                        table.addCell(createCell(numberFormat.format(rs.getInt("transaction_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                        table.addCell(createCell(percentFormat.format(rs.getDouble("percentage") / 100), Element.ALIGN_RIGHT, BaseColor.WHITE));
                        table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("total_amount")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                        table.addCell(createCell("₹" + currencyFormat.format(rs.getDouble("avg_amount")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                        table.addCell(createCell(numberFormat.format(rs.getInt("successful_count")), Element.ALIGN_RIGHT, BaseColor.WHITE));
                    }
                } while (rs.next());
                
                document.add(table);
            } else {
                // If no payment method data, show a message
                Font infoFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);
                Paragraph info = new Paragraph("No payment method data available in the database.", infoFont);
                info.setSpacingAfter(10);
                document.add(info);
            }
        }
    }

    // Utility Methods for Data Export
    public void exportRevenueDataToCSV(String filePath) throws SQLException, IOException {
        String sql = "SELECT " +
                    "p.payment_id, p.booking_id, p.total_amount, p.payment_status, p.payment_date, " +
                    "b.user_id, b.event_code, b.ticket_count, b.total_amount as booking_amount, " +
                    "e.title as event_title, e.category, e.organizer_id " +
                    "FROM payments p " +
                    "JOIN bookings b ON p.booking_id = b.booking_id " +
                    "JOIN events e ON b.event_code = e.event_code " +
                    "ORDER BY p.payment_date DESC";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             java.io.FileWriter writer = new java.io.FileWriter(filePath)) {
            
            // Write CSV header
            writer.write("Payment ID,Booking ID,User ID,Event Code,Event Title,Category,Organizer ID,Ticket Count,Booking Amount,Payment Amount,Payment Status,Payment Date\n");
            
            // Write data rows
            while (rs.next()) {
                writer.write(String.format("%s,%s,%s,%s,\"%s\",%s,%s,%d,%.2f,%.2f,%s,%s\n",
                    rs.getString("payment_id"),
                    rs.getString("booking_id"),
                    rs.getString("user_id"),
                    rs.getString("event_code"),
                    rs.getString("event_title").replace("\"", "\"\""),
                    rs.getString("category"),
                    rs.getString("organizer_id"),
                    rs.getInt("ticket_count"),
                    rs.getDouble("booking_amount"),
                    rs.getDouble("total_amount"),
                    rs.getString("payment_status"),
                    rs.getTimestamp("payment_date")
                ));
            }
        }
    }

    public void exportEventDataToCSV(String filePath) throws SQLException, IOException {
        String sql = "SELECT " +
                    "e.event_code, e.title, e.category, e.venue, e.event_date, e.capacity, " +
                    "e.tickets_sold, e.available_tickets, e.price, e.revenue, e.status, " +
                    "e.break_even_tickets, e.created_at, " +
                    "o.organizer_id, CONCAT(o.firstname, ' ', o.lastname) as organizer_name " +
                    "FROM events e " +
                    "JOIN organizers o ON e.organizer_id = o.organizer_id " +
                    "ORDER BY e.event_date DESC";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             java.io.FileWriter writer = new java.io.FileWriter(filePath)) {
            
            // Write CSV header
            writer.write("Event Code,Title,Category,Venue,Event Date,Capacity,Tickets Sold,Available Tickets,Price,Revenue,Status,Break Even Tickets,Created At,Organizer ID,Organizer Name\n");
            
            // Write data rows
            while (rs.next()) {
                writer.write(String.format("%s,\"%s\",%s,\"%s\",%s,%d,%d,%d,%.2f,%.2f,%s,%d,%s,%s,\"%s\"\n",
                    rs.getString("event_code"),
                    rs.getString("title").replace("\"", "\"\""),
                    rs.getString("category"),
                    rs.getString("venue").replace("\"", "\"\""),
                    rs.getTimestamp("event_date"),
                    rs.getInt("capacity"),
                    rs.getInt("tickets_sold"),
                    rs.getInt("available_tickets"),
                    rs.getDouble("price"),
                    rs.getDouble("revenue"),
                    rs.getString("status"),
                    rs.getInt("break_even_tickets"),
                    rs.getTimestamp("created_at"),
                    rs.getString("organizer_id"),
                    rs.getString("organizer_name").replace("\"", "\"\"")
                ));
            }
        }
    }

    // Data cleanup and utility methods
    public void closeConnection() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Getters for formatting objects (useful for external access)
    public DecimalFormat getCurrencyFormat() {
        return currencyFormat;
    }

    public DecimalFormat getPercentFormat() {
        return percentFormat;
    }

    public DecimalFormat getNumberFormat() {
        return numberFormat;
    }

    // Main method for testing (remove in production)
    public static void main(String[] args) {
        // This is for testing purposes only
        // Remove this method in production environment
        try {
            // Example usage
            Connection testConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "username", "password");
            RevenuePDFGenerator generator = new RevenuePDFGenerator(testConn);
            
            // Generate different reports
            generator.generateAnalyticsReport("Analytics_Report.pdf");
            generator.generateRevenueReport("Revenue_Report.pdf");
            generator.generateEventsReport("Events_Report.pdf");
            generator.generateUserReport("User_Report.pdf");
            generator.generateOrganizerReport("Organizer_Report.pdf");
            generator.generateBookingReport("Booking_Report.pdf");
            generator.generatePaymentReport("Payment_Report.pdf");
            
            // Export data to CSV
            generator.exportRevenueDataToCSV("Revenue_Data.csv");
            generator.exportEventDataToCSV("Event_Data.csv");
            
            generator.closeConnection();
            System.out.println("All reports generated successfully!");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
