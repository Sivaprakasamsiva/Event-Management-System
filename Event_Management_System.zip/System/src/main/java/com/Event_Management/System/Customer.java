package com.Event_Management.System;

import Connectors.DBConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import Chat.CustomerChat;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;

public class Customer extends JFrame {
    private String customerId;
    private Connection con;
    private JTable eventsTable;
    private DefaultTableModel eventsTableModel;
    private JTable bookingsTable;
    private DefaultTableModel bookingsTableModel;

    // Color scheme
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);
    private final Color SECONDARY_COLOR = new Color(46, 139, 87);
    private final Color ACCENT_COLOR = new Color(106, 90, 205);
    private final Color DANGER_COLOR = new Color(220, 53, 69);
    private final Color SUCCESS_COLOR = new Color(34, 139, 34);
    private final Color BACKGROUND_COLOR = new Color(240, 248, 255);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Customer("CUST023"));
    }

    public Customer(String customerId) {
        super("Customer Dashboard - Event Management System");
        this.customerId = customerId;

        // Initialize database connection
        con = DBConnection.getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database. Application will exit.");
            System.exit(1);
        }

        setupUI();
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(PRIMARY_COLOR);
        tabs.setForeground(Color.WHITE);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // Tab 1: Browse Events
        JPanel eventsPanel = new JPanel(new BorderLayout());
        eventsPanel.setBackground(BACKGROUND_COLOR);
        eventsPanel.add(createSearchPanel(), BorderLayout.NORTH);
        eventsPanel.add(createEventsTablePanel(), BorderLayout.CENTER);
        eventsPanel.add(createEventActionsPanel(), BorderLayout.SOUTH);

        // Tab 2: My Bookings
        JPanel bookingsPanel = new JPanel(new BorderLayout());
        bookingsPanel.setBackground(BACKGROUND_COLOR);
        bookingsPanel.add(createBookingsTablePanel(), BorderLayout.CENTER);
        bookingsPanel.add(createBookingActionsPanel(), BorderLayout.SOUTH);

        // Tab 3: Profile
        JPanel profilePanel = new JPanel(new GridBagLayout());
        profilePanel.setBackground(BACKGROUND_COLOR);
        profilePanel.add(createProfilePanel());

        tabs.add("Browse Events", eventsPanel);
        tabs.add("My Bookings", bookingsPanel);
        tabs.add("Profile", profilePanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);
        
        loadAvailableEvents();
        loadCustomerBookings();
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR, 2),
            "Search and Filter Events",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Segoe UI", Font.BOLD, 12),
            PRIMARY_COLOR
        ));
        searchPanel.setBackground(BACKGROUND_COLOR);
        
        // Search field
        JTextField searchField = new JTextField(20);
        searchField.setToolTipText("Search by event title, venue, or organizer (Press Enter to search)");
        searchField.setBackground(Color.WHITE);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        // Category filter
        JComboBox<String> categoryFilter = new JComboBox<>(new String[]{
            "All Categories", "Music", "Sports", "Conference", 
            "Workshop", "Arts", "Business", "Technology"
        });
        styleComboBox(categoryFilter);
        
        // Price filter
        JComboBox<String> priceFilter = new JComboBox<>(new String[]{
            "Any Price", "Free", "Under ₹500", "₹500 - ₹1000", 
            "₹1000 - ₹2000", "Over ₹2000"
        });
        styleComboBox(priceFilter);
        
        // Date filter
        JComboBox<String> dateFilter = new JComboBox<>(new String[]{
            "Any Date", "Today", "Tomorrow", "This Week", 
            "Next Week", "This Month"
        });
        styleComboBox(dateFilter);
        
        // Search button
        JButton searchButton = createStyledButton("Search", SUCCESS_COLOR);
        
        // Clear filters button
        JButton clearButton = createStyledButton("Clear", DANGER_COLOR);

        // Search button action
        searchButton.addActionListener(e -> {
            searchEvents(
                searchField.getText().trim(),
                categoryFilter.getSelectedItem().toString(),
                priceFilter.getSelectedItem().toString(),
                dateFilter.getSelectedItem().toString()
            );
        });

        // Add Enter key listener to search field
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Trigger search when Enter key is pressed
                    searchEvents(
                        searchField.getText().trim(),
                        categoryFilter.getSelectedItem().toString(),
                        priceFilter.getSelectedItem().toString(),
                        dateFilter.getSelectedItem().toString()
                    );
                }
            }
        });

        // Clear button action
        clearButton.addActionListener(e -> {
            searchField.setText("");
            categoryFilter.setSelectedIndex(0);
            priceFilter.setSelectedIndex(0);
            dateFilter.setSelectedIndex(0);
            loadAvailableEvents();
        });

        // Add components to search panel
        searchPanel.add(createStyledLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(createStyledLabel("Category:"));
        searchPanel.add(categoryFilter);
        searchPanel.add(createStyledLabel("Price:"));
        searchPanel.add(priceFilter);
        searchPanel.add(createStyledLabel("Date:"));
        searchPanel.add(dateFilter);
        searchPanel.add(searchButton);
        searchPanel.add(clearButton);

        return searchPanel;
    }
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return button;
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(PRIMARY_COLOR);
        return label;
    }

    private void styleComboBox(JComboBox<String> comboBox) {
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(PRIMARY_COLOR);
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        comboBox.setBorder(BorderFactory.createLineBorder(PRIMARY_COLOR));
    }
    
    private void searchEvents(String query, String category, String price, String date) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            // Build the base SQL query
            StringBuilder sql = new StringBuilder(
                "SELECT e.event_code, e.title, e.event_date, e.venue, e.price, " +
                "e.available_tickets, e.category, o.company_name, e.status " +
                "FROM Events e " +
                "JOIN Organizers o ON e.organizer_id = o.organizer_id " +
                "WHERE e.status = 'Approved' AND e.available_tickets > 0 AND e.event_date > NOW() "
            );
            
            // Add search query condition
            if (!query.isEmpty()) {
                sql.append("AND (e.title LIKE ? OR e.venue LIKE ? OR o.company_name LIKE ? OR e.description LIKE ?) ");
            }
            
            // Add category filter
            if (!category.equals("All Categories")) {
                sql.append("AND e.category = ? ");
            }
            
            // Add price filter
            if (!price.equals("Any Price")) {
                switch (price) {
                    case "Free":
                        sql.append("AND e.price = 0 ");
                        break;
                    case "Under ₹500":
                        sql.append("AND e.price < 500 ");
                        break;
                    case "₹500 - ₹1000":
                        sql.append("AND e.price BETWEEN 500 AND 1000 ");
                        break;
                    case "₹1000 - ₹2000":
                        sql.append("AND e.price BETWEEN 1000 AND 2000 ");
                        break;
                    case "Over ₹2000":
                        sql.append("AND e.price > 2000 ");
                        break;
                }
            }
            
            // Add date filter
            if (!date.equals("Any Date")) {
                switch (date) {
                    case "Today":
                        sql.append("AND DATE(e.event_date) = CURDATE() ");
                        break;
                    case "Tomorrow":
                        sql.append("AND DATE(e.event_date) = CURDATE() + INTERVAL 1 DAY ");
                        break;
                    case "This Week":
                        sql.append("AND YEARWEEK(e.event_date) = YEARWEEK(CURDATE()) ");
                        break;
                    case "Next Week":
                        sql.append("AND YEARWEEK(e.event_date) = YEARWEEK(CURDATE()) + 1 ");
                        break;
                    case "This Month":
                        sql.append("AND MONTH(e.event_date) = MONTH(CURDATE()) AND YEAR(e.event_date) = YEAR(CURDATE()) ");
                        break;
                }
            }
            
            sql.append("ORDER BY e.event_date ASC");
            
            ps = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            
            // Set search query parameters
            if (!query.isEmpty()) {
                String searchPattern = "%" + query + "%";
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
            }
            
            // Set category parameter
            if (!category.equals("All Categories")) {
                ps.setString(paramIndex++, category);
            }
            
            rs = ps.executeQuery();
            
            // Clear and update the table
            eventsTableModel.setRowCount(0);
            int resultCount = 0;
            
            while (rs.next()) {
                eventsTableModel.addRow(new Object[]{
                    rs.getString("event_code"),
                    rs.getString("title"),
                    formatDateTime(rs.getString("event_date")),
                    rs.getString("venue"),
                    String.format("₹%.2f", rs.getDouble("price")),
                    rs.getInt("available_tickets"),
                    rs.getString("category"),
                    rs.getString("company_name"),
                    rs.getString("status")
                });
                resultCount++;
            }
            
            // Show result count
            if (resultCount == 0) {
                JOptionPane.showMessageDialog(this, "No events found matching your criteria.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Found " + resultCount + " events matching your criteria!", "Search Results", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error searching events: " + ex.getMessage(), "Search Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(1200, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        JLabel titleLabel = new JLabel("Customer Dashboard - Event Management System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setOpaque(false);

        JButton chatButton = createStyledButton("Chat Support", SUCCESS_COLOR);
        JButton logoutButton = createStyledButton("Logout", DANGER_COLOR);

        chatButton.addActionListener(e -> {
        	new CustomerChat(customerId);
        });

        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                DBConnection.closeConnection(con);
                dispose();
                JOptionPane.showMessageDialog(null, "Logged out successfully!");
            }
        });

        buttonPanel.add(chatButton);
        buttonPanel.add(logoutButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);

        return headerPanel;
    }
    

    private JScrollPane createEventsTablePanel() {
        String[] columns = {"Event Code", "Title", "Date", "Venue", "Price", "Available", "Category", "Organizer", "Status"};
        eventsTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        eventsTable = new JTable(eventsTableModel);

        eventsTable.setRowHeight(30);
        eventsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        eventsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JTableHeader header = eventsTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(50, 90, 150));
        header.setForeground(Color.WHITE);

        // Color coding for events
        eventsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                    
                    try {
                        String status = table.getModel().getValueAt(row, 8).toString();
                        int availableTickets = Integer.parseInt(table.getModel().getValueAt(row, 5).toString());
                        
                        if ("Approved".equals(status)) {
                            if (availableTickets > 10) {
                                c.setBackground(new Color(220, 255, 220)); // Green - plenty available
                            } else if (availableTickets > 0) {
                                c.setBackground(new Color(255, 255, 220)); // Yellow - limited
                            } else {
                                c.setBackground(new Color(255, 220, 220)); // Red - sold out
                            }
                        } else {
                            c.setBackground(new Color(240, 240, 240)); // Gray - not approved
                        }
                    } catch (Exception ex) {
                        // Ignore errors
                    }
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(eventsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR, 2),
            "Available Events",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Segoe UI", Font.BOLD, 12),
            PRIMARY_COLOR
        ));
        return scrollPane;
    }

    private JPanel createEventActionsPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR),
            "Event Actions"
        ));
        actionPanel.setBackground(BACKGROUND_COLOR);

        JButton bookButton = createStyledButton("Book Selected Event", SECONDARY_COLOR);
        JButton viewDetailsButton = createStyledButton("View Event Details", PRIMARY_COLOR);
        JButton refreshButton = createStyledButton("Refresh Events", ACCENT_COLOR);

        bookButton.addActionListener(e -> bookSelectedEvent());
        viewDetailsButton.addActionListener(e -> viewEventDetails());
        refreshButton.addActionListener(e -> loadAvailableEvents());

        actionPanel.add(bookButton);
        actionPanel.add(viewDetailsButton);
        actionPanel.add(refreshButton);

        return actionPanel;
    }

    private JScrollPane createBookingsTablePanel() {
        String[] columns = {"Booking ID", "Event", "Event Date", "Tickets", "Total Amount", "Booking Date", "Status"};
        bookingsTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        bookingsTable = new JTable(bookingsTableModel);

        bookingsTable.setRowHeight(30);
        bookingsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        bookingsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JTableHeader header = bookingsTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(60, 140, 100));
        header.setForeground(Color.WHITE);

        // Color coding for bookings
        bookingsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(240, 250, 240) : Color.WHITE);
                    
                    try {
                        String status = table.getModel().getValueAt(row, 6).toString();
                        if ("Confirmed".equals(status)) {
                            c.setBackground(new Color(220, 255, 220)); // Green
                        } else if ("Cancelled".equals(status)) {
                            c.setBackground(new Color(255, 220, 220)); // Red
                        } else if ("Refunded".equals(status)) {
                            c.setBackground(new Color(220, 220, 255)); // Blue
                        } else if ("Pending".equals(status)) {
                            c.setBackground(new Color(255, 255, 220)); // Yellow
                        }
                    } catch (Exception ex) {
                        // Ignore errors
                    }
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(bookingsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60, 140, 100), 2),
            "My Bookings",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Segoe UI", Font.BOLD, 12),
            new Color(60, 140, 100)
        ));
        return scrollPane;
    }

    private JPanel createBookingActionsPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60, 140, 100)),
            "Booking Actions"
        ));
        actionPanel.setBackground(new Color(240, 250, 240));

        JButton cancelButton = createStyledButton("Cancel Booking", DANGER_COLOR);
        JButton viewBookingDetailsButton = createStyledButton("View Booking Details", PRIMARY_COLOR);
        JButton refreshBookingsButton = createStyledButton("Refresh Bookings", ACCENT_COLOR);

        cancelButton.addActionListener(e -> cancelSelectedBooking());
        viewBookingDetailsButton.addActionListener(e -> viewBookingDetails());
        refreshBookingsButton.addActionListener(e -> loadCustomerBookings());

        actionPanel.add(cancelButton);
        actionPanel.add(viewBookingDetailsButton);
        actionPanel.add(refreshBookingsButton);

        return actionPanel;
    }

    private void cancelSelectedBooking() {
        int selectedRow = bookingsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking to cancel.");
            return;
        }
        
        String bookingId = (String) bookingsTableModel.getValueAt(selectedRow, 0);
        String eventName = (String) bookingsTableModel.getValueAt(selectedRow, 1);
        String status = (String) bookingsTableModel.getValueAt(selectedRow, 6);
        
        if ("Cancelled".equals(status)) {
            JOptionPane.showMessageDialog(this, "This booking is already cancelled.");
            return;
        }
        
        if ("Refunded".equals(status)) {
            JOptionPane.showMessageDialog(this, "This booking has already been refunded and cannot be cancelled.");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to cancel booking: " + bookingId + " for event: " + eventName + "?",
            "Confirm Cancellation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = cancelBooking(bookingId);
            if (success) {
                JOptionPane.showMessageDialog(this, "Booking cancelled successfully!");
                loadCustomerBookings();
                loadAvailableEvents();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to cancel booking. Please try again.");
            }
        }
    }

    private boolean cancelBooking(String bookingId) {
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement updateEventPs = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            
            // First, get booking details to update event tickets
            String getBookingSql = "SELECT event_code, ticket_count FROM bookings WHERE booking_id = ?";
            ps = conn.prepareStatement(getBookingSql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (!rs.next()) {
                return false;
            }
            
            String eventCode = rs.getString("event_code");
            int ticketCount = rs.getInt("ticket_count");
            
            rs.close();
            ps.close();
            
            // Update booking status to Cancelled
            String updateBookingSql = "UPDATE bookings SET status = 'Cancelled' WHERE booking_id = ?";
            ps = conn.prepareStatement(updateBookingSql);
            ps.setString(1, bookingId);
            int rows = ps.executeUpdate();
            
            if (rows > 0) {
                // Update event available tickets
                String updateEventSql = "UPDATE events SET available_tickets = available_tickets + ?, tickets_sold = tickets_sold - ? WHERE event_code = ?";
                updateEventPs = conn.prepareStatement(updateEventSql);
                updateEventPs.setInt(1, ticketCount);
                updateEventPs.setInt(2, ticketCount);
                updateEventPs.setString(3, eventCode);
                updateEventPs.executeUpdate();
                
                conn.commit();
                return true;
            }
            
        } catch (SQLException ex) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error cancelling booking: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (updateEventPs != null) updateEventPs.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    DBConnection.closeConnection(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

    private void viewBookingDetails() {
        int selectedRow = bookingsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking to view details.");
            return;
        }
        
        String bookingId = (String) bookingsTableModel.getValueAt(selectedRow, 0);
        showBookingDetailsDialog(bookingId);
    }

    private void showBookingDetailsDialog(String bookingId) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.*, e.title, e.event_date, e.venue, e.price, " +
                        "m.firstname, m.lastname, m.email " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "JOIN members m ON b.user_id = m.member_id " +
                        "WHERE b.booking_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                JTextArea detailsArea = new JTextArea(15, 40);
                detailsArea.setEditable(false);
                detailsArea.setLineWrap(true);
                detailsArea.setWrapStyleWord(true);
                detailsArea.setBackground(BACKGROUND_COLOR);
                detailsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                detailsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
                
                StringBuilder details = new StringBuilder();
                details.append("BOOKING DETAILS\n");
                details.append("==================\n\n");
                details.append("Booking ID: ").append(rs.getString("booking_id")).append("\n");
                details.append("Event: ").append(rs.getString("title")).append("\n");
                details.append("Event Date: ").append(formatDateTime(rs.getString("event_date"))).append("\n");
                details.append("Venue: ").append(rs.getString("venue")).append("\n");
                details.append("Tickets: ").append(rs.getInt("ticket_count")).append("\n");
                details.append("Price per Ticket: ₹").append(String.format("%.2f", rs.getDouble("price"))).append("\n");
                details.append("Total Amount: ₹").append(String.format("%.2f", rs.getDouble("total_amount"))).append("\n\n");
                details.append("Booking Date: ").append(formatDateTime(rs.getString("booking_date"))).append("\n");
                details.append("Status: ").append(rs.getString("status")).append("\n\n");
                details.append("Customer: ").append(rs.getString("firstname")).append(" ").append(rs.getString("lastname")).append("\n");
                details.append("Email: ").append(rs.getString("email")).append("\n");
                
                detailsArea.setText(details.toString());
                
                JScrollPane scrollPane = new JScrollPane(detailsArea);
                scrollPane.setBorder(BorderFactory.createTitledBorder("Booking Information"));
                JOptionPane.showMessageDialog(this, scrollPane, "Booking Details - " + bookingId, 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading booking details: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void loadAvailableEvents() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT e.event_code, e.title, e.event_date, e.venue, e.price, " +
                        "e.available_tickets, e.category, o.company_name, e.status " +
                        "FROM Events e " +
                        "JOIN Organizers o ON e.organizer_id = o.organizer_id " +
                        "WHERE e.status = 'Approved' AND e.available_tickets > 0 AND e.event_date > NOW() " +
                        "ORDER BY e.event_date ASC";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            eventsTableModel.setRowCount(0);
            int count = 0;
            while (rs.next()) {
                eventsTableModel.addRow(new Object[]{
                    rs.getString("event_code"),
                    rs.getString("title"),
                    formatDateTime(rs.getString("event_date")),
                    rs.getString("venue"),
                    String.format("₹%.2f", rs.getDouble("price")),
                    rs.getInt("available_tickets"),
                    rs.getString("category"),
                    rs.getString("company_name"),
                    rs.getString("status")
                });
                count++;
            }
            
            // Update table header with count
            JViewport viewport = (JViewport) eventsTable.getParent();
            if (viewport != null) {
                JScrollPane scrollPane = (JScrollPane) viewport.getParent();
                scrollPane.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(PRIMARY_COLOR, 2),
                    "Available Events (" + count + " found)",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
                    javax.swing.border.TitledBorder.DEFAULT_POSITION,
                    new Font("Segoe UI", Font.BOLD, 12),
                    PRIMARY_COLOR
                ));
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading events: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private void loadCustomerBookings() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, e.title, e.event_date, b.ticket_count, " +
                        "b.total_amount, b.booking_date, b.status " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "WHERE b.user_id = ? " +
                        "ORDER BY b.booking_date DESC";
            ps = conn.prepareStatement(sql);
            ps.setString(1, customerId);
            rs = ps.executeQuery();
            
            bookingsTableModel.setRowCount(0);
            int count = 0;
            while (rs.next()) {
                String bookingId = rs.getString("booking_id");
                
                bookingsTableModel.addRow(new Object[]{
                    bookingId,
                    rs.getString("title"),
                    formatDateTime(rs.getString("event_date")),
                    rs.getInt("ticket_count"),
                    String.format("₹%.2f", rs.getDouble("total_amount")),
                    formatDateTime(rs.getString("booking_date")),
                    rs.getString("status")
                });
                count++;
            }
            
            // Update table header with count
            JViewport viewport = (JViewport) bookingsTable.getParent();
            if (viewport != null) {
                JScrollPane scrollPane = (JScrollPane) viewport.getParent();
                scrollPane.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(60, 140, 100), 2),
                    "My Bookings (" + count + " found)",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
                    javax.swing.border.TitledBorder.DEFAULT_POSITION,
                    new Font("Segoe UI", Font.BOLD, 12),
                    new Color(60, 140, 100)
                ));
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading bookings: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    

    private void bookSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to book.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        String eventTitle = (String) eventsTableModel.getValueAt(selectedRow, 1);
        
        // Remove currency symbol before parsing
        String priceString = eventsTableModel.getValueAt(selectedRow, 4).toString();
        double price = Double.parseDouble(priceString.replace("₹", "").replace("Rs.", "").replace("$", "").trim());
        
        String availableTicketsString = eventsTableModel.getValueAt(selectedRow, 5).toString();
        int availableTickets = Integer.parseInt(availableTicketsString);
        
        // Show booking dialog
        showBookingDialog(eventCode, eventTitle, price, availableTickets);
    }
    
    
    private void showBookingDialog(String eventCode, String eventTitle, double price, int availableTickets) {
        JDialog bookingDialog = new JDialog(this, "Book Event", true);
        bookingDialog.setLayout(new GridBagLayout());
        bookingDialog.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel eventLabel = new JLabel("Event: " + eventTitle);
        eventLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        eventLabel.setForeground(PRIMARY_COLOR);
        
        JLabel priceLabel = new JLabel("Price per ticket: ₹" + String.format("%.2f", price));
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JLabel availableLabel = new JLabel("Available tickets: " + availableTickets);
        availableLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JSpinner ticketSpinner = new JSpinner(new SpinnerNumberModel(1, 1, availableTickets, 1));
        JLabel totalLabel = new JLabel("Total: ₹" + String.format("%.2f", price));
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        totalLabel.setForeground(SUCCESS_COLOR);
        
        // Update total when tickets change
        ticketSpinner.addChangeListener(e -> {
            int tickets = (Integer) ticketSpinner.getValue();
            double total = tickets * price;
            totalLabel.setText("Total: ₹" + String.format("%.2f", total));
        });
        
        JButton confirmButton = createStyledButton("Confirm Booking", SUCCESS_COLOR);
        JButton cancelButton = createStyledButton("Cancel", DANGER_COLOR);
        
        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        bookingDialog.add(eventLabel, gbc);
        
        row++;
        gbc.gridy = row;
        bookingDialog.add(priceLabel, gbc);
        
        row++;
        gbc.gridy = row;
        bookingDialog.add(availableLabel, gbc);
        
        row++;
        gbc.gridy = row; gbc.gridwidth = 1;
        bookingDialog.add(new JLabel("Number of tickets:"), gbc);
        
        gbc.gridx = 1;
        bookingDialog.add(ticketSpinner, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        bookingDialog.add(totalLabel, gbc);
        
        row++;
        gbc.gridy = row;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        bookingDialog.add(buttonPanel, gbc);
        
        confirmButton.addActionListener(e -> {
            int ticketCount = (Integer) ticketSpinner.getValue();
            double totalAmount = ticketCount * price;
            
            // Process booking
            String result = createBooking(eventCode, customerId, ticketCount, totalAmount);
            if (result.startsWith("SUCCESS:")) {
                String[] parts = result.split(":");
                String bookingId = parts[1];
                String message = parts[2];
                JOptionPane.showMessageDialog(bookingDialog, 
                    "Booking confirmed!\nBooking ID: " + bookingId + "\n" + message);
                bookingDialog.dispose();
                loadAvailableEvents();
                loadCustomerBookings();
            } else {
                JOptionPane.showMessageDialog(bookingDialog, 
                    result.replace("ERROR:", ""), "Booking Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> bookingDialog.dispose());
        
        bookingDialog.setSize(400, 250);
        bookingDialog.setLocationRelativeTo(this);
        bookingDialog.setVisible(true);
    }
    
    private String createBooking(String eventCode, String userId, int ticketCount, double totalAmount) {
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement updatePs = null;
        PreparedStatement eventPs = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            
            // Get the event_id (varchar) from events table using event_code
            String eventSql = "SELECT event_id, available_tickets FROM events WHERE event_code = ?";
            eventPs = conn.prepareStatement(eventSql);
            eventPs.setString(1, eventCode);
            rs = eventPs.executeQuery();
            
            if (!rs.next()) {
                return "ERROR: Event not found.";
            }
            
            String eventId = rs.getString("event_id");
            int availableTickets = rs.getInt("available_tickets");
            
            // Check if enough tickets are available
            if (availableTickets < ticketCount) {
                return "ERROR: Not enough tickets available. Only " + availableTickets + " tickets left.";
            }
            
            rs.close();
            eventPs.close();
            
            // Generate booking ID like BOOK004
            String bookingId = IDGenerator.generateBookingID();
            System.out.println("Generated Booking ID: " + bookingId);
            
            if (bookingId == null) {
                return "ERROR: Failed to generate booking ID.";
            }
            
            // DEBUG: Check what ID we're about to insert
            System.out.println("Inserting with booking_id: " + bookingId);
            System.out.println("Using event_id: " + eventId + " for event_code: " + eventCode);
            
            // Insert booking - use both event_id and event_code as required by your table structure
            String bookingSql = "INSERT INTO bookings (booking_id, event_id, event_code, user_id, ticket_count, total_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'Confirmed')";
            ps = conn.prepareStatement(bookingSql);
            ps.setString(1, bookingId);
            
            // Try to parse event_id as integer, or use a default value if it's not numeric
            try {
                int eventIdInt = Integer.parseInt(eventId.replaceAll("[^0-9]", ""));
                ps.setInt(2, eventIdInt);
            } catch (NumberFormatException e) {
                // If event_id is not numeric, use a default value or extract numbers from it
                // Extract numbers from string like "EVNT034" -> 34
                String numbersOnly = eventId.replaceAll("[^0-9]", "");
                if (!numbersOnly.isEmpty()) {
                    ps.setInt(2, Integer.parseInt(numbersOnly));
                } else {
                    // Use a fallback value if no numbers found
                    ps.setInt(2, 1);
                }
            }
            
            ps.setString(3, eventCode);
            ps.setString(4, userId);
            ps.setInt(5, ticketCount);
            ps.setDouble(6, totalAmount);
            
            int rows = ps.executeUpdate();
            
            if (rows > 0) {
                System.out.println("Booking inserted successfully with ID: " + bookingId);
                
                // Update event tickets
                String updateEventSql = "UPDATE events SET tickets_sold = tickets_sold + ?, available_tickets = available_tickets - ?, revenue = revenue + ? WHERE event_code = ?";
                updatePs = conn.prepareStatement(updateEventSql);
                updatePs.setInt(1, ticketCount);
                updatePs.setInt(2, ticketCount);
                updatePs.setDouble(3, totalAmount);
                updatePs.setString(4, eventCode);
                updatePs.executeUpdate();
                
                conn.commit();
                
                // Send email
                String customerEmail = getCustomerEmail(userId);
                if (customerEmail != null) {
                    boolean emailSent = EmailService.sendBookingConfirmation(bookingId, customerEmail);
                    if (emailSent) {
                        return "SUCCESS:" + bookingId + ":Confirmation email sent to " + customerEmail;
                    }
                }
                return "SUCCESS:" + bookingId + ":Booking confirmed successfully!";
            }
        } catch (SQLException ex) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
            return "ERROR: Database error: " + ex.getMessage();
        } finally {
            try {
                if (rs != null) rs.close();
                if (eventPs != null) eventPs.close();
                if (ps != null) ps.close();
                if (updatePs != null) updatePs.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    DBConnection.closeConnection(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return "ERROR: Unknown error occurred.";
    }
    
    private String getCustomerEmail(String userId) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT email FROM members WHERE member_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, userId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getString("email");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    private void viewEventDetails() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to view details.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        showEventDetailsDialog(eventCode);
    }
    

    private void showEventDetailsDialog(String eventCode) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT e.*, o.company_name, o.firstname, o.lastname, o.email as organizer_email " +
                        "FROM Events e JOIN Organizers o ON e.organizer_id = o.organizer_id " +
                        "WHERE e.event_code = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eventCode);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                JTextArea detailsArea = new JTextArea(15, 40);
                detailsArea.setEditable(false);
                detailsArea.setLineWrap(true);
                detailsArea.setWrapStyleWord(true);
                detailsArea.setBackground(BACKGROUND_COLOR);
                detailsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                detailsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
                
                StringBuilder details = new StringBuilder();
                details.append("EVENT DETAILS\n");
                details.append("================\n\n");
                details.append("Title: ").append(rs.getString("title")).append("\n");
                details.append("Event Code: ").append(rs.getString("event_code")).append("\n");
                details.append("Description: ").append(rs.getString("description")).append("\n\n");
                details.append("Date: ").append(formatDateTime(rs.getString("event_date"))).append("\n");
                details.append("Venue: ").append(rs.getString("venue")).append("\n");
                details.append("Price: ₹").append(String.format("%.2f", rs.getDouble("price"))).append("\n\n");
                details.append("Tickets Available: ").append(rs.getInt("available_tickets")).append("\n");
                details.append("Capacity: ").append(rs.getInt("capacity")).append("\n");
                details.append("Category: ").append(rs.getString("category")).append("\n\n");
                details.append("Organizer: ").append(rs.getString("company_name")).append("\n");
                details.append("Contact: ").append(rs.getString("organizer_email")).append("\n");
                details.append("Status: ").append(rs.getString("status")).append("\n");
                
                detailsArea.setText(details.toString());
                
                JScrollPane scrollPane = new JScrollPane(detailsArea);
                scrollPane.setBorder(BorderFactory.createTitledBorder("Event Information"));
                JOptionPane.showMessageDialog(this, scrollPane, "Event Details - " + rs.getString("title"), 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading event details: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    

    private JPanel createProfilePanel() {
        JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
        profilePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(ACCENT_COLOR, 2),
            "Customer Profile",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Segoe UI", Font.BOLD, 12),
            ACCENT_COLOR
        ));
        profilePanel.setBackground(BACKGROUND_COLOR);

        JPanel infoPanel = new JPanel(new GridBagLayout());
        infoPanel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 15, 8, 15);
        gbc.anchor = GridBagConstraints.WEST;

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM members WHERE member_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, customerId);
            rs = ps.executeQuery();

            if (rs.next()) {
                int[] rowCount = {0};

                java.util.function.BiConsumer<String, String> addRow = (label, value) -> {
                    gbc.gridx = 0;
                    gbc.gridy = rowCount[0];
                    JLabel labelComp = new JLabel(label + ":");
                    labelComp.setFont(new Font("Segoe UI", Font.BOLD, 12));
                    labelComp.setForeground(PRIMARY_COLOR);
                    infoPanel.add(labelComp, gbc);

                    gbc.gridx = 1;
                    JLabel valueLabel = new JLabel(value != null ? value : "Not set");
                    valueLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                    valueLabel.setForeground(Color.DARK_GRAY);
                    // Add background color for important fields
                    if (label.equals("Customer ID") || label.equals("Email") || label.equals("Username")) {
                        valueLabel.setOpaque(true);
                        valueLabel.setBackground(new Color(255, 255, 200));
                        valueLabel.setBorder(BorderFactory.createEmptyBorder(3, 5, 3, 5));
                    }
                    infoPanel.add(valueLabel, gbc);

                    rowCount[0]++;
                };

                addRow.accept("Customer ID", rs.getString("member_id"));
                addRow.accept("First Name", rs.getString("firstname"));
                addRow.accept("Last Name", rs.getString("lastname"));
                addRow.accept("Username", rs.getString("username"));
                addRow.accept("Email", rs.getString("email"));
                addRow.accept("Mobile", rs.getString("mobile"));
                addRow.accept("Date of Birth", rs.getString("dob") != null ? rs.getString("dob") : "Not set");
                addRow.accept("Gender", rs.getString("gender") != null ? rs.getString("gender") : "Not set");
                addRow.accept("Address", rs.getString("address") != null ? rs.getString("address") : "Not set");
                addRow.accept("Member Since", rs.getString("created_at"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        JButton editProfileButton = createStyledButton("Edit Profile", ACCENT_COLOR);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(editProfileButton);

        editProfileButton.addActionListener(e -> showEditProfileDialog());

        profilePanel.add(infoPanel, BorderLayout.CENTER);
        profilePanel.add(buttonPanel, BorderLayout.SOUTH);

        return profilePanel;
    }

    private void showEditProfileDialog() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM members WHERE member_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, customerId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                JDialog editDialog = new JDialog(this, "Edit Profile", true);
                editDialog.setLayout(new GridBagLayout());
                editDialog.setBackground(BACKGROUND_COLOR);
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.insets = new Insets(5, 5, 5, 5);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                
                // Create form fields
                JTextField firstNameField = new JTextField(rs.getString("firstname"), 20);
                JTextField lastNameField = new JTextField(rs.getString("lastname"), 20);
                JTextField emailField = new JTextField(rs.getString("email"), 20);
                JTextField mobileField = new JTextField(rs.getString("mobile"), 20);
                JTextField dobField = new JTextField(rs.getString("dob") != null ? rs.getString("dob") : "", 20);
                JComboBox<String> genderCombo = new JComboBox<>(new String[]{"", "Male", "Female", "Other"});
                if (rs.getString("gender") != null) {
                    genderCombo.setSelectedItem(rs.getString("gender"));
                }
                JTextArea addressArea = new JTextArea(rs.getString("address") != null ? rs.getString("address") : "", 3, 20);
                addressArea.setLineWrap(true);
                addressArea.setWrapStyleWord(true);
                JScrollPane addressScroll = new JScrollPane(addressArea);
                
                // Style fields
                Component[] fields = {firstNameField, lastNameField, emailField, mobileField, dobField, genderCombo, addressArea};
                for (Component field : fields) {
                    if (field instanceof JTextField) {
                        ((JTextField) field).setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(PRIMARY_COLOR),
                            BorderFactory.createEmptyBorder(5, 5, 5, 5)
                        ));
                    } else if (field instanceof JComboBox) {
                        ((JComboBox<?>) field).setBackground(Color.WHITE);
                    } else if (field instanceof JTextArea) {
                        ((JTextArea) field).setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(PRIMARY_COLOR),
                            BorderFactory.createEmptyBorder(5, 5, 5, 5)
                        ));
                    }
                }
                
                int row = 0;
                
                // First Name
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("First Name:"), gbc);
                gbc.gridx = 1;
                editDialog.add(firstNameField, gbc);
                
                row++;
                // Last Name
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Last Name:"), gbc);
                gbc.gridx = 1;
                editDialog.add(lastNameField, gbc);
                
                row++;
                // Email
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Email:"), gbc);
                gbc.gridx = 1;
                editDialog.add(emailField, gbc);
                
                row++;
                // Mobile
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Mobile:"), gbc);
                gbc.gridx = 1;
                editDialog.add(mobileField, gbc);
                
                row++;
                // Date of Birth
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Date of Birth (YYYY-MM-DD):"), gbc);
                gbc.gridx = 1;
                editDialog.add(dobField, gbc);
                
                row++;
                // Gender
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Gender:"), gbc);
                gbc.gridx = 1;
                editDialog.add(genderCombo, gbc);
                
                row++;
                // Address
                gbc.gridx = 0; gbc.gridy = row;
                editDialog.add(createFormLabel("Address:"), gbc);
                gbc.gridx = 1;
                editDialog.add(addressScroll, gbc);
                
                row++;
                // Buttons
                gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
                JPanel buttonPanel = new JPanel(new FlowLayout());
                buttonPanel.setBackground(BACKGROUND_COLOR);
                
                JButton saveButton = createStyledButton("Save Changes", SUCCESS_COLOR);
                JButton cancelButton = createStyledButton("Cancel", DANGER_COLOR);
                
                saveButton.addActionListener(e -> {
                    // Validate and save changes
                    if (validateProfileFields(firstNameField, lastNameField, emailField, mobileField)) {
                        boolean success = updateProfile(
                            firstNameField.getText(),
                            lastNameField.getText(),
                            emailField.getText(),
                            mobileField.getText(),
                            dobField.getText(),
                            genderCombo.getSelectedItem().toString().replaceFirst("^[^\\s]+\\s+", ""),
                            addressArea.getText()
                        );
                        
                        if (success) {
                            JOptionPane.showMessageDialog(editDialog, "Profile updated successfully!");
                            editDialog.dispose();
                            // Refresh profile panel
                            setupUI();
                        } else {
                            JOptionPane.showMessageDialog(editDialog, "Failed to update profile. Please try again.");
                        }
                    }
                });
                
                cancelButton.addActionListener(e -> editDialog.dispose());
                
                buttonPanel.add(saveButton);
                buttonPanel.add(cancelButton);
                editDialog.add(buttonPanel, gbc);
                
                editDialog.pack();
                editDialog.setSize(500, 400);
                editDialog.setLocationRelativeTo(this);
                editDialog.setVisible(true);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading profile data: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(PRIMARY_COLOR);
        return label;
    }

    private boolean validateProfileFields(JTextField firstName, JTextField lastName, JTextField email, JTextField mobile) {
        if (firstName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "First name is required.");
            return false;
        }
        if (lastName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Last name is required.");
            return false;
        }
        if (email.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email is required.");
            return false;
        }
        if (!email.getText().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address.");
            return false;
        }
        if (mobile.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mobile number is required.");
            return false;
        }
        if (!mobile.getText().matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid 10-digit mobile number.");
            return false;
        }
        return true;
    }

    private boolean updateProfile(String firstName, String lastName, String email, String mobile, 
                                String dob, String gender, String address) {
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE members SET firstname = ?, lastname = ?, email = ?, mobile = ?, " +
                        "dob = ?, gender = ?, address = ? WHERE member_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, email);
            ps.setString(4, mobile);
            ps.setString(5, dob.isEmpty() ? null : dob);
            ps.setString(6, gender.isEmpty() ? null : gender);
            ps.setString(7, address.isEmpty() ? null : address);
            ps.setString(8, customerId);
            
            int rows = ps.executeUpdate();
            return rows > 0;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating profile: " + ex.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private String formatDateTime(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
            java.util.Date date = inputFormat.parse(dateTime);
            return outputFormat.format(date);
        } catch (Exception e) {
            return dateTime;
        }
    }

    @Override
    public void dispose() {
        DBConnection.closeConnection(con);
        super.dispose();
    }
}

// Placeholder classes - you need to implement these