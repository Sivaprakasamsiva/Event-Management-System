package com.Event_Management.System;

import Connectors.*;


import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableCellRenderer;

import com.toedter.calendar.JDateChooser;

import Chat.*;


import java.util.Date;

public class Admin extends JFrame {
    private Connection con;
    private String adminId;
    private JTable usersTable;
    private DefaultTableModel usersTableModel;
    private JTable eventsTable;
    private DefaultTableModel eventsTableModel;
    private JTable organizersTable;
    private DefaultTableModel organizersTableModel;
    private JPanel dashboardStats;
    private JScrollPane dashboardActivity;
    private JPanel dashboardRevenue;
    private JPanel dashboardLoss;
    private JLabel refreshLabel;  
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    
    // Add currency format
    private static final DecimalFormat currencyFormat = new DecimalFormat("₹#,##0.00");
    
    // Add PDF Generator fields
    private PDF_Generator pdfGenerator;
    private RevenuePDFGenerator revenuePDFGenerator;

    public Admin(String adminId) {
        super("Admin Dashboard - Event Management System");
        this.adminId = adminId;

        // Initialize DB connection using DBConnection class
        con = DBConnection.getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Failed to connect to database. Application will exit.");
            System.exit(1);
        }
        
        // Initialize PDF Generators
        this.pdfGenerator = new PDF_Generator(con);
        this.revenuePDFGenerator = new RevenuePDFGenerator(con);

        setupUI();
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    
    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Add a header panel with explanation
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        String headerText = "Financial Overview: Revenue, Profit/Loss, and Margins by Month";
        JLabel infoLabel = new JLabel(headerText);
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoLabel.setForeground(new Color(60, 60, 60));
        infoPanel.add(infoLabel);
        
        JTabbedPane tabs = new JTabbedPane();

        // Dashboard Tab
        JPanel overviewPanel = new JPanel(new BorderLayout());
        JPanel gridPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        JPanel statsPanel = createStatsPanel();
        JScrollPane recentActivityPanel = createRecentActivityTable();
        JPanel revenuePanel = createRevenueChart();
        JPanel analyticsPanel = createAdvancedAnalyticsPanel();

        gridPanel.add(statsPanel);
        gridPanel.add(recentActivityPanel);
        gridPanel.add(revenuePanel);
        gridPanel.add(analyticsPanel);

        // Save references
        this.dashboardStats = statsPanel;
        this.dashboardActivity = recentActivityPanel;
        this.dashboardRevenue = revenuePanel;
        this.dashboardLoss = analyticsPanel;

        // Add grid to center
        overviewPanel.add(gridPanel, BorderLayout.CENTER);

        // Dashboard buttons panel
        JPanel dashboardButtonsPanel = createDashboardButtonsPanel();
        overviewPanel.add(dashboardButtonsPanel, BorderLayout.SOUTH);

        // Refresh label at bottom
        refreshLabel = new JLabel("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));
        refreshLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.add(refreshLabel);
        overviewPanel.add(footer, BorderLayout.SOUTH);

        // User Management Tab
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.add(createUsersTablePanel(), BorderLayout.CENTER);
        userPanel.add(createUserActionsPanel(), BorderLayout.SOUTH);

        // Event Management Tab
        JPanel eventManagementPanel = new JPanel(new BorderLayout());
        eventManagementPanel.add(createEventsTablePanel(), BorderLayout.CENTER);
        JPanel eventActionsPanel = createEventActionsPanel();
        eventManagementPanel.add(eventActionsPanel, BorderLayout.SOUTH);

        // Organizer Management Tab
        JPanel organizerPanel = new JPanel(new BorderLayout());
        organizerPanel.add(createOrganizersTablePanel(), BorderLayout.CENTER);
        organizerPanel.add(createOrganizerActionsPanel(), BorderLayout.SOUTH);

        // Settings Tab
        JPanel settingsPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        settingsPanel.add(createSettingsForm());

        // Keep the working emojis in tabs
        tabs.add("📊 Dashboard", overviewPanel);
        tabs.add("👥 User Management", userPanel);
        tabs.add("🎪 Event Management", eventManagementPanel);
        tabs.add("🏢 Organizer Management", organizerPanel);
        tabs.add("⚙️ Settings", settingsPanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);

        loadUsersData();
        loadAllEvents();
        loadOrganizersData();
        loadRecentActivity();

        // Auto refresh dashboard every 60 sec
        new javax.swing.Timer(60000, e -> refreshDashboard(gridPanel, footer)).start();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(65, 105, 225));
        headerPanel.setPreferredSize(new Dimension(1200, 50));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel titleLabel = new JLabel("Admin Dashboard - Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Create button panel for Admin Chat and Logout
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setOpaque(false);

        // Admin Chat Button - Use simple text
        JButton adminChatButton = new JButton("Admin Chat");
        adminChatButton.setFont(new Font("Arial", Font.BOLD, 12));
        adminChatButton.setBackground(new Color(32, 107, 16));
        adminChatButton.setForeground(Color.WHITE);
        adminChatButton.setFocusPainted(false);
        adminChatButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 85, 12), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        adminChatButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effects
        adminChatButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                adminChatButton.setBackground(new Color(25, 85, 12));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                adminChatButton.setBackground(new Color(32, 107, 16));
            }
        });

        // Logout Button - Use simple text
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setBackground(new Color(220, 53, 69));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 35, 50), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effects
        logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutButton.setBackground(new Color(180, 35, 50));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                logoutButton.setBackground(new Color(220, 53, 69));
            }
        });

        // Chat button action
        adminChatButton.addActionListener(e -> {
        	
            
           
                SwingUtilities.invokeLater(() -> new AdminChat());
                
        	 //SwingUtilities.invokeLater(() -> new AdminChat());
        });

        // Logout button action
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            if (confirm == JOptionPane.YES_OPTION) {
                DBConnection.closeConnection(con);
                dispose();
                JOptionPane.showMessageDialog(null, "Logged out successfully!", "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                SwingUtilities.invokeLater(App::new);
            }
        });

        buttonPanel.add(adminChatButton);
        buttonPanel.add(logoutButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);

        return headerPanel;
    }
   
    private JPanel createDashboardButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panel.setBackground(new Color(240, 240, 240));
        panel.setBorder(BorderFactory.createTitledBorder("Dashboard Controls"));

        // Use simple text without emojis for buttons
        JButton exportPDFButton = new JButton("Export PDF");
        JButton exportRevenuePDFButton = new JButton("Export Revenue PDF");
        JButton selectedPDFButton = new JButton("Selected Events PDF");
        JButton refreshDashboardButton = new JButton("Quick Refresh");

        // Enhanced button styling
        for (JButton btn : new JButton[]{exportPDFButton, exportRevenuePDFButton, selectedPDFButton, refreshDashboardButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(180, 35));
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(btn.getBackground().darker(), 2),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
            ));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        // Special styling for PDF buttons
        exportPDFButton.setBackground(new Color(220, 53, 69));
        exportRevenuePDFButton.setBackground(new Color(40, 167, 69));
        selectedPDFButton.setBackground(new Color(255, 193, 7));
        refreshDashboardButton.setBackground(new Color(108, 117, 125));

        exportPDFButton.addActionListener(e -> generateDashboardPDF());
        exportRevenuePDFButton.addActionListener(e -> generateRevenuePDF());
        selectedPDFButton.addActionListener(e -> generateSelectedEventsPDF());
        refreshDashboardButton.addActionListener(e -> quickRefreshDashboard());

        panel.add(exportPDFButton);
        panel.add(exportRevenuePDFButton);
        panel.add(selectedPDFButton);
        panel.add(refreshDashboardButton);

        return panel;
    }

    // Enhanced refresh functionality
    private void quickRefreshDashboard() {
        try {
            // Show progress indication
            refreshLabel.setText("Refreshing...");
            refreshLabel.setForeground(Color.BLUE);
            
            // Force refresh all data with progress tracking
            refreshLabel.setText("Refreshing users...");
            loadUsersData();
            
            refreshLabel.setText("Refreshing events...");
            loadAllEvents();
            
            refreshLabel.setText("Refreshing organizers...");
            loadOrganizersData();
            
            refreshLabel.setText("Refreshing activity...");
            loadRecentActivity();
            
            // Refresh analytics panel with Organizer's mathematical formulas
            refreshLabel.setText("Updating analytics...");
            refreshAnalyticsData();
            
            // Update the refresh label with success indication
            refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER) + " (Manual)");
            refreshLabel.setForeground(new Color(0, 100, 0));
            
            // Show success message with details
            String refreshMessage = "Dashboard refreshed successfully!\n\n" +
                                   "• Users data updated\n" +
                                   "• Events data updated\n" + 
                                   "• Organizers data updated\n" +
                                   "• Recent activity updated\n" +
                                   "• Analytics recalculated using Organizer formulas";
            
            JOptionPane.showMessageDialog(this, refreshMessage, "Refresh Complete", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception ex) {
            // Update label with error indication
            refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER) + " (Error)");
            refreshLabel.setForeground(Color.RED);
            
            String errorMessage = "Error refreshing dashboard:\n" + ex.getMessage();
            if (ex.getCause() != null) {
                errorMessage += "\n\nCause: " + ex.getCause().getMessage();
            }
            
            JOptionPane.showMessageDialog(this, errorMessage, "Refresh Error", 
                JOptionPane.ERROR_MESSAGE);
            
            // Log the full exception for debugging
            ex.printStackTrace();
        }
    }

    // Refresh analytics data using Organizer's mathematical formulas
    private void refreshAnalyticsData() {
        if (dashboardLoss != null) {
            JPanel analyticsPanel = createAdvancedAnalyticsPanel();
            Component parent = dashboardLoss.getParent();
            if (parent instanceof JPanel) {
                ((JPanel) parent).remove(dashboardLoss);
                ((JPanel) parent).add(analyticsPanel);
                dashboardLoss = analyticsPanel;
                parent.revalidate();
                parent.repaint();
            }
        }
    }

    private JPanel createEventActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        // Use simple text without emojis
        JButton approveButton = new JButton("Approve Selected");
        JButton rejectButton = new JButton("Reject Selected");
        JButton featureButton = new JButton("Feature Event");
        JButton exportPDFButton = new JButton("Export PDF");
        JButton refreshButton = new JButton("Refresh");

        // Button styling
        for (JButton btn : new JButton[]{approveButton, rejectButton, featureButton, exportPDFButton, refreshButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(150, 35));
        }

        exportPDFButton.setBackground(new Color(220, 53, 69));

        approveButton.addActionListener(e -> approveSelectedEvent());
        rejectButton.addActionListener(e -> rejectSelectedEvent());
        featureButton.addActionListener(e -> featureSelectedEvent());
        exportPDFButton.addActionListener(e -> generateEventsPDFReport());
        refreshButton.addActionListener(e -> loadAllEvents());
        
        panel.add(approveButton);
        panel.add(rejectButton);
        panel.add(featureButton);
        panel.add(exportPDFButton);
        panel.add(refreshButton);
        
        return panel;
    }
  
    
    // Mathematical functions now match Organizer.java
    private JPanel createAdvancedAnalyticsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180), 2),
            "System Analytics Dashboard (Using Organizer Formulas)",
            TitledBorder.DEFAULT_JUSTIFICATION,
            TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(70, 130, 180)
        ));
        panel.setBackground(new Color(240, 245, 255));

        JPanel analyticsGrid = new JPanel(new GridLayout(2, 4, 8, 8));
        analyticsGrid.setBackground(new Color(240, 245, 255));
        analyticsGrid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        try {
            // USING ORGANIZER'S MATHEMATICAL FORMULAS:
            
            // 1. Total Events - Count all events
            String totalEventsQuery = "SELECT COUNT(*) as total_events FROM events";
            
            // 2. Current Events - Events that haven't ended yet
            String currentEventsQuery = "SELECT COUNT(*) as current_events FROM events WHERE end_date >= NOW()";
            
            // 3. Tickets Sold - Sum of all tickets sold
            String totalTicketsQuery = "SELECT COALESCE(SUM(tickets_sold), 0) as total_tickets FROM events";
            
            // 4. Total Revenue - From successful payments (LAST 30 DAYS)
            String totalRevenueQuery = "SELECT COALESCE(SUM(total_amount), 0) as total_revenue FROM payments WHERE payment_status = 'Success' AND payment_date >= CURDATE() - INTERVAL 30 DAY";
            
            // 5. Average Attendance - Average tickets sold for past events
            String avgAttendanceQuery = "SELECT COALESCE(AVG(tickets_sold), 0) as avg_attendance FROM events WHERE event_date < CURDATE() AND tickets_sold > 0";
            
            // 6. Pending Tickets - Available tickets for upcoming events
            String pendingTicketsQuery = "SELECT COALESCE(SUM(available_tickets), 0) as pending_tickets FROM events WHERE end_date >= NOW()";
            
            // 7. Total Profit - USING ORGANIZER'S PROFIT FORMULA
            String totalProfitQuery = 
                "SELECT SUM(" +
                "   CASE " +
                "       WHEN end_date < NOW() THEN " + // Completed events
                "           revenue - GREATEST(0, (break_even_tickets - tickets_sold) * price) " +
                "       WHEN end_date >= NOW() THEN " + // Ongoing/upcoming events
                "           revenue - GREATEST(0, (break_even_tickets - (tickets_sold + available_tickets)) * price) " +
                "       ELSE revenue " +
                "   END" +
                ") FROM Events";
            
            // 8. Total Loss - USING ORGANIZER'S LOSS FORMULA
            String totalLossQuery = 
                "SELECT SUM(" +
                "   CASE " +
                "       WHEN end_date < NOW() THEN " + // Completed events - actual loss
                "           GREATEST(0, (break_even_tickets - tickets_sold) * price) " +
                "       WHEN end_date >= NOW() THEN " + // Ongoing/upcoming events - potential loss
                "           GREATEST(0, (break_even_tickets - (tickets_sold + available_tickets)) * price) " +
                "       ELSE 0 " +
                "   END" +
                ") FROM Events WHERE (tickets_sold < break_even_tickets OR (tickets_sold + available_tickets) < break_even_tickets)";

            // Use try-with-resources for automatic resource management
            try (PreparedStatement totalEventsStmt = con.prepareStatement(totalEventsQuery);
                 ResultSet totalEventsRs = totalEventsStmt.executeQuery();
                 PreparedStatement currentEventsStmt = con.prepareStatement(currentEventsQuery);
                 ResultSet currentEventsRs = currentEventsStmt.executeQuery();
                 PreparedStatement totalTicketsStmt = con.prepareStatement(totalTicketsQuery);
                 ResultSet totalTicketsRs = totalTicketsStmt.executeQuery();
                 PreparedStatement totalRevenueStmt = con.prepareStatement(totalRevenueQuery);
                 ResultSet totalRevenueRs = totalRevenueStmt.executeQuery();
                 PreparedStatement avgAttendanceStmt = con.prepareStatement(avgAttendanceQuery);
                 ResultSet avgAttendanceRs = avgAttendanceStmt.executeQuery();
                 PreparedStatement pendingTicketsStmt = con.prepareStatement(pendingTicketsQuery);
                 ResultSet pendingTicketsRs = pendingTicketsStmt.executeQuery();
                 PreparedStatement totalProfitStmt = con.prepareStatement(totalProfitQuery);
                 ResultSet totalProfitRs = totalProfitStmt.executeQuery();
                 PreparedStatement totalLossStmt = con.prepareStatement(totalLossQuery);
                 ResultSet totalLossRs = totalLossStmt.executeQuery()) {

                // Use simple labels without emojis
                String[] labels = {"Total Events", "Current Events", "Tickets Sold", "Revenue (30d)", "Avg Attendance", "Pending Tickets", "Profit", "Loss"};
                ResultSet[] resultSets = {totalEventsRs, currentEventsRs, totalTicketsRs, totalRevenueRs, avgAttendanceRs, pendingTicketsRs, totalProfitRs, totalLossRs};
                
                Color[] backgroundColors = {
                    new Color(220, 240, 255), new Color(220, 255, 240), new Color(255, 245, 220), 
                    new Color(220, 255, 220), new Color(255, 240, 245), new Color(255, 255, 220), 
                    new Color(230, 255, 230), new Color(255, 230, 230)
                };
                
                Color[] borderColors = {
                    new Color(100, 150, 255), new Color(100, 200, 100), new Color(255, 180, 80), 
                    new Color(80, 180, 80), new Color(255, 120, 150), new Color(255, 200, 80), 
                    new Color(80, 200, 120), new Color(255, 100, 100)
                };
                
                for (int i = 0; i < labels.length; i++) {
                    JPanel statPanel = new JPanel(new BorderLayout());
                    statPanel.setBackground(backgroundColors[i]);
                    statPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(borderColors[i], 2, true),
                        BorderFactory.createEmptyBorder(12, 12, 12, 12)
                    ));
                    
                    statPanel.setOpaque(true);
                    
                    JLabel title = new JLabel(labels[i], JLabel.CENTER);
                    title.setFont(new Font("Arial", Font.BOLD, 12));
                    title.setForeground(new Color(60, 60, 60));
                    
                    String value = "0";
                    try {
                        if (resultSets[i].next()) {
                            value = resultSets[i].getString(1);
                            if (value == null) value = "0";
                            
                            // Format currency values
                            if (labels[i].contains("Revenue") || labels[i].contains("Profit") || labels[i].contains("Loss")) {
                                double numericValue = Double.parseDouble(value);
                                value = currencyFormat.format(numericValue);
                            }
                            // Format average attendance
                            else if (labels[i].equals("Avg Attendance")) {
                                double numericValue = Double.parseDouble(value);
                                value = String.format("%.1f", numericValue);
                            }
                            // For count values, ensure they're integers
                            else if (labels[i].equals("Total Events") || labels[i].equals("Current Events") || 
                                     labels[i].equals("Tickets Sold") || labels[i].equals("Pending Tickets")) {
                                int intValue = (int) Double.parseDouble(value);
                                value = String.valueOf(intValue);
                            }
                        }
                    } catch (NumberFormatException e) {
                        value = "0";
                        System.err.println("Error parsing value for " + labels[i] + ": " + e.getMessage());
                    }
                    
                    JLabel valueLabel = new JLabel(value, JLabel.CENTER);
                    valueLabel.setFont(new Font("Arial", Font.BOLD, 18));
                    
                    // Color coding
                    if (labels[i].contains("Revenue")) {
                        valueLabel.setForeground(new Color(0, 100, 0));
                        valueLabel.setFont(new Font("Arial", Font.BOLD, 16));
                    } else if (labels[i].contains("Profit")) {
                        try {
                            double profitValue = Double.parseDouble(value.replace("₹", "").replace(",", ""));
                            if (profitValue > 0) {
                                valueLabel.setForeground(new Color(0, 150, 0));
                                valueLabel.setFont(new Font("Arial", Font.BOLD, 17));
                            } else if (profitValue < 0) {
                                valueLabel.setForeground(Color.RED);
                                valueLabel.setFont(new Font("Arial", Font.BOLD, 16));
                            } else {
                                valueLabel.setForeground(new Color(0, 0, 139));
                            }
                        } catch (NumberFormatException e) {
                            valueLabel.setForeground(new Color(0, 0, 139));
                        }
                    } else if (labels[i].contains("Loss")) {
                        try {
                            double lossValue = Double.parseDouble(value.replace("₹", "").replace(",", ""));
                            if (lossValue > 0) {
                                valueLabel.setForeground(Color.RED);
                                valueLabel.setFont(new Font("Arial", Font.BOLD, 16));
                            } else {
                                valueLabel.setForeground(new Color(0, 0, 139));
                            }
                        } catch (NumberFormatException e) {
                            valueLabel.setForeground(new Color(0, 0, 139));
                        }
                    } else {
                        valueLabel.setForeground(new Color(0, 0, 139));
                    }
                    
                    JPanel contentPanel = new JPanel(new BorderLayout(5, 5));
                    contentPanel.setOpaque(false);
                    
                    // Use simple ASCII characters instead of problematic emojis
                    JLabel iconLabel = new JLabel(getMetricIcon(labels[i]), JLabel.CENTER);
                    iconLabel.setFont(new Font("Arial", Font.PLAIN, 20));
                    iconLabel.setForeground(borderColors[i].darker());
                    
                    contentPanel.add(iconLabel, BorderLayout.NORTH);
                    contentPanel.add(title, BorderLayout.CENTER);
                    contentPanel.add(valueLabel, BorderLayout.SOUTH);
                    
                    statPanel.add(contentPanel, BorderLayout.CENTER);
                    analyticsGrid.add(statPanel);
                }
                
            } // Resources automatically closed here

        } catch (SQLException ex) {
            ex.printStackTrace();
            JLabel errorLabel = new JLabel("Error loading analytics data", JLabel.CENTER);
            errorLabel.setForeground(Color.RED);
            errorLabel.setFont(new Font("Arial", Font.BOLD, 14));
            analyticsGrid.add(errorLabel);
            
            System.err.println("SQL Error in createAdvancedAnalyticsPanel: " + ex.getMessage());
            ex.printStackTrace();
        }
        
        panel.add(analyticsGrid, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(new Color(240, 245, 255));
        
        JButton exportPdfButton = new JButton("Export Analytics PDF");
        exportPdfButton.setBackground(new Color(70, 130, 180));
        exportPdfButton.setForeground(Color.WHITE);
        exportPdfButton.setFont(new Font("Arial", Font.BOLD, 12));
        exportPdfButton.setFocusPainted(false);
        exportPdfButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        exportPdfButton.addActionListener(e -> generateAnalyticsPDF());
        
        bottomPanel.add(exportPdfButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    // Helper method to get icons for metrics - using ASCII characters
    private String getMetricIcon(String metric) {
        switch (metric) {
            case "Total Events":
                return "E"; // Events
            case "Current Events":
                return "C"; // Current
            case "Tickets Sold":
                return "T"; // Tickets
            case "Revenue (30d)":
                return "₹"; // Revenue
            case "Avg Attendance":
                return "A"; // Attendance
            case "Pending Tickets":
                return "P"; // Pending
            case "Profit":
                return "+"; // Profit
            case "Loss":
                return "-"; // Loss
            default:
                return "•"; // Default bullet
        }
    }


    private void generateAnalyticsPDF() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("system_analytics_report.pdf"));
            fileChooser.setDialogTitle("Save Comprehensive Analytics PDF Report");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                final String filePath = getFinalFilePath(fileChooser); // Make it final
                
                // Show progress dialog
                JProgressBar progressBar = new JProgressBar(0, 100);
                progressBar.setStringPainted(true);
                JOptionPane progressDialog = new JOptionPane(
                    new Object[]{"Generating comprehensive analytics report...", progressBar},
                    JOptionPane.INFORMATION_MESSAGE,
                    JOptionPane.DEFAULT_OPTION,
                    null,
                    new Object[]{}
                );
                JDialog dialog = progressDialog.createDialog(this, "Generating Analytics PDF");
                dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
                
                SwingWorker<Boolean, Integer> worker = new SwingWorker<Boolean, Integer>() {
                    @Override
                    protected Boolean doInBackground() throws Exception {
                        publish(10);
                        // Generate the comprehensive analytics report
                        boolean success = revenuePDFGenerator.generateAnalyticsReport(filePath);
                        publish(100);
                        return success;
                    }
                    
                    @Override
                    protected void process(java.util.List<Integer> chunks) {
                        int progress = chunks.get(chunks.size() - 1);
                        progressBar.setValue(progress);
                        
                        // Update progress message based on stage
                        if (progress < 30) {
                            progressBar.setString("Processing financial data...");
                        } else if (progress < 60) {
                            progressBar.setString("Analyzing event performance...");
                        } else if (progress < 90) {
                            progressBar.setString("Generating insights and recommendations...");
                        } else {
                            progressBar.setString("Finalizing report...");
                        }
                    }
                    
                    @Override
                    protected void done() {
                        dialog.dispose();
                        try {
                            boolean success = get();
                            if (success) {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Comprehensive Analytics PDF Generated Successfully!\n\n" +
                                    "Report includes:\n" +
                                    "• Executive Summary & KPIs\n" +
                                    "• Financial Deep Dive Analysis\n" +
                                    "• Event Performance Analytics\n" +
                                    "• User & Organizer Insights\n" +
                                    "• Booking & Payment Analysis\n" +
                                    "• System Engagement Metrics\n" +
                                    "• Risk Assessment & Recommendations\n\n" +
                                    "Saved to: " + filePath, 
                                    "Analytics Report Complete", 
                                    JOptionPane.INFORMATION_MESSAGE);
                                
                                int openFile = JOptionPane.showConfirmDialog(Admin.this,
                                    "Do you want to open the generated PDF report?",
                                    "Open Analytics Report",
                                    JOptionPane.YES_NO_OPTION);
                                
                                if (openFile == JOptionPane.YES_OPTION) {
                                    openPDFFile(filePath);
                                }
                            } else {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Failed to generate analytics PDF report.\n" +
                                    "Please check the system logs for details.", 
                                    "Generation Failed", 
                                    JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(Admin.this, 
                                "Error generating analytics PDF:\n" + ex.getMessage() + 
                                "\n\nPlease ensure all database connections are working properly.", 
                                "Generation Error", 
                                JOptionPane.ERROR_MESSAGE);
                        }
                    }
                };
                
                worker.execute();
                dialog.setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error initializing PDF generation:\n" + ex.getMessage(), 
                "Initialization Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openPDFFile(String filePath) {
        try {
            File file = new File(filePath);
            if (file.exists()) {
                Desktop.getDesktop().open(file);
            } else {
                JOptionPane.showMessageDialog(this,
                    "PDF file not found: " + filePath +
                    "\nThe file may have been moved or deleted.",
                    "File Not Found",
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                "Error opening PDF file: " + ex.getMessage() +
                "\n\nPlease ensure you have a PDF reader installed.",
                "Open Error",
                JOptionPane.ERROR_MESSAGE);
        } catch (UnsupportedOperationException ex) {
            JOptionPane.showMessageDialog(this,
                "Opening PDF files is not supported on this system." +
                "\nPlease open the file manually from: " + filePath,
                "Unsupported Operation",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void generateEventsPDFReport() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("events_complete_report.pdf"));
            fileChooser.setDialogTitle("Save Events PDF Report");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                final String finalFilePath = getFinalFilePath(fileChooser);
                
                JProgressBar progressBar = new JProgressBar(0, 100);
                progressBar.setStringPainted(true);
                JOptionPane progressDialog = new JOptionPane(
                    new Object[]{"Generating Events PDF report...", progressBar},
                    JOptionPane.INFORMATION_MESSAGE,
                    JOptionPane.DEFAULT_OPTION,
                    null,
                    new Object[]{}
                );
                JDialog dialog = progressDialog.createDialog(this, "Exporting Events PDF");
                dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
                
                SwingWorker<Boolean, Integer> worker = new SwingWorker<Boolean, Integer>() {
                    @Override
                    protected Boolean doInBackground() throws Exception {
                        publish(20);
                        boolean success = revenuePDFGenerator.generateEventsReport(finalFilePath);
                        publish(100);
                        return success;
                    }
                    
                    @Override
                    protected void process(java.util.List<Integer> chunks) {
                        int progress = chunks.get(chunks.size() - 1);
                        progressBar.setValue(progress);
                    }
                    
                    @Override
                    protected void done() {
                        dialog.dispose();
                        try {
                            boolean success = get();
                            if (success) {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Events PDF report generated successfully!\nSaved to: " + finalFilePath, 
                                    "Success", JOptionPane.INFORMATION_MESSAGE);
                                
                                int openFile = JOptionPane.showConfirmDialog(Admin.this,
                                    "Do you want to open the generated PDF file?",
                                    "Open PDF File",
                                    JOptionPane.YES_NO_OPTION);
                                
                                if (openFile == JOptionPane.YES_OPTION) {
                                    openPDFFile(finalFilePath);
                                }
                            } else {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Failed to generate events PDF report.", 
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(Admin.this, 
                                "Error generating events PDF: " + ex.getMessage(), 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                };
                
                worker.execute();
                dialog.setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error generating events PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getFinalFilePath(JFileChooser fileChooser) {
        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
        if (!filePath.toLowerCase().endsWith(".pdf")) {
            return filePath + ".pdf";
        }
        return filePath;
    }

    private void generateDashboardPDF() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("dashboard_complete_report.pdf"));
            fileChooser.setDialogTitle("Save Dashboard Complete Report");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                final String filePath = getFinalFilePath(fileChooser); // Make it final
                
                JProgressBar progressBar = new JProgressBar(0, 100);
                progressBar.setStringPainted(true);
                JOptionPane progressDialog = new JOptionPane(
                    new Object[]{"Generating PDF report...", progressBar},
                    JOptionPane.INFORMATION_MESSAGE,
                    JOptionPane.DEFAULT_OPTION,
                    null,
                    new Object[]{}
                );
                JDialog dialog = progressDialog.createDialog(this, "Exporting PDF");
                dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
                
                SwingWorker<Boolean, Integer> worker = new SwingWorker<Boolean, Integer>() {
                    @Override
                    protected Boolean doInBackground() throws Exception {
                        publish(10);
                        boolean success = generateComprehensiveDashboardReport(filePath);
                        publish(100);
                        return success;
                    }
                    
                    @Override
                    protected void process(java.util.List<Integer> chunks) {
                        int progress = chunks.get(chunks.size() - 1);
                        progressBar.setValue(progress);
                    }
                    
                    @Override
                    protected void done() {
                        dialog.dispose();
                        try {
                            boolean success = get();
                            if (success) {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Dashboard PDF report generated successfully!\nSaved to: " + filePath, 
                                    "Success", JOptionPane.INFORMATION_MESSAGE);
                                
                                int openFile = JOptionPane.showConfirmDialog(Admin.this,
                                    "Do you want to open the generated PDF file?",
                                    "Open PDF File",
                                    JOptionPane.YES_NO_OPTION);
                                
                                if (openFile == JOptionPane.YES_OPTION) {
                                    openPDFFile(filePath);
                                }
                            } else {
                                JOptionPane.showMessageDialog(Admin.this, 
                                    "Failed to generate dashboard PDF report.", 
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(Admin.this, 
                                "Error generating dashboard PDF: " + ex.getMessage(), 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                };
                
                worker.execute();
                dialog.setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error generating dashboard PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    private boolean generateComprehensiveDashboardReport(String filePath) {
        try {
            return revenuePDFGenerator.generateRevenueReport(filePath);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    private void generateRevenuePDF() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("revenue_analytics_report.pdf"));
            fileChooser.setDialogTitle("Save Revenue Analytics Report");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".pdf")) {
                    filePath += ".pdf";
                }
                
                boolean success = revenuePDFGenerator.generateRevenueReport(filePath);
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "Revenue analytics PDF report generated successfully!\nSaved to: " + filePath, 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to generate revenue analytics PDF report.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error generating revenue PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    private void generateSelectedEventsPDF() {
        boolean foundSelected = false;
        java.util.List<String> selectedEventIds = new java.util.ArrayList<>();
        
        for (int i = 0; i < eventsTableModel.getRowCount(); i++) {
            if (eventsTable.isRowSelected(i)) {
                foundSelected = true;
                String eventId = (String) eventsTableModel.getValueAt(i, 0);
                selectedEventIds.add(eventId);
            }
        }
        
        if (!foundSelected) {
            showEventSelectionDialog();
            return;
        }
        
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("selected_events_report.pdf"));
            fileChooser.setDialogTitle("Save Selected Events Report");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".pdf")) {
                    filePath += ".pdf";
                }
                
                boolean success = pdfGenerator.generateSelectedEventsReport(selectedEventIds, filePath);
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "Selected events PDF report generated successfully!\nSaved to: " + filePath, 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to generate selected events PDF report.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error generating selected events PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showEventSelectionDialog() {
        JDialog selectDialog = new JDialog(this, "Select Events for PDF Report", true);
        selectDialog.setLayout(new BorderLayout());
        selectDialog.setSize(600, 400);
        
        String[] columns = {"Select", "Event Code", "Title", "Organizer", "Date", "Status"};
        DefaultTableModel selectModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 0;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Boolean.class;
                return Object.class;
            }
        };
        
        JTable selectTable = new JTable(selectModel);
        
        try {
            String sql = "SELECT e.event_code, e.title, o.firstname, o.lastname, e.event_date, e.status " +
                        "FROM events e JOIN organizers o ON e.organizer_id = o.organizer_id " +
                        "ORDER BY e.event_date DESC";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                selectModel.addRow(new Object[]{
                    false,
                    rs.getString("event_code"),
                    rs.getString("title"),
                    rs.getString("firstname") + " " + rs.getString("lastname"),
                    rs.getTimestamp("event_date"),
                    rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        JScrollPane scrollPane = new JScrollPane(selectTable);
        selectDialog.add(scrollPane, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton generateButton = new JButton("Generate PDF");
        JButton cancelButton = new JButton("Cancel");
        
        generateButton.addActionListener(e -> {
            java.util.List<String> selectedCodes = new java.util.ArrayList<>();
            for (int i = 0; i < selectModel.getRowCount(); i++) {
                Boolean selected = (Boolean) selectModel.getValueAt(i, 0);
                if (selected != null && selected) {
                    selectedCodes.add((String) selectModel.getValueAt(i, 1));
                }
            }
            
            if (selectedCodes.isEmpty()) {
                JOptionPane.showMessageDialog(selectDialog, 
                    "Please select at least one event.", 
                    "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            selectDialog.dispose();
            
            try {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setSelectedFile(new File("selected_events_report.pdf"));
                fileChooser.setDialogTitle("Save Selected Events Report");
                
                int result = fileChooser.showSaveDialog(this);
                
                if (result == JFileChooser.APPROVE_OPTION) {
                    String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                    if (!filePath.toLowerCase().endsWith(".pdf")) {
                        filePath += ".pdf";
                    }
                    
                    boolean success = pdfGenerator.generateSelectedEventsReport(selectedCodes, filePath);
                    if (success) {
                        JOptionPane.showMessageDialog(this, 
                            "Selected events PDF report generated successfully!\nSaved to: " + filePath, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, 
                            "Failed to generate selected events PDF report.", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error generating selected events PDF: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> selectDialog.dispose());
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(generateButton);
        selectDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        selectDialog.setLocationRelativeTo(this);
        selectDialog.setVisible(true);
    }

    private void refreshDashboardData() {
        quickRefreshDashboard();
    }

    private JPanel createLossChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Loss Analysis Chart"));

        DefaultTableModel model = new DefaultTableModel(new String[]{"Event", "Unsold Tickets", "Potential Loss", "Date"}, 0);
        JTable table = new JTable(model);

        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(220, 53, 69));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (column == 1 || column == 2) {
                    c.setBackground(new Color(255, 230, 230));
                } else {
                    if (!isSelected) {
                        c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                    }
                }
                return c;
            }
        });

        try {
            String sql = "SELECT e.title, " +
                         "(e.capacity - e.tickets_sold) as unsold_tickets, " +
                         "((e.capacity - e.tickets_sold) * e.price) as potential_loss, " +
                         "e.event_date " +
                         "FROM events e " +
                         "WHERE e.event_date < CURDATE() AND e.status = 'Approved' " +
                         "ORDER BY potential_loss DESC LIMIT 10";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            java.text.DecimalFormat df = new java.text.DecimalFormat("#,##0.00");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    rs.getInt("unsold_tickets"),
                    "₹" + df.format(rs.getDouble("potential_loss")),
                    new SimpleDateFormat("MMM dd, yyyy").format(rs.getTimestamp("event_date"))
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JScrollPane createOrganizersTablePanel() {
        String[] columns = {"Select", "Organizer ID", "First Name", "Last Name", "Email", "Mobile", "Company", "Verified", "Created At", "Actions"};
        organizersTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 0 || column == 9;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Boolean.class;
                return Object.class;
            }
        };
        organizersTable = new JTable(organizersTableModel);

        organizersTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        organizersTable.getTableHeader().setBackground(new Color(102, 51, 153));
        organizersTable.getTableHeader().setForeground(Color.WHITE);
        organizersTable.setRowHeight(28);
        organizersTable.setFont(new Font("Arial", Font.PLAIN, 14));

        organizersTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        organizersTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        organizersTable.getColumn("Actions").setCellEditor(new OrganizerButtonEditor(new JCheckBox(), con, this, organizersTable));

        return new JScrollPane(organizersTable);
    }

    private JPanel createOrganizerActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        JButton registerButton = new JButton("Register New Organizer");
        JButton verifyButton = new JButton("Verify Selected");
        JButton unverifyButton = new JButton("Unverify Selected");
        JButton pdfSelectedButton = new JButton("PDF Selected");
        JButton refreshButton = new JButton("Refresh");
        JButton exportButton = new JButton("Export to PDF");

        for (JButton btn : new JButton[]{registerButton, verifyButton, unverifyButton, pdfSelectedButton, refreshButton, exportButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(102, 51, 153));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(180, 30));
        }

        registerButton.setBackground(new Color(40, 167, 69));
        registerButton.setPreferredSize(new Dimension(200, 30));
        pdfSelectedButton.setBackground(new Color(220, 53, 69));

        registerButton.addActionListener(e -> registerNewOrganizer());
        verifyButton.addActionListener(e -> verifySelectedOrganizer());
        unverifyButton.addActionListener(e -> unverifySelectedOrganizer());
        pdfSelectedButton.addActionListener(e -> generateSelectedOrganizerPDF());
        refreshButton.addActionListener(e -> loadOrganizersData());
        exportButton.addActionListener(e -> exportOrganizersToPDF());

        panel.add(registerButton);
        panel.add(verifyButton);
        panel.add(unverifyButton);
        panel.add(pdfSelectedButton);
        panel.add(refreshButton);
        panel.add(exportButton);
        return panel;
    }

    private void generateSelectedOrganizerPDF() {
        boolean foundSelected = false;
        
        for (int i = 0; i < organizersTableModel.getRowCount(); i++) {
            Boolean selected = (Boolean) organizersTableModel.getValueAt(i, 0);
            if (selected != null && selected) {
                foundSelected = true;
                String organizerId = (String) organizersTableModel.getValueAt(i, 1);
                String organizerName = organizersTableModel.getValueAt(i, 2) + " " + organizersTableModel.getValueAt(i, 3);
                
                try {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setSelectedFile(new File("organizer_" + organizerId + "_report.pdf"));
                    fileChooser.setDialogTitle("Save Organizer PDF Report");
                    
                    int result = fileChooser.showSaveDialog(this);
                    
                    if (result == JFileChooser.APPROVE_OPTION) {
                        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                        if (!filePath.toLowerCase().endsWith(".pdf")) {
                            filePath += ".pdf";
                        }
                        
                        boolean success = pdfGenerator.generateOrganizerPDF(organizerId, filePath);
                        if (success) {
                            JOptionPane.showMessageDialog(this, 
                                "PDF report generated successfully for organizer: " + organizerName + 
                                "\nSaved to: " + filePath, 
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(this, 
                                "Failed to generate PDF report for organizer: " + organizerName, 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Error generating PDF for organizer " + organizerName + ": " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        
        if (!foundSelected) {
            JOptionPane.showMessageDialog(this, 
                "Please select at least one organizer to generate PDF report.", 
                "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }

    private JScrollPane createUsersTablePanel() {
        String[] columns = {"Select", "Customer ID", "Username", "First Name", "Last Name", "Email", "Mobile", "Gender", "Status", "Join Date", "Actions"};
        usersTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 0 || column == 10;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Boolean.class;
                return Object.class;
            }
        };
        usersTable = new JTable(usersTableModel);

        usersTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        usersTable.getTableHeader().setBackground(new Color(65, 105, 225));
        usersTable.getTableHeader().setForeground(Color.WHITE);
        usersTable.setRowHeight(28);
        usersTable.setFont(new Font("Arial", Font.PLAIN, 14));

        usersTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        usersTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        usersTable.getColumn("Actions").setCellEditor(new ButtonEditor(new JCheckBox(), con, this, usersTable));

        return new JScrollPane(usersTable);
    }

    private JPanel createUserActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        JButton refreshButton = new JButton("Refresh");
        JButton pdfSelectedButton = new JButton("PDF Selected");
        JButton exportButton = new JButton("Export to PDF");

        for (JButton btn : new JButton[]{refreshButton, pdfSelectedButton, exportButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(140, 30));
        }
        
        pdfSelectedButton.setBackground(new Color(220, 53, 69));

        refreshButton.addActionListener(e -> loadUsersData());
        pdfSelectedButton.addActionListener(e -> generateSelectedCustomerPDF());
        exportButton.addActionListener(e -> exportUsersToPDF());

        panel.add(refreshButton);
        panel.add(pdfSelectedButton);
        panel.add(exportButton);
        return panel;
    }

    private void generateSelectedCustomerPDF() {
        boolean foundSelected = false;
        
        for (int i = 0; i < usersTableModel.getRowCount(); i++) {
            Boolean selected = (Boolean) usersTableModel.getValueAt(i, 0);
            if (selected != null && selected) {
                foundSelected = true;
                String memberId = (String) usersTableModel.getValueAt(i, 1);
                String customerName = usersTableModel.getValueAt(i, 3) + " " + usersTableModel.getValueAt(i, 4);
                
                try {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setSelectedFile(new File("customer_" + memberId + "_report.pdf"));
                    fileChooser.setDialogTitle("Save Customer PDF Report");
                    
                    int result = fileChooser.showSaveDialog(this);
                    
                    if (result == JFileChooser.APPROVE_OPTION) {
                        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                        if (!filePath.toLowerCase().endsWith(".pdf")) {
                            filePath += ".pdf";
                        }
                        
                        boolean success = pdfGenerator.generateCustomerPDF(memberId, filePath);
                        if (success) {
                            JOptionPane.showMessageDialog(this, 
                                "PDF report generated successfully for customer: " + customerName + 
                                "\nSaved to: " + filePath, 
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(this, 
                                "Failed to generate PDF report for customer: " + customerName, 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Error generating PDF for customer " + customerName + ": " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        
        if (!foundSelected) {
            JOptionPane.showMessageDialog(this, 
                "Please select at least one customer to generate PDF report.", 
                "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void refreshDashboard(JPanel gridPanel, JPanel footer) {
        gridPanel.removeAll();

        dashboardStats = createStatsPanel();
        dashboardActivity = createRecentActivityTable();
        dashboardRevenue = createRevenueChart();
        dashboardLoss = createAdvancedAnalyticsPanel();

        gridPanel.add(dashboardStats);
        gridPanel.add(dashboardActivity);
        gridPanel.add(dashboardRevenue);
        gridPanel.add(dashboardLoss);

        refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));

        gridPanel.revalidate();
        gridPanel.repaint();
        footer.revalidate();
        footer.repaint();
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        try {
            String[] queries = {
                "SELECT COUNT(*) FROM members",
                "SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()",
                "SELECT COUNT(*) FROM bookings WHERE booking_date >= CURDATE() - INTERVAL 30 DAY",
                "SELECT SUM(total_amount) FROM payments WHERE payment_status = 'Success' AND payment_date >= CURDATE() - INTERVAL 30 DAY"
            };

            String[] labels = {"Total Users", "Upcoming Events", "Bookings (30 days)", "Revenue (30 days)"};
            Color[] colors = {new Color(135, 206, 250), new Color(144, 238, 144), new Color(255, 182, 193), new Color(255, 228, 181)};

            for (int i = 0; i < queries.length; i++) {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(queries[i]);
                if (rs.next()) {
                    JPanel statCard = new JPanel(new BorderLayout());
                    statCard.setBackground(colors[i]);
                    statCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.GRAY, 1, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    ));

                    JLabel title = new JLabel(labels[i], JLabel.CENTER);
                    title.setFont(new Font("Segoe UI", Font.BOLD, 14));
                    title.setForeground(Color.DARK_GRAY);

                    String valueText = rs.getString(1);
                    if (valueText == null) valueText = "0";

                    JLabel value = new JLabel(valueText, JLabel.CENTER);
                    value.setFont(new Font("Segoe UI", Font.BOLD, 20));
                    value.setForeground(new Color(0, 102, 204));

                    statCard.add(title, BorderLayout.NORTH);
                    statCard.add(value, BorderLayout.CENTER);
                    statsPanel.add(statCard);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading statistics: " + ex.getMessage());
        }

        return statsPanel;
    }
    

    private JScrollPane createRecentActivityTable() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"User", "Activity", "Date"}, 0);
        JTable table = new JTable(model);
        
        table.setFillsViewportHeight(true);
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(60, 179, 113));
        table.getTableHeader().setForeground(Color.WHITE);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        try {
            String sql = "SELECT m.username, 'Booking' AS activity, b.booking_date AS activity_date " +
                         "FROM bookings b " +
                         "JOIN members m ON b.user_id = m.member_id " +
                         "WHERE b.booking_date >= CURDATE() - INTERVAL 7 DAY " +
                         "UNION ALL " +
                         "SELECT m.username, 'Registration' AS activity, m.created_at AS activity_date " +
                         "FROM members m " +
                         "WHERE m.created_at >= CURDATE() - INTERVAL 7 DAY " +
                         "ORDER BY activity_date DESC LIMIT 10";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("username"),
                    rs.getString("activity"),
                    rs.getTimestamp("activity_date")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        return scrollPane;
    }

    private JPanel createRevenueChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60, 179, 113), 2),
            "Revenue & Financial Analytics",
            TitledBorder.DEFAULT_JUSTIFICATION,
            TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(60, 179, 113)
        ));

        DefaultTableModel model = new DefaultTableModel(new String[]{"Month", "Revenue", "Profit", "Loss", "Profit Margin"}, 0);
        JTable table = new JTable(model);

        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(60, 179, 113));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setGridColor(new Color(220, 220, 220));

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                    
                    if (column == 1) { // Revenue column
                        c.setForeground(new Color(0, 100, 0));
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (column == 2) { // Profit column
                        if (value != null) {
                            String profitStr = value.toString().replace("₹", "").replace(",", "").replace("+", "");
                            try {
                                double profit = Double.parseDouble(profitStr);
                                if (profit > 0) {
                                    c.setForeground(new Color(0, 150, 0));
                                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                                } else if (profit < 0) {
                                    c.setForeground(Color.RED);
                                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                                }
                            } catch (NumberFormatException e) {
                                // Ignore formatting errors
                            }
                        }
                    } else if (column == 3) { // Loss column
                        if (value != null && !value.toString().equals("₹0.00")) {
                            c.setForeground(Color.RED);
                        }
                    } else if (column == 4) { // Profit Margin column
                        if (value != null) {
                            String marginStr = value.toString().replace("%", "");
                            try {
                                double margin = Double.parseDouble(marginStr);
                                if (margin > 20) {
                                    c.setForeground(new Color(0, 150, 0));
                                } else if (margin < 0) {
                                    c.setForeground(Color.RED);
                                }
                            } catch (NumberFormatException e) {
                                // Ignore formatting errors
                            }
                        }
                    }
                }
                return c;
            }
        });

        try {
            // SIMPLIFIED AND CORRECTED REVENUE QUERY
            String sql = "SELECT " +
                        "DATE_FORMAT(payment_date, '%Y-%m') as month, " +
                        "COALESCE(SUM(total_amount), 0) as revenue, " +
                        "COALESCE(SUM(total_amount * 0.85), 0) as profit, " + // 15% platform commission
                        "COALESCE(SUM(total_amount * 0.15), 0) as loss " + // 15% as operational cost/loss
                        "FROM payments " +
                        "WHERE payment_status = 'Success' " +
                        "GROUP BY DATE_FORMAT(payment_date, '%Y-%m') " +
                        "ORDER BY month DESC " +
                        "LIMIT 12";
            
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            java.text.DecimalFormat df = new java.text.DecimalFormat("#,##0.00");
            java.text.DecimalFormat percentFormat = new java.text.DecimalFormat("0.0'%'");

            while (rs.next()) {
                double revenue = rs.getDouble("revenue");
                double profit = rs.getDouble("profit");
                double loss = rs.getDouble("loss");
                
                // Calculate profit margin
                double profitMargin = revenue > 0 ? (profit / revenue) * 100 : 0;
                
                String profitFormatted = (profit >= 0 ? "+" : "") + "₹" + df.format(Math.abs(profit));
                
                model.addRow(new Object[]{
                    rs.getString("month"),
                    "₹" + df.format(revenue),
                    profitFormatted,
                    "₹" + df.format(loss),
                    percentFormat.format(profitMargin)
                });
            }
            
            // Add summary row
            if (model.getRowCount() > 0) {
                double totalRevenue = 0;
                double totalProfit = 0;
                double totalLoss = 0;
                
                for (int i = 0; i < model.getRowCount(); i++) {
                    totalRevenue += Double.parseDouble(model.getValueAt(i, 1).toString().replace("₹", "").replace(",", ""));
                    totalProfit += Double.parseDouble(model.getValueAt(i, 2).toString().replace("+", "").replace("₹", "").replace(",", ""));
                    totalLoss += Double.parseDouble(model.getValueAt(i, 3).toString().replace("₹", "").replace(",", ""));
                }
                
                double overallMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
                String overallProfitFormatted = (totalProfit >= 0 ? "+" : "") + "₹" + df.format(Math.abs(totalProfit));
                
                model.addRow(new Object[]{"-----", "-----", "-----", "-----", "-----"});
                model.addRow(new Object[]{
                    "TOTAL",
                    "₹" + df.format(totalRevenue),
                    overallProfitFormatted,
                    "₹" + df.format(totalLoss),
                    percentFormat.format(overallMargin)
                });
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            model.addRow(new Object[]{"Error", "Check", "Database", "Connection", "---"});
            JOptionPane.showMessageDialog(this, 
                "Error loading revenue data: " + ex.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(new Color(240, 248, 255));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        String headerText = "Financial Overview: Revenue, Profit/Loss, and Margins by Month";
        JLabel infoLabel = new JLabel(headerText);
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoLabel.setForeground(new Color(60, 60, 60));
        headerPanel.add(infoLabel);
        
        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JPanel legendPanel = createFinancialLegend();
        panel.add(legendPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private JPanel createFinancialLegend() {
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        legendPanel.setBackground(new Color(245, 248, 255));
        legendPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JLabel revenueLegend = new JLabel("Revenue");
        revenueLegend.setForeground(new Color(0, 100, 0));
        revenueLegend.setFont(new Font("Arial", Font.BOLD, 11));
        
        JLabel profitLegend = new JLabel("Profit");
        profitLegend.setForeground(new Color(0, 150, 0));
        profitLegend.setFont(new Font("Arial", Font.BOLD, 11));
        
        JLabel lossLegend = new JLabel("Loss");
        lossLegend.setForeground(Color.RED);
        lossLegend.setFont(new Font("Arial", Font.BOLD, 11));
        
        JLabel marginLegend = new JLabel("Margin: Green(>20%) | Orange(10-20%) | Red(<10%)");
        marginLegend.setForeground(new Color(60, 60, 60));
        marginLegend.setFont(new Font("Arial", Font.PLAIN, 10));
        
        legendPanel.add(revenueLegend);
        legendPanel.add(new JLabel("•"));
        legendPanel.add(profitLegend);
        legendPanel.add(new JLabel("•"));
        legendPanel.add(lossLegend);
        legendPanel.add(new JLabel("•"));
        legendPanel.add(marginLegend);
        
        return legendPanel;
    }
    
    // FIXED: Events table now allows editing previous events
    private JScrollPane createEventsTablePanel() {
        String[] columns = {"Event Code", "Title", "Organizer", "Start Date", "End Date", "Venue", "Tickets Sold", "Break-even", "Revenue", "Status", "Actions"};
        eventsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // FIXED: Allow editing for ALL events (including previous ones)
                // Only make Status and Actions columns editable
                return column == 9 || column == 10; // Status and Actions columns are editable
            }
        };
        eventsTable = new JTable(eventsTableModel);

        eventsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        eventsTable.getTableHeader().setBackground(new Color(65, 105, 225));
        eventsTable.getTableHeader().setForeground(Color.WHITE);
        eventsTable.setRowHeight(28);
        eventsTable.setFont(new Font("Arial", Font.PLAIN, 14));
        
        eventsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus, 
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                Color backgroundColor = row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE;
                
                try {
                    Object endDateObj = table.getModel().getValueAt(row, 4); // End Date column
                    Object ticketsSoldObj = table.getModel().getValueAt(row, 6); // Tickets Sold column
                    Object breakEvenObj = table.getModel().getValueAt(row, 7); // Break-even column
                    
                    if (endDateObj != null && ticketsSoldObj != null && breakEvenObj != null) {
                        String endDateStr = endDateObj.toString();
                        int ticketsSold = Integer.parseInt(ticketsSoldObj.toString());
                        int breakEven = Integer.parseInt(breakEvenObj.toString());
                        
                        // Parse the date from the formatted string in the table
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                        Date endDate = dateFormat.parse(endDateStr);
                        Date currentDate = new Date();
                        
                        // If event has ended (finished)
                        if (endDate.before(currentDate)) {
                            if (ticketsSold >= breakEven) {
                                // ✅ FINISHED & PROFITABLE - Light Green
                                backgroundColor = new Color(220, 255, 220);
                            } else {
                                // ❌ FINISHED & LOSS - Light Red
                                backgroundColor = new Color(255, 220, 220);
                            }
                        } 
                        // If event is current (ongoing or upcoming)
                        else {
                            // 🔵 CURRENT EVENT - Light Blue
                            backgroundColor = new Color(220, 235, 255);
                            
                            // Show progress for current events
                            if (breakEven > 0) {
                                double progress = (ticketsSold * 100.0) / breakEven;
                                if (progress >= 100) {
                                    // 🟢 CURRENT & REACHED BREAK-EVEN - Light Mint Green
                                    backgroundColor = new Color(220, 255, 240);
                                } else if (progress >= 50) {
                                    // 🟡 CURRENT & GOOD PROGRESS - Light Yellow
                                    backgroundColor = new Color(255, 255, 220);
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    // If any parsing error, use default background
                    backgroundColor = row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE;
                }
                
                // Apply the background color
                c.setBackground(backgroundColor);
                
                // Handle selection - make it darker
                if (isSelected) {
                    c.setBackground(backgroundColor.darker());
                }
                
                return c;
            }
        });

        eventsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        eventsTable.getColumn("Actions").setCellEditor(new EventButtonEditor(new JCheckBox(), con, this, eventsTable));

        return new JScrollPane(eventsTable);
    }
    

    private JPanel createSettingsForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel nameLabel = new JLabel("System Name:");
        panel.add(nameLabel, gbc);

        gbc.gridx = 1;
        JTextField systemName = new JTextField(15);
        systemName.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(systemName, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel commissionLabel = new JLabel("Commission Rate (%):");
        commissionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(commissionLabel, gbc);

        gbc.gridx = 1;
        JTextField commissionField = new JTextField(7);
        commissionField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(commissionField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel autoApproveLabel = new JLabel("Auto-approve Events:");
        autoApproveLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(autoApproveLabel, gbc);

        gbc.gridx = 1;
        JCheckBox autoApprove = new JCheckBox();
        panel.add(autoApprove, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel maxEventsLabel = new JLabel("Max Events per Organizer:");
        maxEventsLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(maxEventsLabel, gbc);

        gbc.gridx = 1;
        JTextField maxEvents = new JTextField(7);
        maxEvents.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(maxEvents, gbc);

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton saveButton = new JButton("Save Settings");
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.setBackground(new Color(65, 105, 225));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new Dimension(180, 35));

        saveButton.addActionListener(e -> saveSettings(
                systemName.getText(),
                commissionField.getText(),
                autoApprove.isSelected(),
                maxEvents.getText()
        ));
        panel.add(saveButton, gbc);

        loadCurrentSettings(systemName, commissionField, autoApprove, maxEvents);

        return panel;
    }

    private void loadCurrentSettings(JTextField systemName, JTextField commission, JCheckBox autoApprove, JTextField maxEvents) {
        try {
            String sql = "SELECT * FROM SystemSettings WHERE id = 1";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                systemName.setText(rs.getString("system_name"));
                commission.setText(String.valueOf(rs.getDouble("commission_rate")));
                autoApprove.setSelected(rs.getBoolean("auto_approve_events"));
                maxEvents.setText(String.valueOf(rs.getInt("max_events_per_organizer")));
            } else {
                String insertSql = "INSERT INTO SystemSettings (system_name, commission_rate, auto_approve_events, max_events_per_organizer) " +
                                   "VALUES ('Event Management System', 5.0, false, 10)";
                stmt.executeUpdate(insertSql);

                systemName.setText("Event Management System");
                commission.setText("5.0");
                autoApprove.setSelected(false);
                maxEvents.setText("10");
            }

            Font fieldFont = new Font("Arial", Font.PLAIN, 14);
            systemName.setFont(fieldFont);
            commission.setFont(fieldFont);
            autoApprove.setFont(fieldFont);
            maxEvents.setFont(fieldFont);

            systemName.setPreferredSize(new Dimension(250, 30));
            commission.setPreferredSize(new Dimension(100, 30));
            maxEvents.setPreferredSize(new Dimension(100, 30));

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading settings: " + ex.getMessage());
        }
    }

    private void saveSettings(String systemName, String commission, boolean autoApprove, String maxEvents) {
        try {
            String sql = "UPDATE SystemSettings SET system_name=?, commission_rate=?, auto_approve_events=?, max_events_per_organizer=? WHERE id=1";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, systemName);
            ps.setDouble(2, Double.parseDouble(commission));
            ps.setBoolean(3, autoApprove);
            ps.setInt(4, Integer.parseInt(maxEvents));

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "✅ Settings saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Error saving settings: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    void loadUsersData() {
        try {
            String sql = "SELECT member_id, username, firstname, lastname, email, mobile, gender, active, created_at FROM members";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            usersTableModel.setRowCount(0);
            while (rs.next()) {
                usersTableModel.addRow(new Object[]{
                        false,
                        rs.getString("member_id"),
                        rs.getString("username"),
                        rs.getString("firstname"),
                        rs.getString("lastname"),
                        rs.getString("email"),
                        rs.getString("mobile"),
                        rs.getString("gender"),
                        rs.getBoolean("active") ? "Active" : "Inactive",
                        rs.getDate("created_at"),
                        "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    

    void loadAllEvents() {
        try {
            String sql = "SELECT e.event_code, e.title, o.firstname, o.lastname, " +
                         "e.start_date, e.end_date, e.venue, e.tickets_sold, " +
                         "e.break_even_tickets, e.revenue, e.status " +
                         "FROM events e " +
                         "JOIN organizers o ON e.organizer_id = o.organizer_id " +
                         "ORDER BY e.start_date DESC";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            eventsTableModel.setRowCount(0);

            while (rs.next()) {
                String organizerName = rs.getString("firstname") + " " + rs.getString("lastname");
                eventsTableModel.addRow(new Object[]{
                        rs.getString("event_code"),
                        rs.getString("title"),
                        organizerName,
                        formatDateTime(rs.getString("start_date")),
                        formatDateTime(rs.getString("end_date")),
                        rs.getString("venue"),
                        rs.getInt("tickets_sold"),
                        rs.getInt("break_even_tickets"),
                        "₹" + String.format("%.2f", rs.getDouble("revenue")),
                        rs.getString("status"),
                        "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading events: " + ex.getMessage());
        }
    }

    private String formatDateTime(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
            Date date = inputFormat.parse(dateTime);
            return outputFormat.format(date);
        } catch (Exception e) {
            return dateTime;
        }
    }

    void loadOrganizersData() {
        try {
            String sql = "SELECT organizer_id, firstname, lastname, email, mobile, company_name, verified, created_at FROM organizers";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            organizersTableModel.setRowCount(0);
            while (rs.next()) {
                organizersTableModel.addRow(new Object[]{
                        false,
                        rs.getString("organizer_id"),
                        rs.getString("firstname"),
                        rs.getString("lastname"),
                        rs.getString("email"),
                        rs.getString("mobile"),
                        rs.getString("company_name"),
                        rs.getBoolean("verified") ? "Verified" : "Not Verified",
                        rs.getTimestamp("created_at"),
                        "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadRecentActivity() {
        // Implementation for recent activity
    }

    private void exportOrganizersToPDF() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("organizers_report.pdf"));
            fileChooser.setDialogTitle("Export Organizers to PDF");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".pdf")) {
                    filePath += ".pdf";
                }
                
                boolean success = pdfGenerator.generateOrganizersReport(filePath);
                
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "PDF report generated successfully!", "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to generate PDF report.", "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), "Export Failed", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportUsersToPDF() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("users_report.pdf"));
            fileChooser.setDialogTitle("Export Users to PDF");
            
            int result = fileChooser.showSaveDialog(this);
            
            if (result == JFileChooser.APPROVE_OPTION) {
                String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".pdf")) {
                    filePath += ".pdf";
                }
                
                boolean success = pdfGenerator.generateUsersReport(filePath);
                
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "PDF report generated successfully!", "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to generate PDF report.", "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), "Export Failed", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verifySelectedOrganizer() {
        boolean foundSelected = false;
        
        for (int i = 0; i < organizersTableModel.getRowCount(); i++) {
            Boolean selected = (Boolean) organizersTableModel.getValueAt(i, 0);
            if (selected != null && selected) {
                foundSelected = true;
                String organizerId = (String) organizersTableModel.getValueAt(i, 1);
                String organizerName = organizersTableModel.getValueAt(i, 2) + " " + organizersTableModel.getValueAt(i, 3);
                
                try {
                    String sql = "UPDATE organizers SET verified = 1 WHERE organizer_id = ?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, organizerId);
                    
                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(this, "Organizer '" + organizerName + "' verified successfully!");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error verifying organizer: " + ex.getMessage());
                }
            }
        }
        
        if (foundSelected) {
            loadOrganizersData();
        } else {
            JOptionPane.showMessageDialog(this, "Please select at least one organizer to verify.");
        }
    }

    private void unverifySelectedOrganizer() {
        boolean foundSelected = false;
        
        for (int i = 0; i < organizersTableModel.getRowCount(); i++) {
            Boolean selected = (Boolean) organizersTableModel.getValueAt(i, 0);
            if (selected != null && selected) {
                foundSelected = true;
                String organizerId = (String) organizersTableModel.getValueAt(i, 1);
                String organizerName = organizersTableModel.getValueAt(i, 2) + " " + organizersTableModel.getValueAt(i, 3);
                
                try {
                    String sql = "UPDATE organizers SET verified = 0 WHERE organizer_id = ?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, organizerId);
                    
                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(this, "Organizer '" + organizerName + "' unverified successfully!");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error unverifying organizer: " + ex.getMessage());
                }
            }
        }
        
        if (foundSelected) {
            loadOrganizersData();
        } else {
            JOptionPane.showMessageDialog(this, "Please select at least one organizer to unverify.");
        }
    }

    private void registerNewOrganizer() {
        JDialog registerDialog = new JDialog(this, "Register New Organizer", true);
        registerDialog.setLayout(new GridBagLayout());
        registerDialog.setSize(500, 600);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel idLabel = new JLabel("Organizer ID:");
        registerDialog.add(idLabel, gbc);

        gbc.gridx = 1;
        String generatedId = "ORG" + System.currentTimeMillis() % 10000;
        JTextField idField = new JTextField(generatedId);
        idField.setEditable(false);
        idField.setBackground(new Color(240, 240, 240));
        registerDialog.add(idField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel firstNameLabel = new JLabel("First Name:");
        registerDialog.add(firstNameLabel, gbc);

        gbc.gridx = 1;
        JTextField firstNameField = new JTextField(20);
        registerDialog.add(firstNameField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel lastNameLabel = new JLabel("Last Name:");
        registerDialog.add(lastNameLabel, gbc);

        gbc.gridx = 1;
        JTextField lastNameField = new JTextField(20);
        registerDialog.add(lastNameField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel emailLabel = new JLabel("Email:");
        registerDialog.add(emailLabel, gbc);

        gbc.gridx = 1;
        JTextField emailField = new JTextField(20);
        registerDialog.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel mobileLabel = new JLabel("Mobile:");
        registerDialog.add(mobileLabel, gbc);

        gbc.gridx = 1;
        JTextField mobileField = new JTextField(20);
        registerDialog.add(mobileField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel companyLabel = new JLabel("Company Name:");
        registerDialog.add(companyLabel, gbc);

        gbc.gridx = 1;
        JTextField companyField = new JTextField(20);
        registerDialog.add(companyField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel addressLabel = new JLabel("Address:");
        registerDialog.add(addressLabel, gbc);

        gbc.gridx = 1;
        JTextArea addressArea = new JTextArea(3, 20);
        JScrollPane addressScroll = new JScrollPane(addressArea);
        registerDialog.add(addressScroll, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel passwordLabel = new JLabel("Password:");
        registerDialog.add(passwordLabel, gbc);

        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(20);
        registerDialog.add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        JLabel verifiedLabel = new JLabel("Verified:");
        registerDialog.add(verifiedLabel, gbc);

        gbc.gridx = 1;
        JCheckBox verifiedCheckbox = new JCheckBox("Mark as verified");
        registerDialog.add(verifiedCheckbox, gbc);

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton saveButton = new JButton("Register Organizer");
        saveButton.setBackground(new Color(40, 167, 69));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(108, 117, 125));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));

        saveButton.addActionListener(e -> {
            // Enhanced validation from Organizer.java
            if (firstNameField.getText().trim().isEmpty() || 
                lastNameField.getText().trim().isEmpty() ||
                emailField.getText().trim().isEmpty() ||
                mobileField.getText().trim().isEmpty() ||
                passwordField.getPassword().length == 0) {
                
                JOptionPane.showMessageDialog(registerDialog, 
                    "Please fill in all required fields!", "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Email validation
            if (!isValidEmail(emailField.getText().trim())) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Please enter a valid email address.", 
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Mobile validation
            if (!isValidMobile(mobileField.getText().trim())) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Please enter a valid mobile number (10-15 digits).", 
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                String sql = "INSERT INTO organizers (organizer_id, firstname, lastname, email, mobile, " +
                           "company_name, address, password, verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, idField.getText());
                ps.setString(2, firstNameField.getText().trim());
                ps.setString(3, lastNameField.getText().trim());
                ps.setString(4, emailField.getText().trim());
                ps.setString(5, mobileField.getText().trim());
                ps.setString(6, companyField.getText().trim());
                ps.setString(7, addressArea.getText().trim());
                ps.setString(8, new String(passwordField.getPassword()));
                ps.setBoolean(9, verifiedCheckbox.isSelected());

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Organizer registered successfully!", "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    registerDialog.dispose();
                    loadOrganizersData();
                }
            } catch (SQLException ex) {
                if (ex.getErrorCode() == 1062) {
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Email or mobile number already exists!", "Registration Error", 
                        JOptionPane.ERROR_MESSAGE);
                } else {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Error registering organizer: " + ex.getMessage(), "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener(e -> registerDialog.dispose());

        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        registerDialog.add(buttonPanel, gbc);

        registerDialog.setLocationRelativeTo(this);
        registerDialog.setVisible(true);
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    private boolean isValidMobile(String mobile) {
        return mobile.matches("\\d{10,15}");
    }

    private void approveSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to approve.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        
        try {
            String sql = "UPDATE Events SET status = 'Approved' WHERE event_code = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, eventCode);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Event approved successfully!");
                loadAllEvents();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error approving event: " + ex.getMessage());
        }
    }
    
    private void rejectSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to reject.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        
        try {
            String sql = "UPDATE Events SET status = 'Rejected' WHERE event_code = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, eventCode);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Event rejected successfully!");
                loadAllEvents();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error rejecting event: " + ex.getMessage());
        }
    }
    
    private void featureSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to feature.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        String eventTitle = (String) eventsTableModel.getValueAt(selectedRow, 1);
        
        JOptionPane.showMessageDialog(this, "Event '" + eventTitle + "' has been featured!");
    }

    @Override
    public void dispose() {
        DBConnection.closeConnection(con);
        super.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Admin("1"));
    }
}

// The rest of the supporting classes (AdminChat, EventButtonEditor, ButtonRenderer, etc.)
// remain the same as in your original code...

// Complete AdminChat Class

// EventButtonEditor class
class EventButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Admin admin;
    private JTable table;

    public EventButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
        super(checkBox);
        this.con = con;
        this.admin = admin;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        try {
            String endDateStr = (String) table.getModel().getValueAt(row, 4);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
            Date endDate = dateFormat.parse(endDateStr);
            if (endDate.before(new java.util.Date())) {
                button.setEnabled(false);
                button.setBackground(Color.GRAY);
            } else {
                button.setEnabled(true);
                button.setBackground(new Color(40, 167, 69));
            }
        } catch (Exception e) {
            button.setEnabled(true);
            button.setBackground(new Color(40, 167, 69));
        }
        
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            try {
                String endDateStr = (String) table.getModel().getValueAt(row, 4);
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                Date endDate = dateFormat.parse(endDateStr);
                if (endDate.before(new java.util.Date())) {
                    JOptionPane.showMessageDialog(admin, "Cannot edit past events.", "Read Only", JOptionPane.WARNING_MESSAGE);
                    return label;
                }
            } catch (Exception e) {
            }
            
            String eventCode = (String) table.getModel().getValueAt(row, 0);
            showEventEditDialog(eventCode);
        }
        isPushed = false;
        return label;
    }
    
    private void showEventEditDialog(String eventCode) {
        JDialog editDialog = new JDialog(admin, "Edit Event", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        editDialog.setSize(500, 400);
        
        JTextField titleField = new JTextField();
        JTextArea descriptionArea = new JTextArea(3, 20);
        JTextField venueField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField capacityField = new JTextField();
        JTextField breakEvenField = new JTextField();
        JComboBox<String> categoryCombo = new JComboBox<>(new String[]{"Music", "Sports", "Conference", "Workshop", "Exhibition", "Party", "Wedding"});
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Pending", "Approved", "Rejected", "Cancelled"});
        
        JDateChooser startDateChooser = new JDateChooser();
        startDateChooser.setDateFormatString("yyyy-MM-dd");
        JDateChooser endDateChooser = new JDateChooser();
        endDateChooser.setDateFormatString("yyyy-MM-dd");
        
        JTextField startTimeField = new JTextField(6);
        JTextField endTimeField = new JTextField(6);
        
        try {
            String sql = "SELECT * FROM Events WHERE event_code = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, eventCode);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                titleField.setText(rs.getString("title"));
                descriptionArea.setText(rs.getString("description"));
                venueField.setText(rs.getString("venue"));
                priceField.setText(String.valueOf(rs.getDouble("price")));
                capacityField.setText(String.valueOf(rs.getInt("capacity")));
                breakEvenField.setText(String.valueOf(rs.getInt("break_even_tickets")));
                categoryCombo.setSelectedItem(rs.getString("category"));
                statusCombo.setSelectedItem(rs.getString("status"));
                
                // Parse and set start/end dates
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date startDate = dateFormat.parse(rs.getString("start_date"));
                Date endDate = dateFormat.parse(rs.getString("end_date"));
                
                startDateChooser.setDate(startDate);
                endDateChooser.setDate(endDate);
                
                // Extract times
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
                startTimeField.setText(timeFormat.format(startDate));
                endTimeField.setText(timeFormat.format(endDate));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("Event Code:"));
        editDialog.add(new JLabel(eventCode));
        editDialog.add(new JLabel("Title:"));
        editDialog.add(titleField);
        editDialog.add(new JLabel("Description:"));
        editDialog.add(new JScrollPane(descriptionArea));
        editDialog.add(new JLabel("Venue:"));
        editDialog.add(venueField);
        editDialog.add(new JLabel("Price:"));
        editDialog.add(priceField);
        editDialog.add(new JLabel("Capacity:"));
        editDialog.add(capacityField);
        editDialog.add(new JLabel("Break-even Tickets:"));
        editDialog.add(breakEvenField);
        editDialog.add(new JLabel("Category:"));
        editDialog.add(categoryCombo);
        editDialog.add(new JLabel("Start Date:"));
        editDialog.add(startDateChooser);
        editDialog.add(new JLabel("Start Time (HH:MM):"));
        editDialog.add(startTimeField);
        editDialog.add(new JLabel("End Date:"));
        editDialog.add(endDateChooser);
        editDialog.add(new JLabel("End Time (HH:MM):"));
        editDialog.add(endTimeField);
        editDialog.add(new JLabel("Status:"));
        editDialog.add(statusCombo);
        
        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(40, 167, 69));
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(e -> {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String startDatePart = dateFormat.format(startDateChooser.getDate());
                String endDatePart = dateFormat.format(endDateChooser.getDate());
                
                String startDateTime = startDatePart + " " + startTimeField.getText() + ":00";
                String endDateTime = endDatePart + " " + endTimeField.getText() + ":00";

                String updateSql = "UPDATE Events SET title=?, description=?, venue=?, price=?, capacity=?, " +
                                 "break_even_tickets=?, category=?, status=?, start_date=?, end_date=? " +
                                 "WHERE event_code=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, titleField.getText());
                ps.setString(2, descriptionArea.getText());
                ps.setString(3, venueField.getText());
                ps.setDouble(4, Double.parseDouble(priceField.getText()));
                ps.setInt(5, Integer.parseInt(capacityField.getText()));
                ps.setInt(6, Integer.parseInt(breakEvenField.getText()));
                ps.setString(7, (String) categoryCombo.getSelectedItem());
                ps.setString(8, (String) statusCombo.getSelectedItem());
                ps.setString(9, startDateTime);
                ps.setString(10, endDateTime);
                ps.setString(11, eventCode);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Event updated successfully!");
                    editDialog.dispose();
                    admin.loadAllEvents();
                }
            } catch (SQLException | NumberFormatException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating event: " + ex.getMessage());
            }
        });
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(108, 117, 125));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(e -> editDialog.dispose());
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        
        editDialog.add(new JLabel(""));
        editDialog.add(buttonPanel);
        
        editDialog.setLocationRelativeTo(admin);
        editDialog.setVisible(true);
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

//Button Renderer and Editor Classes
class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
 public ButtonRenderer() {
     setOpaque(true);
 }

 public Component getTableCellRendererComponent(JTable table, Object value,
                                                boolean isSelected, boolean hasFocus, int row, int column) {
     setText((value == null) ? "Edit" : value.toString());
     setBackground(new Color(65, 105, 225));
     setForeground(Color.WHITE);
     setFont(new Font("Arial", Font.BOLD, 12));
     setFocusPainted(false);
     return this;
 }
}

class ButtonEditor extends DefaultCellEditor {
 protected JButton button;
 private String label;
 private boolean isPushed;
 private Connection con;
 private Admin admin;
 private JTable table;

 public ButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
     super(checkBox);
     this.con = con;
     this.admin = admin;
     this.table = table;
     button = new JButton();
     button.setOpaque(true);
     button.addActionListener(e -> fireEditingStopped());
 }

 public Component getTableCellEditorComponent(JTable table, Object value,
                                              boolean isSelected, int row, int column) {
     label = (value == null) ? "Edit" : value.toString();
     button.setText(label);
     button.setBackground(new Color(40, 167, 69));
     button.setForeground(Color.WHITE);
     button.setFont(new Font("Arial", Font.BOLD, 12));
     button.setFocusPainted(false);
     isPushed = true;
     return button;
 }

 public Object getCellEditorValue() {
     if (isPushed) {
         int row = table.getSelectedRow();
         String memberId = (String) table.getModel().getValueAt(row, 1);
         showUserEditDialog(memberId);
     }
     isPushed = false;
     return label;
 }
 
 
 private void showUserEditDialog(String memberId) {
     JDialog editDialog = new JDialog(admin, "Edit User", true);
     editDialog.setLayout(new GridLayout(0, 2, 5, 5));
     editDialog.setSize(400, 300);
     
     JTextField usernameField = new JTextField();
     JTextField firstnameField = new JTextField();
     JTextField lastnameField = new JTextField();
     JTextField emailField = new JTextField();
     JTextField mobileField = new JTextField();
     JComboBox<String> genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
     JCheckBox activeCheckbox = new JCheckBox("Active");
     
     try {
         String sql = "SELECT * FROM members WHERE member_id = ?";
         PreparedStatement ps = con.prepareStatement(sql);
         ps.setString(1, memberId);
         ResultSet rs = ps.executeQuery();
         
         if (rs.next()) {
             usernameField.setText(rs.getString("username"));
             firstnameField.setText(rs.getString("firstname"));
             lastnameField.setText(rs.getString("lastname"));
             emailField.setText(rs.getString("email"));
             mobileField.setText(rs.getString("mobile"));
             genderCombo.setSelectedItem(rs.getString("gender"));
             activeCheckbox.setSelected(rs.getBoolean("active"));
         }
     } catch (SQLException ex) {
         ex.printStackTrace();
         JOptionPane.showMessageDialog(editDialog, "Error loading user data: " + ex.getMessage());
     }
     
     editDialog.add(new JLabel("Username:"));
     editDialog.add(usernameField);
     editDialog.add(new JLabel("First Name:"));
     editDialog.add(firstnameField);
     editDialog.add(new JLabel("Last Name:"));
     editDialog.add(lastnameField);
     editDialog.add(new JLabel("Email:"));
     editDialog.add(emailField);
     editDialog.add(new JLabel("Mobile:"));
     editDialog.add(mobileField);
     editDialog.add(new JLabel("Gender:"));
     editDialog.add(genderCombo);
     editDialog.add(new JLabel("Status:"));
     editDialog.add(activeCheckbox);
     
     JButton saveButton = new JButton("Save");
     saveButton.setBackground(new Color(40, 167, 69));
     saveButton.setForeground(Color.WHITE);
     saveButton.addActionListener(e -> {
         try {
             String updateSql = "UPDATE members SET username=?, firstname=?, lastname=?, email=?, mobile=?, gender=?, active=? WHERE member_id=?";
             PreparedStatement ps = con.prepareStatement(updateSql);
             ps.setString(1, usernameField.getText());
             ps.setString(2, firstnameField.getText());
             ps.setString(3, lastnameField.getText());
             ps.setString(4, emailField.getText());
             ps.setString(5, mobileField.getText());
             ps.setString(6, (String) genderCombo.getSelectedItem());
             ps.setBoolean(7, activeCheckbox.isSelected());
             ps.setString(8, memberId);
             
             if (ps.executeUpdate() > 0) {
                 JOptionPane.showMessageDialog(editDialog, "User updated successfully!");
                 editDialog.dispose();
                 admin.loadUsersData();
             }
         } catch (SQLException ex) {
             ex.printStackTrace();
             JOptionPane.showMessageDialog(editDialog, "Error updating user: " + ex.getMessage());
         }
     });
     
     JButton cancelButton = new JButton("Cancel");
     cancelButton.setBackground(new Color(108, 117, 125));
     cancelButton.setForeground(Color.WHITE);
     cancelButton.addActionListener(e -> editDialog.dispose());
     
     JPanel buttonPanel = new JPanel(new FlowLayout());
     buttonPanel.add(cancelButton);
     buttonPanel.add(saveButton);
     
     editDialog.add(new JLabel(""));
     editDialog.add(buttonPanel);
     
     editDialog.setLocationRelativeTo(admin);
     editDialog.setVisible(true);
 }

 public boolean stopCellEditing() {
     isPushed = false;
     return super.stopCellEditing();
 }
}

class OrganizerButtonEditor extends DefaultCellEditor {
 protected JButton button;
 private String label;
 private boolean isPushed;
 private Connection con;
 private Admin admin;
 private JTable table;

 public OrganizerButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
     super(checkBox);
     this.con = con;
     this.admin = admin;
     this.table = table;
     button = new JButton();
     button.setOpaque(true);
     button.addActionListener(e -> fireEditingStopped());
 }

 public Component getTableCellEditorComponent(JTable table, Object value,
                                              boolean isSelected, int row, int column) {
     label = (value == null) ? "Edit" : value.toString();
     button.setText(label);
     button.setBackground(new Color(40, 167, 69));
     button.setForeground(Color.WHITE);
     button.setFont(new Font("Arial", Font.BOLD, 12));
     button.setFocusPainted(false);
     isPushed = true;
     return button;
 }

 public Object getCellEditorValue() {
     if (isPushed) {
         int row = table.getSelectedRow();
         String organizerId = (String) table.getModel().getValueAt(row, 1);
         showOrganizerEditDialog(organizerId);
     }
     isPushed = false;
     return label;
 }
 
 private void showOrganizerEditDialog(String organizerId) {
     JDialog editDialog = new JDialog(admin, "Edit Organizer", true);
     editDialog.setLayout(new GridLayout(0, 2, 5, 5));
     editDialog.setSize(500, 400);
     
     JTextField firstnameField = new JTextField();
     JTextField lastnameField = new JTextField();
     JTextField emailField = new JTextField();
     JTextField mobileField = new JTextField();
     JTextField companyField = new JTextField();
     JTextArea addressArea = new JTextArea(3, 20);
     JCheckBox verifiedCheckbox = new JCheckBox("Verified");
     
     try {
         String sql = "SELECT * FROM organizers WHERE organizer_id = ?";
         PreparedStatement ps = con.prepareStatement(sql);
         ps.setString(1, organizerId);
         ResultSet rs = ps.executeQuery();
         
         if (rs.next()) {
             firstnameField.setText(rs.getString("firstname"));
             lastnameField.setText(rs.getString("lastname"));
             emailField.setText(rs.getString("email"));
             mobileField.setText(rs.getString("mobile"));
             companyField.setText(rs.getString("company_name"));
             addressArea.setText(rs.getString("address"));
             verifiedCheckbox.setSelected(rs.getBoolean("verified"));
         }
     } catch (SQLException ex) {
         ex.printStackTrace();
         JOptionPane.showMessageDialog(editDialog, "Error loading organizer data: " + ex.getMessage());
     }
     
     editDialog.add(new JLabel("First Name:"));
     editDialog.add(firstnameField);
     editDialog.add(new JLabel("Last Name:"));
     editDialog.add(lastnameField);
     editDialog.add(new JLabel("Email:"));
     editDialog.add(emailField);
     editDialog.add(new JLabel("Mobile:"));
     editDialog.add(mobileField);
     editDialog.add(new JLabel("Company:"));
     editDialog.add(companyField);
     editDialog.add(new JLabel("Address:"));
     editDialog.add(new JScrollPane(addressArea));
     editDialog.add(new JLabel("Verified:"));
     editDialog.add(verifiedCheckbox);
     
     JButton saveButton = new JButton("Save");
     saveButton.setBackground(new Color(40, 167, 69));
     saveButton.setForeground(Color.WHITE);
     saveButton.addActionListener(e -> {
         try {
             String updateSql = "UPDATE organizers SET firstname=?, lastname=?, email=?, mobile=?, company_name=?, address=?, verified=? WHERE organizer_id=?";
             PreparedStatement ps = con.prepareStatement(updateSql);
             ps.setString(1, firstnameField.getText());
             ps.setString(2, lastnameField.getText());
             ps.setString(3, emailField.getText());
             ps.setString(4, mobileField.getText());
             ps.setString(5, companyField.getText());
             ps.setString(6, addressArea.getText());
             ps.setBoolean(7, verifiedCheckbox.isSelected());
             ps.setString(8, organizerId);
             
             if (ps.executeUpdate() > 0) {
                 JOptionPane.showMessageDialog(editDialog, "Organizer updated successfully!");
                 editDialog.dispose();
                 admin.loadOrganizersData();
             }
         } catch (SQLException ex) {
             ex.printStackTrace();
             JOptionPane.showMessageDialog(editDialog, "Error updating organizer: " + ex.getMessage());
         }
     });
     
     JButton cancelButton = new JButton("Cancel");
     cancelButton.setBackground(new Color(108, 117, 125));
     cancelButton.setForeground(Color.WHITE);
     cancelButton.addActionListener(e -> editDialog.dispose());
     
     JPanel buttonPanel = new JPanel(new FlowLayout());
     buttonPanel.add(cancelButton);
     buttonPanel.add(saveButton);
     
     editDialog.add(new JLabel(""));
     editDialog.add(buttonPanel);
     
     editDialog.setLocationRelativeTo(admin);
     editDialog.setVisible(true);
 }
 

 public boolean stopCellEditing() {
     isPushed = false;
     return super.stopCellEditing();
 }
}
