package com.Event_Management.System;

import Connectors.DBConnection;
import java.sql.*;
import java.util.Properties;

import java.io.File;
import java.io.FileOutputStream;

public class EmailService {
    
    // Email configuration - UPDATE THESE WITH YOUR EMAIL CREDENTIALS
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    private static final String USERNAME = "youremail@gmail.com";
    private static final String PASSWORD = "your-app-password";
    private static final String FROM_EMAIL = "youremail@gmail.com";
    
    public static boolean sendBookingConfirmation(String bookingId, String customerEmail) {
        try {
            // Generate PDF invoice
            String pdfFilePath = generateBookingPDF(bookingId);
            
            if (pdfFilePath != null) {
                boolean sent = sendEmailWithAttachment(customerEmail, 
                    "Event Booking Confirmation - Booking ID: " + bookingId,
                    getEmailBody(bookingId),
                    pdfFilePath);
                
                // Clean up PDF file
                new File(pdfFilePath).delete();
                return sent;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private static String generateBookingPDF(String bookingId) {
        String filePath = System.getProperty("java.io.tmpdir") + "/booking_" + bookingId + ".pdf";
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, b.ticket_count, b.total_amount, b.booking_date, " +
                        "e.title, e.venue, e.event_date, e.price, " +
                        "m.firstname, m.lastname, m.email, m.mobile " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "JOIN members m ON b.user_id = m.member_id " +
                        "WHERE b.booking_id = ?";
            
            ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                // Simple text-based PDF generation (you can enhance this with iTextPDF later)
                StringBuilder pdfContent = new StringBuilder();
                pdfContent.append("EVENT BOOKING CONFIRMATION\n");
                pdfContent.append("==========================\n\n");
                pdfContent.append("Booking ID: ").append(rs.getString("booking_id")).append("\n");
                pdfContent.append("Customer: ").append(rs.getString("firstname")).append(" ").append(rs.getString("lastname")).append("\n");
                pdfContent.append("Email: ").append(rs.getString("email")).append("\n");
                pdfContent.append("Mobile: ").append(rs.getString("mobile")).append("\n\n");
                pdfContent.append("Event Details:\n");
                pdfContent.append("-------------\n");
                pdfContent.append("Title: ").append(rs.getString("title")).append("\n");
                pdfContent.append("Venue: ").append(rs.getString("venue")).append("\n");
                pdfContent.append("Date: ").append(rs.getString("event_date")).append("\n\n");
                pdfContent.append("Booking Details:\n");
                pdfContent.append("---------------\n");
                pdfContent.append("Tickets: ").append(rs.getInt("ticket_count")).append("\n");
                pdfContent.append("Price per Ticket: $").append(rs.getDouble("price")).append("\n");
                pdfContent.append("Total Amount: $").append(rs.getDouble("total_amount")).append("\n");
                pdfContent.append("Booking Date: ").append(rs.getString("booking_date")).append("\n\n");
                pdfContent.append("Thank you for your booking!\n");
                
                // Write to file
                try (FileOutputStream fos = new FileOutputStream(filePath)) {
                    fos.write(pdfContent.toString().getBytes());
                }
                return filePath;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    
    private static String getEmailBody(String bookingId) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, b.ticket_count, b.total_amount, " +
                        "e.title, e.venue, e.event_date, " +
                        "m.firstname " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "JOIN members m ON b.user_id = m.member_id " +
                        "WHERE b.booking_id = ?";
            
            ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                return "Dear " + rs.getString("firstname") + ",\n\n" +
                       "Your event booking has been confirmed!\n\n" +
                       "Booking Details:\n" +
                       "---------------\n" +
                       "Booking ID: " + rs.getString("booking_id") + "\n" +
                       "Event: " + rs.getString("title") + "\n" +
                       "Venue: " + rs.getString("venue") + "\n" +
                       "Event Date: " + rs.getString("event_date") + "\n" +
                       "Tickets: " + rs.getInt("ticket_count") + "\n" +
                       "Total Amount: $" + rs.getDouble("total_amount") + "\n\n" +
                       "Please find your detailed invoice attached.\n\n" +
                       "Thank you for choosing our Event Management System!\n\n" +
                       "Best regards,\nEvent Management Team";
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return "Your booking has been confirmed. Booking ID: " + bookingId;
    }
    
    private static boolean sendEmailWithAttachment(String toEmail, String subject, String body, String attachmentPath) {
        // For now, just log the email (you can implement actual email sending later)
        System.out.println("=== EMAIL WOULD BE SENT ===");
        System.out.println("To: " + toEmail);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);
        System.out.println("Attachment: " + attachmentPath);
        System.out.println("===========================");
        
        // Return true for testing purposes
        // To implement actual email, uncomment the code below and add javax.mail dependency
        
        /*
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        });
        
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setText(body);
            
            Transport.send(message);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        */
        
        return true;
    }
}