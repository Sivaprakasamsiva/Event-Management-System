package com.Mavan.EventManagementSystem.Organizer;



import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.Mavan.EventManagementSystem.App;
import com.Mavan.EventManagementSystem.DBConnection.DBConnection;
import com.Mavan.EventManagementSystem.OrganizerChat.OrganizerChat;
import com.toedter.calendar.JDateChooser;


import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import javax.swing.table.TableCellRenderer;
import java.awt.Component;
import java.util.Date;

public class Organizer extends JFrame {
    private String organizerId;
    private Connection con;
    private JTable eventsTable;
    private DefaultTableModel eventsTableModel;
    private JPanel analyticsPanel;
    private JPanel analyticsGridPanel;
    private JLabel refreshLabel;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    
    // Add currency format for Indian Rupee
    private static final java.text.DecimalFormat currencyFormat = new java.text.DecimalFormat("₹#,##0.00");
    private static final double USD_TO_INR_RATE = 1; // Conversion rate

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Organizer("ORG003"));
    }

    public Organizer(String organizerId) {
        super("Organizer Dashboard - Event Management System");
        this.organizerId = organizerId;

        // Initialize database connection using DBConnection
        con = DBConnection.getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database. Application will exit.");
            System.exit(1);
        }

        setupUI();
        setSize(1200, 800); // Increased size to match Admin
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel with logout button
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JTabbedPane tabs = new JTabbedPane();

        // Tab 1: My Events
        JPanel eventsPanel = new JPanel(new BorderLayout());
        eventsPanel.add(createEventsTablePanel(), BorderLayout.CENTER);
        eventsPanel.add(createEventActionsPanel(), BorderLayout.SOUTH);

        // Tab 2: Create Event
        JPanel createEventPanel = new JPanel(new GridBagLayout());
        createEventPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        createEventPanel.add(createEventForm());

        // Tab 3: Analytics
        analyticsPanel = new JPanel(new BorderLayout());
        analyticsGridPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        analyticsGridPanel.add(createRevenueChart());
        analyticsGridPanel.add(createAttendanceChart());
        analyticsGridPanel.add(createTopEventsTable());
        analyticsGridPanel.add(createSummaryPanel());
        analyticsPanel.add(analyticsGridPanel, BorderLayout.CENTER);

        // Refresh label at bottom-right
        refreshLabel = new JLabel("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));
        refreshLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.add(refreshLabel);
        analyticsPanel.add(footer, BorderLayout.SOUTH);

        // Auto refresh every 30 sec to match Admin
        new javax.swing.Timer(30000, e -> refreshAnalyticsTab()).start();

        // Tab 4: Profile
        JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
        profilePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        profilePanel.add(createProfilePanel(), BorderLayout.CENTER);

        tabs.add("📊 My Events", eventsPanel);
        tabs.add("🚀 Create Event", createEventPanel);
        tabs.add("📈 Analytics", analyticsPanel);
        tabs.add("👤 Profile", profilePanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);
        loadOrganizerEvents();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(65, 105, 225)); // Matching Admin blue
        headerPanel.setPreferredSize(new Dimension(1200, 50));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel titleLabel = new JLabel("Organizer Dashboard - Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Larger font like Admin
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setOpaque(false);

        // Enhanced Chat Button matching Admin style
        JButton chatButton = new JButton("Organizer Chat");
        chatButton.setFont(new Font("Arial", Font.BOLD, 12));
        chatButton.setBackground(new Color(32, 107, 16));
        chatButton.setForeground(Color.WHITE);
        chatButton.setFocusPainted(false);
        chatButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 85, 12), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        chatButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effects like Admin
        chatButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                chatButton.setBackground(new Color(25, 85, 12));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                chatButton.setBackground(new Color(32, 107, 16));
            }
        });

        chatButton.addActionListener(e -> {
        	SwingUtilities.invokeLater(() -> new OrganizerChat(organizerId));
        });

        // Enhanced Logout Button matching Admin style
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setBackground(new Color(220, 53, 69));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 35, 50), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effects
        logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutButton.setBackground(new Color(180, 35, 50));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                logoutButton.setBackground(new Color(220, 53, 69));
            }
        });
        
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            if (confirm == JOptionPane.YES_OPTION) {
                DBConnection.closeConnection(con);
                dispose();
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "Logged out successfully!", "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    SwingUtilities.invokeLater(App::new);
                });
            }
        });

        buttonPanel.add(chatButton);
        buttonPanel.add(logoutButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);

        return headerPanel;
    }

    private void refreshAnalyticsTab() {
        analyticsPanel.remove(analyticsGridPanel);

        analyticsGridPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        analyticsGridPanel.add(createRevenueChart());
        analyticsGridPanel.add(createAttendanceChart());
        analyticsGridPanel.add(createTopEventsTable());
        analyticsGridPanel.add(createSummaryPanel());

        analyticsPanel.add(analyticsGridPanel, BorderLayout.CENTER);
        refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));

        analyticsPanel.revalidate();
        analyticsPanel.repaint();
    }

    private JPanel createEventActionsPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.setBorder(BorderFactory.createTitledBorder("Event Actions"));
        actionPanel.setBackground(new Color(240, 240, 240)); // Matching Admin background

        JButton createButton = new JButton("Create New Event");
        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        // Enhanced button styling matching Admin
        JButton[] buttons = {createButton, editButton, deleteButton, refreshButton};
        for (JButton btn : buttons) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225)); // Admin blue
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(160, 35));
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(btn.getBackground().darker(), 2),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
            ));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        // Special colors for different actions
        createButton.setBackground(new Color(40, 167, 69)); // Green
        deleteButton.setBackground(new Color(220, 53, 69)); // Red
        refreshButton.setBackground(new Color(108, 117, 125)); // Gray

        createButton.addActionListener(e -> switchToCreateEventTab());
        editButton.addActionListener(e -> editSelectedEvent());
        deleteButton.addActionListener(e -> deleteSelectedEvent());
        refreshButton.addActionListener(e -> loadOrganizerEvents());

        actionPanel.add(createButton);
        actionPanel.add(editButton);
        actionPanel.add(deleteButton);
        actionPanel.add(refreshButton);

        return actionPanel;
    }

    private void switchToCreateEventTab() {
        JTabbedPane tabbedPane = (JTabbedPane) ((JPanel) getContentPane().getComponent(0)).getComponent(1);
        tabbedPane.setSelectedIndex(1);
    }

    private JScrollPane createEventsTablePanel() {
        String[] columns = {"Event Code", "Title", "Start Date", "End Date", "Venue", "Tickets Sold", "Break-even", "Revenue", "Status", "Actions"};
        eventsTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 9;
            }
        };
        eventsTable = new JTable(eventsTableModel);

        eventsTable.setRowHeight(30); // Slightly increased for better appearance

        JTableHeader header = eventsTable.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14)); // Matching Admin font size
        header.setBackground(new Color(65, 105, 225)); // Admin blue
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        eventsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                                                          boolean isSelected, boolean hasFocus, 
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                Color backgroundColor = row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE;
                
                try {
                    // Get the actual data from the table model
                    Object endDateObj = table.getModel().getValueAt(row, 3); // End Date column
                    Object ticketsSoldObj = table.getModel().getValueAt(row, 5); // Tickets Sold column
                    Object breakEvenObj = table.getModel().getValueAt(row, 6); // Break-even column
                    
                    if (endDateObj != null && ticketsSoldObj != null && breakEvenObj != null) {
                        String endDateStr = endDateObj.toString();
                        int ticketsSold = Integer.parseInt(ticketsSoldObj.toString());
                        int breakEven = Integer.parseInt(breakEvenObj.toString());
                        
                        // Parse the date from the formatted string in the table
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                        Date endDate = dateFormat.parse(endDateStr);
                        Date currentDate = new Date();
                        
                        // If event has ended (finished)
                        if (endDate.before(currentDate)) {
                            if (ticketsSold >= breakEven) {
                                // ✅ FINISHED & PROFITABLE - Light Green
                                backgroundColor = new Color(220, 255, 220);
                            } else {
                                // ❌ FINISHED & LOSS - Light Red
                                backgroundColor = new Color(255, 220, 220);
                            }
                        } 
                        // If event is current (ongoing or upcoming)
                        else {
                            // 🔵 CURRENT EVENT - Light Blue
                            backgroundColor = new Color(220, 235, 255);
                            
                            // Show progress for current events
                            if (breakEven > 0) {
                                double progress = (ticketsSold * 100.0) / breakEven;
                                if (progress >= 100) {
                                    // 🟢 CURRENT & REACHED BREAK-EVEN - Light Mint Green
                                    backgroundColor = new Color(220, 255, 240);
                                } else if (progress >= 50) {
                                    // 🟡 CURRENT & GOOD PROGRESS - Light Yellow
                                    backgroundColor = new Color(255, 255, 220);
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    // If any parsing error, use default background
                    backgroundColor = row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE;
                }
                
                // Apply the background color
                c.setBackground(backgroundColor);
                
                // Handle selection - make it darker
                if (isSelected) {
                    c.setBackground(backgroundColor.darker());
                }
                
                return c;
            }
        });

        eventsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        eventsTable.getColumn("Actions").setCellEditor(
            new OrganizerEventButtonEditor(new JCheckBox(), con, this, eventsTable)
        );

        JScrollPane scrollPane = new JScrollPane(eventsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(65, 105, 225), 2),
            "Events Management",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(65, 105, 225)
        ));
        return scrollPane;
    }
    
    private JPanel createEventForm() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(40, 167, 69), 2),
            "Create New Event",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(40, 167, 69)
        ));

        // Form fields with better styling
        JTextField titleField = createStyledTextField(25);
        JTextArea descriptionArea = createStyledTextArea(3, 20);
        JTextField venueField = createStyledTextField(20);
        JTextField priceField = createStyledTextField(10);
        JTextField capacityField = createStyledTextField(10);
        JTextField breakEvenField = createStyledTextField(10);

        JComboBox<String> categoryDropdown = new JComboBox<>(new String[]{
            "Music", "Sports", "Conference", "Workshop", "Exhibition", "Party", "Wedding"
        });
        categoryDropdown.setFont(new Font("Arial", Font.PLAIN, 13));
        categoryDropdown.setBackground(Color.WHITE);

        JDateChooser startDateChooser = new JDateChooser();
        startDateChooser.setDateFormatString("yyyy-MM-dd");
        startDateChooser.setFont(new Font("Arial", Font.PLAIN, 13));
        
        JDateChooser endDateChooser = new JDateChooser();
        endDateChooser.setDateFormatString("yyyy-MM-dd");
        endDateChooser.setFont(new Font("Arial", Font.PLAIN, 13));

        JTextField startTimeField = createStyledTextField(6);
        JTextField endTimeField = createStyledTextField(6);

        int row = 0;
        
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Event Title:"), gbc);
        gbc.gridx = 1; formPanel.add(titleField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Description:"), gbc);
        gbc.gridx = 1; formPanel.add(new JScrollPane(descriptionArea), gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Venue:"), gbc);
        gbc.gridx = 1; formPanel.add(venueField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Price:"), gbc);
        gbc.gridx = 1; formPanel.add(priceField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Capacity:"), gbc);
        gbc.gridx = 1; formPanel.add(capacityField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Break-even Tickets:"), gbc);
        gbc.gridx = 1; formPanel.add(breakEvenField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Category:"), gbc);
        gbc.gridx = 1; formPanel.add(categoryDropdown, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Event Start Date:"), gbc);
        gbc.gridx = 1; formPanel.add(startDateChooser, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Start Time (HH:MM):"), gbc);
        gbc.gridx = 1; formPanel.add(startTimeField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("Event End Date:"), gbc);
        gbc.gridx = 1; formPanel.add(endDateChooser, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        formPanel.add(createFormLabel("End Time (HH:MM):"), gbc);
        gbc.gridx = 1; formPanel.add(endTimeField, gbc);

        // Enhanced Submit Button
        JButton submitButton = new JButton("Create Event");
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        submitButton.setBackground(new Color(40, 167, 69));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setPreferredSize(new Dimension(200, 40));
        submitButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 130, 50), 2),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            // Validation
            if (startDateChooser.getDate() == null || endDateChooser.getDate() == null || 
                startTimeField.getText().isEmpty() || endTimeField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select dates and enter times.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!startTimeField.getText().matches("([01]?[0-9]|2[0-3]):[0-5][0-9]") || 
                !endTimeField.getText().matches("([01]?[0-9]|2[0-3]):[0-5][0-9]")) {
                JOptionPane.showMessageDialog(this, "Please enter times in HH:MM format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (startDateChooser.getDate().after(endDateChooser.getDate())) {
                JOptionPane.showMessageDialog(this, "End date cannot be before start date.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String startDatePart = dateFormat.format(startDateChooser.getDate());
                String endDatePart = dateFormat.format(endDateChooser.getDate());
                
                String startDateTime = startDatePart + " " + startTimeField.getText() + ":00";
                String endDateTime = endDatePart + " " + endTimeField.getText() + ":00";

                int breakEvenTickets = breakEvenField.getText().isEmpty() ? 0 : Integer.parseInt(breakEvenField.getText());

                createEvent(
                    titleField.getText(),
                    descriptionArea.getText(),
                    venueField.getText(),
                    Double.parseDouble(priceField.getText()),
                    Integer.parseInt(capacityField.getText()),
                    breakEvenTickets,
                    (String) categoryDropdown.getSelectedItem(),
                    startDateTime,
                    endDateTime
                );

                // Clear form
                titleField.setText("");
                descriptionArea.setText("");
                venueField.setText("");
                priceField.setText("");
                capacityField.setText("");
                breakEvenField.setText("");
                categoryDropdown.setSelectedIndex(0);
                startDateChooser.setDate(null);
                endDateChooser.setDate(null);
                startTimeField.setText("");
                endTimeField.setText("");
                
                JOptionPane.showMessageDialog(this, "Event created successfully!", "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                    
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for price, capacity, and break-even tickets.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return formPanel;
    }

    // Helper methods for styled form components
    private JTextField createStyledTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setFont(new Font("Arial", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    private JTextArea createStyledTextArea(int rows, int columns) {
        JTextArea area = new JTextArea(rows, columns);
        area.setFont(new Font("Arial", Font.PLAIN, 13));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return area;
    }

    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        label.setForeground(new Color(60, 60, 60));
        return label;
    }

    // WORKING createEvent method - uses trigger for event_code generation
    private void createEvent(String title, String description, String venue,
            double price, int capacity, int breakEvenTickets, String category, 
            String startDateTime, String endDateTime) {
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {
            conn = DBConnection.getConnection();
            
            // Generate event_id
            String eventId = generateEventId(conn);
            
            String sql = "INSERT INTO Events (event_id, title, description, venue, price, capacity, " +
                    "available_tickets, break_even_tickets, category, organizer_id, " +
                    "start_date, end_date, event_date) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eventId);
            ps.setString(2, title);
            ps.setString(3, description);
            ps.setString(4, venue);
            ps.setDouble(5, price);
            ps.setInt(6, capacity);
            ps.setInt(7, capacity);
            ps.setInt(8, breakEvenTickets);
            ps.setString(9, category);
            ps.setString(10, organizerId);
            ps.setString(11, startDateTime);
            ps.setString(12, endDateTime);
            ps.setString(13, startDateTime);
            
            int rows = ps.executeUpdate();
            if (rows > 0) {
                loadOrganizerEvents(); // Refresh the events table
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating event: " + ex.getMessage(), "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private String generateEventId(Connection conn) throws SQLException {
        String eventId = null;
        PreparedStatement seqPs = null;
        ResultSet seqRs = null;
        
        try {
            // Get next value from sequence
            String seqSql = "SELECT next_value, prefix FROM id_sequences WHERE sequence_name = 'event_id'";
            seqPs = conn.prepareStatement(seqSql);
            seqRs = seqPs.executeQuery();
            
            if (seqRs.next()) {
                int nextVal = seqRs.getInt("next_value");
                String prefix = seqRs.getString("prefix");
                eventId = prefix + String.format("%06d", nextVal);
                
                // Update sequence
                String updateSeq = "UPDATE id_sequences SET next_value = next_value + 1 WHERE sequence_name = 'event_id'";
                PreparedStatement updatePs = conn.prepareStatement(updateSeq);
                updatePs.executeUpdate();
                updatePs.close();
            } else {
                // Fallback: generate random ID
                eventId = "EVT" + System.currentTimeMillis() % 1000000;
            }
        } finally {
            if (seqRs != null) seqRs.close();
            if (seqPs != null) seqPs.close();
        }
        
        return eventId;
    }

    private void loadOrganizerEvents() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT event_code, title, start_date, end_date, venue, " +
                        "tickets_sold, break_even_tickets, revenue, status " +
                        "FROM Events WHERE organizer_id = ? ORDER BY start_date DESC";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();
            updateEventsTable(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading events: " + ex.getMessage(), "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void updateEventsTable(ResultSet rs) throws SQLException {
        eventsTableModel.setRowCount(0);
        while (rs.next()) {
            // Convert USD to INR (assuming 1 USD = 83 INR)
            double revenueInUSD = rs.getDouble("revenue");
            double revenueInINR = revenueInUSD; // Conversion rate
            eventsTableModel.addRow(new Object[]{
                rs.getString("event_code"),
                rs.getString("title"),
                formatDateTime(rs.getString("start_date")),
                formatDateTime(rs.getString("end_date")),
                rs.getString("venue"),
                rs.getInt("tickets_sold"),
                rs.getInt("break_even_tickets"),
                currencyFormat.format(revenueInINR), // Using Indian Rupee format
                rs.getString("status"),
                "Edit/Delete"
            });
        }
    }

    private String formatDateTime(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm");
            Date date = inputFormat.parse(dateTime);
            return outputFormat.format(date);
        } catch (Exception e) {
            return dateTime;
        }
    }
   
    private void editSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to edit.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        showEventEditDialog(eventCode);
    }

    private void deleteSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to delete.");
            return;
        }
        
        String eventCode = (String) eventsTableModel.getValueAt(selectedRow, 0);
        String eventTitle = (String) eventsTableModel.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete the event '" + eventTitle + "'?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            Connection conn = null;
            PreparedStatement checkPs = null;
            PreparedStatement deletePs = null;
            ResultSet rs = null;
            
            try {
                conn = DBConnection.getConnection();
                
                // Check if there are any bookings for this event
                String checkSql = "SELECT COUNT(*) FROM bookings WHERE event_code = ?";
                checkPs = conn.prepareStatement(checkSql);
                checkPs.setString(1, eventCode);
                rs = checkPs.executeQuery();
                
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Cannot delete event with existing bookings. Please cancel the event instead.");
                    return;
                }
                
                String deleteSql = "DELETE FROM Events WHERE event_code = ? AND organizer_id = ?";
                deletePs = conn.prepareStatement(deleteSql);
                deletePs.setString(1, eventCode);
                deletePs.setString(2, organizerId);
                
                int rows = deletePs.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Event deleted successfully!");
                    loadOrganizerEvents();
                } else {
                    JOptionPane.showMessageDialog(this, "Event not found or you don't have permission to delete it.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting event: " + ex.getMessage());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (checkPs != null) checkPs.close();
                    if (deletePs != null) deletePs.close();
                    if (conn != null) DBConnection.closeConnection(conn);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    void showEventEditDialog(String eventCode) {
        JDialog editDialog = new JDialog(this, "Edit Event", true);
        editDialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        
        editDialog.getContentPane().setBackground(new Color(240, 248, 255));
        
        JTextField titleField = createStyledTextField(25);
        JTextArea descriptionArea = createStyledTextArea(3, 20);
        JTextField venueField = createStyledTextField(20);
        JTextField priceField = createStyledTextField(10);
        JTextField capacityField = createStyledTextField(10);
        JTextField breakEvenField = createStyledTextField(10);
        
        JComboBox<String> categoryDropdown = new JComboBox<>(new String[]{
            "Music", "Sports", "Conference", "Workshop", "Exhibition", "Party", "Wedding"
        });
        categoryDropdown.setFont(new Font("Arial", Font.PLAIN, 13));
        
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Pending", "Approved", "Rejected", "Cancelled"});
        statusCombo.setFont(new Font("Arial", Font.PLAIN, 13));
        
        JDateChooser startDateChooser = new JDateChooser();
        startDateChooser.setDateFormatString("yyyy-MM-dd");
        startDateChooser.setFont(new Font("Arial", Font.PLAIN, 13));
        
        JDateChooser endDateChooser = new JDateChooser();
        endDateChooser.setDateFormatString("yyyy-MM-dd");
        endDateChooser.setFont(new Font("Arial", Font.PLAIN, 13));
        
        JTextField startTimeField = createStyledTextField(6);
        JTextField endTimeField = createStyledTextField(6);
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Events WHERE event_code = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eventCode);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                titleField.setText(rs.getString("title"));
                descriptionArea.setText(rs.getString("description"));
                venueField.setText(rs.getString("venue"));
                priceField.setText(String.valueOf(rs.getDouble("price")));
                capacityField.setText(String.valueOf(rs.getInt("capacity")));
                breakEvenField.setText(String.valueOf(rs.getInt("break_even_tickets")));
                categoryDropdown.setSelectedItem(rs.getString("category"));
                statusCombo.setSelectedItem(rs.getString("status"));
                
                // Parse and set start/end dates
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date startDate = dateFormat.parse(rs.getString("start_date"));
                Date endDate = dateFormat.parse(rs.getString("end_date"));
                
                startDateChooser.setDate(startDate);
                endDateChooser.setDate(endDate);
                
                // Extract times
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
                startTimeField.setText(timeFormat.format(startDate));
                endTimeField.setText(timeFormat.format(endDate));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        int row = 0;
        
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Event Code:"), gbc);
        gbc.gridx = 1; 
        JLabel eventCodeLabel = new JLabel(eventCode);
        eventCodeLabel.setFont(new Font("Arial", Font.BOLD, 13));
        editDialog.add(eventCodeLabel, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Title:"), gbc);
        gbc.gridx = 1; editDialog.add(titleField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Description:"), gbc);
        gbc.gridx = 1; editDialog.add(new JScrollPane(descriptionArea), gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Venue:"), gbc);
        gbc.gridx = 1; editDialog.add(venueField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Price:"), gbc);
        gbc.gridx = 1; editDialog.add(priceField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Capacity:"), gbc);
        gbc.gridx = 1; editDialog.add(capacityField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Break-even Tickets:"), gbc);
        gbc.gridx = 1; editDialog.add(breakEvenField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Category:"), gbc);
        gbc.gridx = 1; editDialog.add(categoryDropdown, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Start Date:"), gbc);
        gbc.gridx = 1; editDialog.add(startDateChooser, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Start Time (HH:MM):"), gbc);
        gbc.gridx = 1; editDialog.add(startTimeField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("End Date:"), gbc);
        gbc.gridx = 1; editDialog.add(endDateChooser, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("End Time (HH:MM):"), gbc);
        gbc.gridx = 1; editDialog.add(endTimeField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("Status:"), gbc);
        gbc.gridx = 1; editDialog.add(statusCombo, gbc);
        
        // Enhanced Save Button
        JButton saveButton = new JButton("💾 Save Changes");
        saveButton.setFont(new Font("Arial", Font.BOLD, 13));
        saveButton.setBackground(new Color(40, 167, 69));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new Dimension(150, 35));
        saveButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 130, 50), 2),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setOpaque(false);
        
        JButton cancelButton = new JButton("❌ Cancel");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 13));
        cancelButton.setBackground(new Color(108, 117, 125));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.addActionListener(e -> editDialog.dispose());
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        editDialog.add(buttonPanel, gbc);
        
        saveButton.addActionListener(e -> {
            Connection updateConn = null;
            PreparedStatement updatePs = null;
            
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String startDatePart = dateFormat.format(startDateChooser.getDate());
                String endDatePart = dateFormat.format(endDateChooser.getDate());
                
                String startDateTime = startDatePart + " " + startTimeField.getText() + ":00";
                String endDateTime = endDatePart + " " + endTimeField.getText() + ":00";

                updateConn = DBConnection.getConnection();
                String updateSql = "UPDATE Events SET title=?, description=?, venue=?, price=?, capacity=?, " +
                                 "break_even_tickets=?, category=?, status=?, start_date=?, end_date=? " +
                                 "WHERE event_code=?";
                updatePs = updateConn.prepareStatement(updateSql);
                updatePs.setString(1, titleField.getText());
                updatePs.setString(2, descriptionArea.getText());
                updatePs.setString(3, venueField.getText());
                updatePs.setDouble(4, Double.parseDouble(priceField.getText()));
                updatePs.setInt(5, Integer.parseInt(capacityField.getText()));
                updatePs.setInt(6, Integer.parseInt(breakEvenField.getText()));
                updatePs.setString(7, (String) categoryDropdown.getSelectedItem());
                updatePs.setString(8, (String) statusCombo.getSelectedItem());
                updatePs.setString(9, startDateTime);
                updatePs.setString(10, endDateTime);
                updatePs.setString(11, eventCode);
                
                if (updatePs.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Event updated successfully!", "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    editDialog.dispose();
                    loadOrganizerEvents();
                }
            } catch (SQLException | NumberFormatException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating event: " + ex.getMessage(), "Error", 
                    JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    if (updatePs != null) updatePs.close();
                    if (updateConn != null) DBConnection.closeConnection(updateConn);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        editDialog.setSize(550, 650);
        editDialog.setLocationRelativeTo(this);
        editDialog.setVisible(true);
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180), 2),
            "Performance Summary",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(70, 130, 180)
        ));

        JPanel statsPanel = new JPanel(new GridLayout(2, 4, 8, 8));
        statsPanel.setBackground(new Color(240, 245, 255));
        
        Connection conn = null;
        
        try {
            conn = DBConnection.getConnection();
            
            // Events
            String totalEventsQuery = "SELECT COUNT(*) FROM Events WHERE organizer_id = ?";
            PreparedStatement totalEventsStmt = conn.prepareStatement(totalEventsQuery);
            totalEventsStmt.setString(1, organizerId);
            ResultSet totalEventsRs = totalEventsStmt.executeQuery();
            
            // Current Events (ongoing and upcoming)
            String currentEventsQuery = "SELECT COUNT(*) FROM Events WHERE organizer_id = ? AND end_date >= NOW()";
            PreparedStatement currentEventsStmt = conn.prepareStatement(currentEventsQuery);
            currentEventsStmt.setString(1, organizerId);
            ResultSet currentEventsRs = currentEventsStmt.executeQuery();
            
            // Tickets Sold
            String totalTicketsQuery = "SELECT SUM(tickets_sold) FROM Events WHERE organizer_id = ?";
            PreparedStatement totalTicketsStmt = conn.prepareStatement(totalTicketsQuery);
            totalTicketsStmt.setString(1, organizerId);
            ResultSet totalTicketsRs = totalTicketsStmt.executeQuery();
            
            // Revenue
            String totalRevenueQuery = "SELECT SUM(revenue) FROM Events WHERE organizer_id = ?";
            PreparedStatement totalRevenueStmt = conn.prepareStatement(totalRevenueQuery);
            totalRevenueStmt.setString(1, organizerId);
            ResultSet totalRevenueRs = totalRevenueStmt.executeQuery();
            
            // Avg. Attendance
            String avgAttendanceQuery = "SELECT AVG(tickets_sold) FROM Events WHERE organizer_id = ?";
            PreparedStatement avgAttendanceStmt = conn.prepareStatement(avgAttendanceQuery);
            avgAttendanceStmt.setString(1, organizerId);
            ResultSet avgAttendanceRs = avgAttendanceStmt.executeQuery();
            
            // Pending Tickets
            String pendingTicketsQuery = "SELECT SUM(available_tickets) FROM Events WHERE organizer_id = ? AND end_date >= NOW()";
            PreparedStatement pendingTicketsStmt = conn.prepareStatement(pendingTicketsQuery);
            pendingTicketsStmt.setString(1, organizerId);
            ResultSet pendingTicketsRs = pendingTicketsStmt.executeQuery();
            
            // Profit
            String totalProfitQuery = 
                "SELECT SUM(" +
                "   CASE " +
                "       WHEN end_date < NOW() THEN " + // Completed events
                "           revenue - GREATEST(0, (break_even_tickets - tickets_sold) * price) " +
                "       WHEN end_date >= NOW() THEN " + // Ongoing/upcoming events
                "           revenue - GREATEST(0, (break_even_tickets - (tickets_sold + available_tickets)) * price) " +
                "       ELSE revenue " +
                "   END" +
                ") FROM Events WHERE organizer_id = ?";
            PreparedStatement totalProfitStmt = conn.prepareStatement(totalProfitQuery);
            totalProfitStmt.setString(1, organizerId);
            ResultSet totalProfitRs = totalProfitStmt.executeQuery();
            
            // Loss
            String totalLossQuery = 
                "SELECT SUM(" +
                "   CASE " +
                "       WHEN end_date < NOW() THEN " + // Completed events - actual loss
                "           GREATEST(0, (break_even_tickets - tickets_sold) * price) " +
                "       WHEN end_date >= NOW() THEN " + // Ongoing/upcoming events - potential loss
                "           GREATEST(0, (break_even_tickets - (tickets_sold + available_tickets)) * price) " +
                "       ELSE 0 " +
                "   END" +
                ") FROM Events WHERE organizer_id = ? AND (tickets_sold < break_even_tickets OR (tickets_sold + available_tickets) < break_even_tickets)";
            PreparedStatement totalLossStmt = conn.prepareStatement(totalLossQuery);
            totalLossStmt.setString(1, organizerId);
            ResultSet totalLossRs = totalLossStmt.executeQuery();
            
            String[] labels = {"Events", "Current", "Tickets", "Revenue", "Attendance", "Pending", "Profit", "Loss"};
            ResultSet[] resultSets = {totalEventsRs, currentEventsRs, totalTicketsRs, totalRevenueRs, avgAttendanceRs, pendingTicketsRs, totalProfitRs, totalLossRs};
            
            Color[] backgroundColors = {
                new Color(220, 240, 255), new Color(220, 255, 240), new Color(255, 245, 220), 
                new Color(220, 255, 220), new Color(255, 240, 245), new Color(255, 255, 220), 
                new Color(230, 255, 230), new Color(255, 230, 230)
            };
            
            for (int i = 0; i < labels.length; i++) {
                JPanel statPanel = new JPanel(new BorderLayout());
                statPanel.setBackground(backgroundColors[i]);
                statPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(backgroundColors[i].darker(), 1, true),
                    BorderFactory.createEmptyBorder(10, 10, 10, 10)
                ));
                
                statPanel.setOpaque(true);
                
                JLabel title = new JLabel(labels[i], JLabel.CENTER);
                title.setFont(new Font("Arial", Font.BOLD, 12));
                title.setForeground(new Color(60, 60, 60));
                
                String value = "0";
                if (resultSets[i].next()) {
                    value = resultSets[i].getString(1);
                    if (value == null) value = "0";
                    if (labels[i].equals("Revenue") || labels[i].equals("Profit") || labels[i].equals("Loss")) {
                        double amountInUSD = Double.parseDouble(value);
                        double amountInINR = amountInUSD * USD_TO_INR_RATE; // Convert to INR
                        value = currencyFormat.format(amountInINR);
                    }
                    if (labels[i].equals("Attendance")) {
                        value = String.format("%.1f", Double.parseDouble(value));
                    }
                }
                
                JLabel valueLabel = new JLabel(value, JLabel.CENTER);
                valueLabel.setFont(new Font("Arial", Font.BOLD, 16));
                
                // Color coding based on metric type
                if (labels[i].equals("Revenue")) {
                    valueLabel.setForeground(new Color(0, 100, 0));
                } else if (labels[i].equals("Profit")) {
                    double profitValue = Double.parseDouble(value.replace("₹", "").replace(",", ""));
                    if (profitValue > 0) {
                        valueLabel.setForeground(new Color(0, 150, 0));
                    } else if (profitValue < 0) {
                        valueLabel.setForeground(Color.RED);
                    } else {
                        valueLabel.setForeground(new Color(0, 0, 139));
                    }
                } else if (labels[i].equals("Loss") && !value.equals("₹0.00")) {
                    valueLabel.setForeground(Color.RED);
                } else if (labels[i].equals("Pending")) {
                    valueLabel.setForeground(new Color(200, 120, 0));
                } else if (labels[i].equals("Current")) {
                    valueLabel.setForeground(new Color(0, 100, 200));
                } else {
                    valueLabel.setForeground(new Color(0, 0, 139));
                }
                
                statPanel.add(title, BorderLayout.NORTH);
                statPanel.add(valueLabel, BorderLayout.CENTER);
                statsPanel.add(statPanel);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                DBConnection.closeConnection(conn);
            }
        }
        
        panel.add(statsPanel, BorderLayout.CENTER);
        return panel;
    }
    

    private JPanel createRevenueChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60, 179, 113), 2),
            "Revenue Analytics",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(60, 179, 113)
        ));
        
        DefaultTableModel model = new DefaultTableModel(new String[]{"Event", "Revenue"}, 0);
        JTable table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        header.setBackground(new Color(60, 179, 113));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                    
                    // Color revenue values
                    if (column == 1 && value != null) {
                        String revenueStr = value.toString();
                        if (revenueStr.startsWith("₹")) {
                            try {
                                double revenue = Double.parseDouble(revenueStr.substring(1).replace(",", ""));
                                if (revenue > 0) {
                                    c.setForeground(new Color(0, 100, 0));
                                } else if (revenue < 0) {
                                    c.setForeground(Color.RED);
                                }
                            } catch (NumberFormatException e) {
                                // Ignore formatting errors
                            }
                        }
                    }
                }
                return c;
            }
        });

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT title, revenue FROM Events WHERE organizer_id = ? ORDER BY revenue DESC LIMIT 10";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();

            while (rs.next()) {
                double revenueInUSD = rs.getDouble("revenue");
                double revenueInINR = revenueInUSD * USD_TO_INR_RATE; // Convert to INR
                model.addRow(new Object[]{
                    rs.getString("title"),
                    currencyFormat.format(revenueInINR)
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createAttendanceChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(255, 193, 7), 2),
            "Attendance Analytics",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(255, 193, 7)
        ));

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Event", "Tickets Sold", "Capacity"}, 0
        );
        JTable table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        header.setBackground(new Color(255, 193, 7));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(255, 250, 240) : Color.WHITE);
                    
                    // Color coding for attendance
                    if (column == 1 || column == 2) {
                        try {
                            int sold = Integer.parseInt(table.getValueAt(row, 1).toString());
                            int capacity = Integer.parseInt(table.getValueAt(row, 2).toString());
                            
                            if (column == 1) { // Tickets Sold column
                                double percentage = capacity > 0 ? (sold * 100.0 / capacity) : 0;
                                if (percentage >= 80) {
                                    c.setForeground(new Color(0, 100, 0));
                                } else if (percentage >= 50) {
                                    c.setForeground(new Color(200, 120, 0));
                                } else {
                                    c.setForeground(Color.RED);
                                }
                            }
                        } catch (NumberFormatException e) {
                            // Ignore parsing errors
                        }
                    }
                }
                return c;
            }
        });

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT title, tickets_sold, capacity FROM Events WHERE organizer_id = ? ORDER BY tickets_sold DESC LIMIT 10";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    rs.getInt("tickets_sold"),
                    rs.getInt("capacity")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createTopEventsTable() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(102, 16, 242), 2),
            "Top Performing Events",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(102, 16, 242)
        ));

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Event", "Rating", "Bookings"}, 0
        );
        JTable table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        header.setBackground(new Color(102, 16, 242));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 240, 255) : Color.WHITE);
                }
                return c;
            }
        });

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT title, tickets_sold FROM Events WHERE organizer_id = ? ORDER BY tickets_sold DESC LIMIT 5";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    "N/A",
                    rs.getInt("tickets_sold")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createProfilePanel() {
        JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
        profilePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(65, 105, 225), 2),
            "Organizer Profile",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 14),
            new Color(65, 105, 225)
        ));

        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 15, 8, 15);
        gbc.anchor = GridBagConstraints.WEST;

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Organizers WHERE organizer_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();

            if (rs.next()) {
                 int[] rowCount = {0};

                java.util.function.BiConsumer<String, String> addRow = (label, value) -> {
                    gbc.gridx = 0;
                    gbc.gridy = rowCount[0];
                    JLabel fieldLabel = new JLabel(label + ":");
                    fieldLabel.setFont(new Font("Arial", Font.BOLD, 13));
                    fieldLabel.setForeground(new Color(60, 60, 60));
                    infoPanel.add(fieldLabel, gbc);

                    gbc.gridx = 1;
                    JLabel valueLabel = new JLabel(value);
                    valueLabel.setFont(new Font("Arial", Font.PLAIN, 13));
                    valueLabel.setForeground(new Color(30, 30, 30));
                    infoPanel.add(valueLabel, gbc);

                    rowCount[0]++;
                };

                addRow.accept("First Name", rs.getString("firstname"));
                addRow.accept("Last Name", rs.getString("lastname"));
                addRow.accept("Mobile", rs.getString("mobile"));
                addRow.accept("Email", rs.getString("email"));
                addRow.accept("Company", rs.getString("company_name"));
                addRow.accept("Address", rs.getString("address"));
                addRow.accept("Verified", rs.getBoolean("verified") ? "✅ Yes" : "❌ No");
                addRow.accept("Member Since", rs.getString("created_at"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        // Enhanced Edit Profile Button
        JButton editProfileButton = new JButton("✏️ Edit Profile");
        editProfileButton.setFont(new Font("Arial", Font.BOLD, 13));
        editProfileButton.setBackground(new Color(65, 105, 225));
        editProfileButton.setForeground(Color.WHITE);
        editProfileButton.setFocusPainted(false);
        editProfileButton.setPreferredSize(new Dimension(150, 35));
        editProfileButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 80, 180), 2),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        editProfileButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.add(editProfileButton);

        editProfileButton.addActionListener(e -> showEditProfileDialog());

        profilePanel.add(infoPanel, BorderLayout.CENTER);
        profilePanel.add(buttonPanel, BorderLayout.SOUTH);

        return profilePanel;
    }

    private void showEditProfileDialog() {
        JDialog editDialog = new JDialog(this, "Edit Organizer Profile", true);
        editDialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        editDialog.getContentPane().setBackground(new Color(240, 248, 255));

        // Form fields with better styling
        JTextField firstNameField = createStyledTextField(20);
        JTextField lastNameField = createStyledTextField(20);
        JTextField mobileField = createStyledTextField(15);
        JTextField emailField = createStyledTextField(25);
        JTextField companyField = createStyledTextField(20);
        JTextArea addressArea = createStyledTextArea(3, 20);

        // Load current data
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Organizers WHERE organizer_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, organizerId);
            rs = ps.executeQuery();

            if (rs.next()) {
                firstNameField.setText(rs.getString("firstname"));
                lastNameField.setText(rs.getString("lastname"));
                mobileField.setText(rs.getString("mobile"));
                emailField.setText(rs.getString("email"));
                companyField.setText(rs.getString("company_name"));
                addressArea.setText(rs.getString("address"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading profile data: " + ex.getMessage(), "Error", 
                JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        int row = 0;
        
        // First Name
        gbc.gridx = 0; gbc.gridy = row; 
        editDialog.add(createFormLabel("First Name:"), gbc);
        gbc.gridx = 1; 
        editDialog.add(firstNameField, gbc);
        
        row++;
        // Last Name
        gbc.gridx = 0; gbc.gridy = row;
        editDialog.add(createFormLabel("Last Name:"), gbc);
        gbc.gridx = 1;
        editDialog.add(lastNameField, gbc);
        
        row++;
        // Mobile
        gbc.gridx = 0; gbc.gridy = row;
        editDialog.add(createFormLabel("Mobile:"), gbc);
        gbc.gridx = 1;
        editDialog.add(mobileField, gbc);
        
        row++;
        // Email
        gbc.gridx = 0; gbc.gridy = row;
        editDialog.add(createFormLabel("Email:"), gbc);
        gbc.gridx = 1;
        editDialog.add(emailField, gbc);
        
        row++;
        // Company Name
        gbc.gridx = 0; gbc.gridy = row;
        editDialog.add(createFormLabel("Company:"), gbc);
        gbc.gridx = 1;
        editDialog.add(companyField, gbc);
        
        row++;
        // Address
        gbc.gridx = 0; gbc.gridy = row;
        editDialog.add(createFormLabel("Address:"), gbc);
        gbc.gridx = 1;
        editDialog.add(new JScrollPane(addressArea), gbc);
        
        row++;
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setOpaque(false);
        
        JButton saveButton = new JButton("💾 Save Changes");
        saveButton.setFont(new Font("Arial", Font.BOLD, 13));
        saveButton.setBackground(new Color(40, 167, 69));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new Dimension(150, 35));
        saveButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 130, 50), 2),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        
        JButton cancelButton = new JButton("❌ Cancel");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 13));
        cancelButton.setBackground(new Color(108, 117, 125));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(80, 90, 100), 2),
            BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        editDialog.add(buttonPanel, gbc);

        // Save button action
        saveButton.addActionListener(e -> {
            // Validation
            if (firstNameField.getText().trim().isEmpty() || 
                lastNameField.getText().trim().isEmpty() ||
                mobileField.getText().trim().isEmpty() ||
                emailField.getText().trim().isEmpty()) {
                
                JOptionPane.showMessageDialog(editDialog, 
                    "Please fill in all required fields: First Name, Last Name, Mobile, and Email.", 
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Email validation
            if (!isValidEmail(emailField.getText().trim())) {
                JOptionPane.showMessageDialog(editDialog, 
                    "Please enter a valid email address.", 
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Mobile validation (basic)
            if (!isValidMobile(mobileField.getText().trim())) {
                JOptionPane.showMessageDialog(editDialog, 
                    "Please enter a valid mobile number (10-15 digits).", 
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Connection updateConn = null;
            PreparedStatement updatePs = null;
            
            try {
                updateConn = DBConnection.getConnection();
                String updateSql = "UPDATE Organizers SET firstname=?, lastname=?, mobile=?, " +
                                 "email=?, company_name=?, address=? WHERE organizer_id=?";
                updatePs = updateConn.prepareStatement(updateSql);
                updatePs.setString(1, firstNameField.getText().trim());
                updatePs.setString(2, lastNameField.getText().trim());
                updatePs.setString(3, mobileField.getText().trim());
                updatePs.setString(4, emailField.getText().trim());
                updatePs.setString(5, companyField.getText().trim());
                updatePs.setString(6, addressArea.getText().trim());
                updatePs.setString(7, organizerId);
                
                int rowsUpdated = updatePs.executeUpdate();
                
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(editDialog, 
                        "Profile updated successfully!", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    editDialog.dispose();
                    
                    // Refresh the profile panel to show updated data
                    refreshProfilePanel();
                } else {
                    JOptionPane.showMessageDialog(editDialog, 
                        "Failed to update profile. Please try again.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                if (ex.getMessage().contains("Duplicate entry")) {
                    if (ex.getMessage().contains("mobile")) {
                        JOptionPane.showMessageDialog(editDialog, 
                            "Mobile number already exists. Please use a different mobile number.", 
                            "Duplicate Mobile", JOptionPane.ERROR_MESSAGE);
                    } else if (ex.getMessage().contains("email")) {
                        JOptionPane.showMessageDialog(editDialog, 
                            "Email address already exists. Please use a different email.", 
                            "Duplicate Email", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(editDialog, 
                        "Error updating profile: " + ex.getMessage(), 
                        "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } finally {
                try {
                    if (updatePs != null) updatePs.close();
                    if (updateConn != null) DBConnection.closeConnection(updateConn);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Cancel button action
        cancelButton.addActionListener(e -> editDialog.dispose());

        editDialog.setSize(500, 450);
        editDialog.setLocationRelativeTo(this);
        editDialog.setVisible(true);
    }

    // Helper method to validate email format
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    // Helper method to validate mobile format
    private boolean isValidMobile(String mobile) {
        // Basic mobile validation - 10 to 15 digits
        return mobile.matches("\\d{10,15}");
    }

    // Method to refresh profile panel after update
    private void refreshProfilePanel() {
        // Get the main tabbed pane
        JTabbedPane tabbedPane = (JTabbedPane) ((JPanel) getContentPane().getComponent(0)).getComponent(1);
        
        // Remove and re-add the profile tab to refresh it
        int profileIndex = 3; // Profile is the 4th tab (index 3)
        tabbedPane.remove(profileIndex);
        
        JPanel newProfilePanel = new JPanel(new BorderLayout(10, 10));
        newProfilePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        newProfilePanel.add(createProfilePanel(), BorderLayout.CENTER);
        tabbedPane.add("👤 Profile", newProfilePanel);
        
        // Switch to profile tab to show updated data
        tabbedPane.setSelectedIndex(profileIndex);
    }

    @Override
    public void dispose() {
        DBConnection.closeConnection(con);
        super.dispose();
    }
}

// Complete OrganizerChat Class matching AdminChat style

class OrganizerEventButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Organizer organizer;
    private JTable table;

    public OrganizerEventButtonEditor(JCheckBox checkBox, Connection con, Organizer organizer, JTable table) {
        super(checkBox);
        this.con = con;
        this.organizer = organizer;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        button.setBackground(new Color(40, 167, 69));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            String eventCode = (String) table.getModel().getValueAt(row, 0);
            String action = (String) table.getModel().getValueAt(row, 9);
            
            if ("Edit/Delete".equals(action)) {
                organizer.showEventEditDialog(eventCode);
            }
        }
        isPushed = false;
        return label;
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

class ButtonRenderer extends JButton implements TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        setText((value == null) ? "Edit" : value.toString());
        setBackground(new Color(65, 105, 225));
        setForeground(Color.WHITE);
        setFont(new Font("Arial", Font.BOLD, 12));
        setFocusPainted(false);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 80, 180)),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        return this;
    }
}