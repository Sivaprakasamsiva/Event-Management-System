package com.Mavan.EventManagementSystem.IDGenerator;

import com.Mavan.EventManagementSystem.DBConnection.DBConnection;
import java.sql.*;

public class IDGenerator {
    
    public static String generateEventCode() {
        return generateID("events", "EVT");
    }
    
    public static String generateBookingID() {
        return generateID("bookings", "BOOK");
    }
    
    public static String generateCustomerID() {
        return generateID("members", "CUST");
    }
    
    
    private static String generateID(String sequenceName, String prefix) {
        Connection conn = null;
        PreparedStatement selectPs = null;
        PreparedStatement updatePs = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            
            // Get current value and lock the row
            String selectSql = "SELECT next_value FROM id_sequences WHERE sequence_name = ? FOR UPDATE";
            selectPs = conn.prepareStatement(selectSql);
            selectPs.setString(1, sequenceName);
            rs = selectPs.executeQuery();
            
            int nextValue;
            if (rs.next()) {
                nextValue = rs.getInt("next_value");
                
                // Update to next value
                String updateSql = "UPDATE id_sequences SET next_value = ? WHERE sequence_name = ?";
                updatePs = conn.prepareStatement(updateSql);
                updatePs.setInt(1, nextValue + 1);
                updatePs.setString(2, sequenceName);
                updatePs.executeUpdate();
            } else {
                // Create new sequence if doesn't exist
                nextValue = 1;
                String insertSql = "INSERT INTO id_sequences (sequence_name, prefix, next_value) VALUES (?, ?, ?)";
                updatePs = conn.prepareStatement(insertSql);
                updatePs.setString(1, sequenceName);
                updatePs.setString(2, prefix);
                updatePs.setInt(3, 2);
                updatePs.executeUpdate();
            }
            
            conn.commit();
            return prefix + String.format("%03d", nextValue);
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Fallback: generate ID based on timestamp
            return prefix + (System.currentTimeMillis() % 1000);
        } finally {
            try {
                if (rs != null) rs.close();
                if (selectPs != null) selectPs.close();
                if (updatePs != null) updatePs.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    DBConnection.closeConnection(conn);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    // Remove the generateBookingDisplayID method as it's no longer needed
}