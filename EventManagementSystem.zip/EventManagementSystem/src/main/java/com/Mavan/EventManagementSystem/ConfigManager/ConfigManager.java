package com.Mavan.EventManagementSystem.ConfigManager;

import java.io.*;
import java.util.*;

import javax.swing.SwingUtilities;

public class ConfigManager {
    public static void main(String[] args) {
        new ConfigManager();
    }
    private static final String CONFIG_FILE = "config.properties";
    private Properties props = new Properties();

    public ConfigManager() {
        load();
    }

    public void load() {
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
        } catch (IOException e) {
            System.out.println("Config file not found, using defaults.");
            setDefaultProperties();
        }
    }

    public void save() {
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Event Management Config");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String key) {
        return props.getProperty(key, "");
    }

    public void set(String key, String value) {
        props.setProperty(key, value);
    }
    
    // Method to get the complete database URL for connection
    public String getCompleteDbUrl() {
        String baseUrl = props.getProperty("DB_URL", "");
        String dbName = props.getProperty("DB_NAME", "");
        
        if (baseUrl.isEmpty()) {
            return "";
        }
        
        // If DB_NAME is empty, return the base URL as is
        if (dbName.isEmpty()) {
            return baseUrl;
        }
        
        // Check if baseUrl already contains a database name
        if (baseUrl.contains("/")) {
            int lastSlash = baseUrl.lastIndexOf("/");
            String afterSlash = baseUrl.substring(lastSlash + 1);
            // If what's after the last slash doesn't look like connection parameters, 
            // it's probably a database name
            if (!afterSlash.isEmpty() && !afterSlash.contains(":") && !afterSlash.contains("?")) {
                // Replace the existing database name with the new one
                return baseUrl.substring(0, lastSlash + 1) + dbName;
            } else {
                // No database name in URL, append it
                return baseUrl + "/" + dbName;
            }
        } else {
            // No slash in URL, just append the database name
            return baseUrl + "/" + dbName;
        }
    }
    
    // Method to get base URL without database name
    public String getBaseDbUrl() {
        String url = props.getProperty("DB_URL", "");
        if (url.contains("/")) {
            int lastSlash = url.lastIndexOf("/");
            String afterSlash = url.substring(lastSlash + 1);
            // If what's after the last slash looks like a database name, return the base
            if (!afterSlash.isEmpty() && !afterSlash.contains(":") && !afterSlash.contains("?")) {
                return url.substring(0, lastSlash);
            }
        }
        return url;
    }
    
    // Method to extract database name from URL
    public String getDbNameFromUrl() {
        String url = props.getProperty("DB_URL", "");
        if (url.contains("/")) {
            int lastSlash = url.lastIndexOf("/");
            String dbName = url.substring(lastSlash + 1);
            // Only return if it looks like a database name
            if (!dbName.isEmpty() && !dbName.contains(":") && !dbName.contains("?")) {
                return dbName;
            }
        }
        return "";
    }
    
    private void setDefaultProperties() {
        // Set default database properties
        props.setProperty("DB_URL", "jdbc:mysql://localhost:3306");
        props.setProperty("DB_USER", "root");
        props.setProperty("DB_PASS", "");
        props.setProperty("DB_NAME", "event_management");
        
        // Set default Twilio properties
        props.setProperty("ACCOUNT_SID", "");
        props.setProperty("AUTH_TOKEN", "");
        props.setProperty("TWILIO_NUMBER", "");
        
        // Set default Email properties
        props.setProperty("EMAIL_USER", "");
        props.setProperty("EMAIL_APP_PASSWORD", "");
        props.setProperty("EMAIL_HOST", "smtp.gmail.com");
        
        // Save defaults
        save();
    }
}