package com.Mavan.EventManagementSystem.ConfigEditor;

import javax.swing.*;

import com.Mavan.EventManagementSystem.ConfigManager.ConfigManager;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ConfigEditor extends JFrame {
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ConfigEditor::new);
    }
    
    private ConfigManager config;
    private JTextField dbUrlField, dbUserField, dbPassField;
    private JTextField sidField, tokenField, twilioField;
    private JTextField emailUserField, emailPassField, emailHostField;
    
    // Admin Details Fields
    private JTextField adminFirstNameField, adminLastNameField, adminMobileField, adminEmailField, adminPasswordField;
    
    // Database Creation Fields
    private JTextField databaseNameField;

    public ConfigEditor() {
        super("Configuration Settings");
        config = new ConfigManager();
        
        // Load MySQL driver - CRITICAL FIX
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this,
                "MySQL Driver not found: " + e.getMessage(),
                "Driver Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
        initializeUI();
        setupWindow();
        setVisible(true);
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 650);
        setLocationRelativeTo(null);
        
        // Main panel with styling
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("Configuration Settings", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form panel with tabs for better organization
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Database", createDatabasePanel());
        tabbedPane.addTab("Twilio", createTwilioPanel());
        tabbedPane.addTab("Email", createEmailPanel());
        tabbedPane.addTab("Admin Details", createAdminDetailsPanel());
        tabbedPane.addTab("Database Creation", createDatabaseCreationPanel());
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createDatabasePanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        // Show only the base URL without database name
        dbUrlField = createTextField(config.getBaseDbUrl());
        dbUserField = createTextField(config.get("DB_USER"));
        dbPassField = createTextField(config.get("DB_PASS"));

        addLabelAndField(panel, gbc, "Database Base URL:", dbUrlField, 0);
        addLabelAndField(panel, gbc, "Database User:", dbUserField, 1);
        addLabelAndField(panel, gbc, "Database Password:", dbPassField, 2);

        return panel;
    }
    

    private JPanel createTwilioPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        sidField = createTextField(config.get("ACCOUNT_SID"));
        tokenField = createTextField(config.get("AUTH_TOKEN"));
        twilioField = createTextField(config.get("TWILIO_NUMBER"));

        addLabelAndField(panel, gbc, "Twilio Account SID:", sidField, 0);
        addLabelAndField(panel, gbc, "Twilio Auth Token:", tokenField, 1);
        addLabelAndField(panel, gbc, "Twilio Phone Number:", twilioField, 2);

        return panel;
    }

    private JPanel createEmailPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        emailUserField = createTextField(config.get("EMAIL_USER"));
        emailPassField = createTextField(config.get("EMAIL_APP_PASSWORD"));
        emailHostField = createTextField(config.get("EMAIL_HOST"));

        addLabelAndField(panel, gbc, "Email Username:", emailUserField, 0);
        addLabelAndField(panel, gbc, "Email App Password:", emailPassField, 1);
        addLabelAndField(panel, gbc, "Email Host:", emailHostField, 2);

        return panel;
    }

    private JPanel createAdminDetailsPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        // Initialize admin fields
        adminFirstNameField = createTextField("Monkey D");
        adminLastNameField = createTextField("Luffy");
        adminMobileField = createTextField("1234567890");
        adminEmailField = createTextField("luffy@strawhat.com");
        adminPasswordField = createTextField("password");

        addLabelAndField(panel, gbc, "First Name:", adminFirstNameField, 0);
        addLabelAndField(panel, gbc, "Last Name:", adminLastNameField, 1);
        addLabelAndField(panel, gbc, "Mobile:", adminMobileField, 2);
        addLabelAndField(panel, gbc, "Email:", adminEmailField, 3);
        addLabelAndField(panel, gbc, "Password:", adminPasswordField, 4);

        // Admin table structure info
        JTextArea tableInfo = new JTextArea();
        tableInfo.setEditable(false);
        tableInfo.setFont(new Font("Monospaced", Font.PLAIN, 12));
        tableInfo.setBackground(new Color(250, 250, 250));
        tableInfo.setText(
            "admins Table Structure:\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "| Field      | Type         | Null | Key | Default           | Extra             |\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "| admin_id   | int          | NO   | PRI | NULL              | auto_increment    |\n" +
            "| firstname  | varchar(50)  | NO   |     | NULL              |                   |\n" +
            "| lastname   | varchar(50)  | NO   |     | NULL              |                   |\n" +
            "| mobile     | varchar(15)  | NO   | UNI | NULL              |                   |\n" +
            "| email      | varchar(100) | NO   | UNI | NULL              |                   |\n" +
            "| password   | varchar(255) | NO   |     | NULL              |                   |\n" +
            "| created_at | timestamp    | YES  |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED |\n" +
            "+------------+--------------+------+-----+-------------------+-------------------+\n" +
            "7 rows in set (0.00 sec)"
        );

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        panel.add(new JScrollPane(tableInfo), gbc);

        return panel;
    }

    private JPanel createDatabaseCreationPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new BorderLayout(10, 10));

        // Top panel for database name input
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(Color.WHITE);
        
        JLabel dbNameLabel = new JLabel("Database Name:");
        dbNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        databaseNameField = createTextField(config.get("DB_NAME"));
        databaseNameField.setPreferredSize(new Dimension(200, 35));
        
        // Add Create Database button
        JButton createDbBtn = createStyledButton("Create Database", new Color(70, 130, 180));
        createDbBtn.addActionListener(e -> {
            String dbName = databaseNameField.getText().trim();
            if (dbName.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a database name",
                    "Database Name Required",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            createDatabaseIfNotExists();
        });
        
        topPanel.add(dbNameLabel);
        topPanel.add(databaseNameField);
        topPanel.add(createDbBtn);
        
        panel.add(topPanel, BorderLayout.NORTH);

        // Center panel for schema display
        JTextArea schemaArea = new JTextArea();
        schemaArea.setEditable(false);
        schemaArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        schemaArea.setBackground(new Color(250, 250, 250));
        schemaArea.setBorder(BorderFactory.createTitledBorder("Database Schema Information"));
        
        JScrollPane scrollPane = new JScrollPane(schemaArea);
        scrollPane.setPreferredSize(new Dimension(650, 350));
        panel.add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton viewSchemaBtn = createStyledButton("View Schema", new Color(70, 130, 180));
        JButton createTablesBtn = createStyledButton("Create Tables", new Color(60, 179, 113));
        JButton insertDataBtn = createStyledButton("Insert Sample Data", new Color(218, 165, 32));

        viewSchemaBtn.addActionListener(e -> viewDatabaseSchema(schemaArea));
        createTablesBtn.addActionListener(e -> createTables());
        insertDataBtn.addActionListener(e -> insertSampleData());

        buttonPanel.add(viewSchemaBtn);
        buttonPanel.add(createTablesBtn);
        buttonPanel.add(insertDataBtn);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(245, 245, 245));

        JButton saveBtn = createStyledButton("Save", new Color(70, 130, 180));
        JButton cancelBtn = createStyledButton("Cancel", new Color(120, 120, 120));
        JButton testBtn = createStyledButton("Test Connections", new Color(60, 179, 113));

        saveBtn.addActionListener(e -> saveConfig());
        cancelBtn.addActionListener(e -> dispose());
        testBtn.addActionListener(e -> testConnections());

        buttonPanel.add(testBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        return buttonPanel;
    }

    private void addLabelAndField(JPanel panel, GridBagConstraints gbc, String labelText, JTextField field, int gridy) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 0;
        gbc.gridy = gridy;
        gbc.anchor = GridBagConstraints.LINE_END;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weighty = 0.0;
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(field, gbc);
    }

    private JPanel createStyledPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        return panel;
    }

    private GridBagConstraints createGBC() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        return gbc;
    }

    private JTextField createTextField(String text) {
        JTextField field = new JTextField(text, 20);
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(250, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(160, 35));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }

    private void setupWindow() {
        // Add window listener for confirmation on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (hasUnsavedChanges()) {
                    int result = JOptionPane.showConfirmDialog(
                        ConfigEditor.this,
                        "You have unsaved changes. Are you sure you want to close?",
                        "Unsaved Changes",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (result == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                dispose();
            }
        });
    }

    private boolean hasUnsavedChanges() {
        // Check if any field has been modified from original config values
        return !dbUrlField.getText().equals(config.get("DB_URL")) ||
               !dbUserField.getText().equals(config.get("DB_USER")) ||
               !dbPassField.getText().equals(config.get("DB_PASS")) ||
               !sidField.getText().equals(config.get("ACCOUNT_SID")) ||
               !tokenField.getText().equals(config.get("AUTH_TOKEN")) ||
               !twilioField.getText().equals(config.get("TWILIO_NUMBER")) ||
               !emailUserField.getText().equals(config.get("EMAIL_USER")) ||
               !emailPassField.getText().equals(config.get("EMAIL_APP_PASSWORD")) ||
               !emailHostField.getText().equals(config.get("EMAIL_HOST")) ||
               !databaseNameField.getText().equals(config.get("DB_NAME"));
    }

    private void saveConfig() {
        try {
            // Get the base URL (without database name)
            String currentUrl = dbUrlField.getText().trim();
            String dbName = databaseNameField.getText().trim();
            
            // If the current URL contains a database name, extract the base
            String baseUrl = currentUrl;
            if (currentUrl.contains("/")) {
                int lastSlash = currentUrl.lastIndexOf("/");
                String afterSlash = currentUrl.substring(lastSlash + 1);
                if (!afterSlash.isEmpty() && !afterSlash.contains(":") && !afterSlash.contains("?")) {
                    baseUrl = currentUrl.substring(0, lastSlash);
                }
            }
            
            config.set("DB_URL", baseUrl);
            config.set("DB_USER", dbUserField.getText().trim());
            config.set("DB_PASS", dbPassField.getText().trim());
            config.set("DB_NAME", dbName);

            config.set("ACCOUNT_SID", sidField.getText().trim());
            config.set("AUTH_TOKEN", tokenField.getText().trim());
            config.set("TWILIO_NUMBER", twilioField.getText().trim());

            config.set("EMAIL_USER", emailUserField.getText().trim());
            config.set("EMAIL_APP_PASSWORD", emailPassField.getText().trim());
            config.set("EMAIL_HOST", emailHostField.getText().trim());

            config.save();
            
            JOptionPane.showMessageDialog(this, 
                "Configuration saved successfully!\n" +
                "Base URL: " + baseUrl + "\n" +
                "Database: " + dbName + "\n" +
                "Complete URL: " + config.getCompleteDbUrl(),
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saving configuration: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    

    private void testConnections() {
        // Test database connection
        StringBuilder result = new StringBuilder();
        result.append("Connection Test Results:\n\n");
        
        // Test database connection
        if (testDatabaseConnection()) {
            result.append("✅ Database: Connection successful\n");
        } else {
            result.append("❌ Database: Connection failed\n");
        }
        
        // Test Twilio configuration
        if (sidField.getText().trim().isEmpty() || tokenField.getText().trim().isEmpty()) {
            result.append("❌ Twilio: Missing SID or Token\n");
        } else {
            result.append("✅ Twilio: Configuration looks valid\n");
        }
        
        // Test Email configuration
        if (emailUserField.getText().trim().isEmpty() || emailPassField.getText().trim().isEmpty()) {
            result.append("❌ Email: Missing username or password\n");
        } else {
            result.append("✅ Email: Configuration looks valid\n");
        }
        
        JOptionPane.showMessageDialog(this,
            result.toString(),
            "Connection Test Results",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private boolean testDatabaseConnection() {
        try {
            Connection conn = getConnectionWithoutDB();
            if (conn != null && !conn.isClosed()) {
                conn.close();
                return true;
            }
        } catch (Exception ex) {
            return false;
        }
        return false;
    }

    // Database Management Methods - FIXED CONNECTION METHODS
    private Connection getConnection() throws SQLException {
        String baseUrl = config.getBaseDbUrl();
        String dbName = databaseNameField.getText().trim();
        String completeUrl = baseUrl + "/" + dbName;
        String user = dbUserField.getText().trim();
        String password = dbPassField.getText().trim();
        
        System.out.println("Connecting to: " + completeUrl);
        return DriverManager.getConnection(completeUrl, user, password);
    }

    private Connection getConnectionWithoutDB() throws SQLException {
        String baseUrl = config.getBaseDbUrl();
        String user = dbUserField.getText().trim();
        String password = dbPassField.getText().trim();
        
        System.out.println("Connecting to base URL: " + baseUrl);
        return DriverManager.getConnection(baseUrl, user, password);
    }
    

    private void createDatabaseIfNotExists() {
        String dbName = databaseNameField.getText().trim();
        if (dbName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter a database name first",
                "Database Name Required",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try (Connection conn = getConnectionWithoutDB(); Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE DATABASE IF NOT EXISTS " + dbName);
            System.out.println("Database created or already exists: " + dbName);
            
            // Test the connection to the new database
            try (Connection testConn = getConnection()) {
                if (testConn != null) {
                    System.out.println("Successfully connected to database: " + dbName);
                    testConn.close();
                }
            } catch (SQLException e) {
                System.out.println("Warning: Could not connect to new database: " + e.getMessage());
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error creating database: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void viewDatabaseSchema(JTextArea schemaArea) {
        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection()) {
                DatabaseMetaData metaData = conn.getMetaData();
                String dbName = databaseNameField.getText().trim();
                
                // Get all tables from the specific database only
                ResultSet tables = metaData.getTables(dbName, null, "%", new String[]{"TABLE", "VIEW"});
                StringBuilder schemaInfo = new StringBuilder();
                schemaInfo.append("DATABASE: " + dbName + "\n");
                schemaInfo.append("TABLES AND VIEWS:\n");
                schemaInfo.append("+-----------------------+------------+\n");
                schemaInfo.append("| Name                  | Type       |\n");
                schemaInfo.append("+-----------------------+------------+\n");
                
                List<String> tableNames = new ArrayList<>();
                while (tables.next()) {
                    String tableName = tables.getString("TABLE_NAME");
                    String tableType = tables.getString("TABLE_TYPE");
                    tableNames.add(tableName);
                    schemaInfo.append(String.format("| %-21s | %-10s |\n", tableName, tableType));
                }
                schemaInfo.append("+-----------------------+------------+\n");
                schemaInfo.append(tableNames.size() + " rows in set\n\n");
                
                if (tableNames.isEmpty()) {
                    schemaInfo.append("No tables found in database '" + dbName + "'. Click 'Create Tables' to create the tables.\n");
                } else {
                    // Get schema for each table from the specific database
                    for (String tableName : tableNames) {
                        schemaInfo.append("Table: " + tableName + "\n");
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        schemaInfo.append("| Field                    | Type                                                  | Null | Key | Default           | Extra             |\n");
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        
                        ResultSet columns = metaData.getColumns(dbName, null, tableName, null);
                        while (columns.next()) {
                            String field = columns.getString("COLUMN_NAME");
                            String type = columns.getString("TYPE_NAME");
                            int size = columns.getInt("COLUMN_SIZE");
                            String typeWithSize = type + (size > 0 ? "(" + size + ")" : "");
                            String nullable = columns.getString("IS_NULLABLE").equals("YES") ? "YES" : "NO";
                            String key = "";
                            String defaultValue = columns.getString("COLUMN_DEF") != null ? columns.getString("COLUMN_DEF") : "NULL";
                            String extra = columns.getString("IS_AUTOINCREMENT") != null && columns.getString("IS_AUTOINCREMENT").equals("YES") ? "auto_increment" : "";
                            
                            // Get primary key information from the specific database
                            ResultSet primaryKeys = metaData.getPrimaryKeys(dbName, null, tableName);
                            while (primaryKeys.next()) {
                                if (primaryKeys.getString("COLUMN_NAME").equals(field)) {
                                    key = "PRI";
                                    break;
                                }
                            }
                            primaryKeys.close();
                            
                            schemaInfo.append(String.format("| %-24s | %-53s | %-4s | %-3s | %-17s | %-17s |\n", 
                                field, typeWithSize, nullable, key, defaultValue, extra));
                        }
                        columns.close();
                        schemaInfo.append("+--------------------------+-------------------------------------------------------+------+-----+-------------------+-------------------+\n");
                        schemaInfo.append("\n");
                    }
                }
                
                schemaArea.setText(schemaInfo.toString());
                
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error viewing database schema: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createTables() {
        String dbName = databaseNameField.getText().trim();
        if (dbName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter a database name first",
                "Database Name Required",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "This will create all database tables in database: " + dbName + ". Continue?",
            "Create Tables",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
                
                // Drop existing function first
                try {
                    stmt.execute("DROP FUNCTION IF EXISTS get_next_customer_id");
                } catch (SQLException e) {
                    System.out.println("Note: Function didn't exist or couldn't be dropped: " + e.getMessage());
                }

                // Create tables in correct order to avoid foreign key issues
                String[] createTableSQLs = {
                    // admins table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS admins (" +
                    "admin_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "mobile VARCHAR(15) NOT NULL UNIQUE, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // organizers table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS organizers (" +
                    "organizer_id VARCHAR(10) PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "mobile VARCHAR(15) NOT NULL UNIQUE, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "company_name VARCHAR(100), " +
                    "address TEXT, " +
                    "verified TINYINT(1) DEFAULT 0, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // members table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS members (" +
                    "member_id VARCHAR(10) PRIMARY KEY, " +
                    "firstname VARCHAR(50) NOT NULL, " +
                    "lastname VARCHAR(50) NOT NULL, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "dob DATE, " +
                    "gender ENUM('Male','Female','Other'), " +
                    "password VARCHAR(255) NOT NULL, " +
                    "address TEXT, " +
                    "mobile VARCHAR(15), " +
                    "email VARCHAR(100), " +
                    "active TINYINT(1) DEFAULT 1, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // events table - EXACT STRUCTURE FROM YOUR DATABASE
                    "CREATE TABLE IF NOT EXISTS events (" +
                    "event_id VARCHAR(10) PRIMARY KEY, " +
                    "title VARCHAR(100) NOT NULL, " +
                    "description TEXT, " +
                    "venue VARCHAR(100) NOT NULL, " +
                    "price DECIMAL(10,2) DEFAULT 0.00, " +
                    "capacity INT NOT NULL, " +
                    "available_tickets INT NOT NULL, " +
                    "category VARCHAR(50), " +
                    "organizer_id VARCHAR(10) NOT NULL, " +
                    "event_date DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                    "tickets_sold INT DEFAULT 0, " +
                    "revenue DECIMAL(10,2) DEFAULT 0.00, " +
                    "status ENUM('Pending','Approved','Rejected','Cancelled') DEFAULT 'Pending', " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "break_even_tickets INT DEFAULT 0, " +
                    "start_date DATETIME NOT NULL, " +
                    "end_date DATETIME NOT NULL, " +
                    "event_code VARCHAR(10) UNIQUE NOT NULL)",

                    // bookings table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS bookings (" +
                    "booking_id VARCHAR(10) PRIMARY KEY, " +
                    "event_id VARCHAR(10) NOT NULL, " +
                    "user_id VARCHAR(10), " +
                    "ticket_count INT NOT NULL, " +
                    "total_amount DECIMAL(10,2) NOT NULL, " +
                    "status ENUM('Confirmed','Pending','Cancelled','Refunded') DEFAULT 'Confirmed', " +
                    "booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "event_code VARCHAR(10))",

                    // payments table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS payments (" +
                    "payment_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "booking_id VARCHAR(10) NOT NULL, " +
                    "amount DECIMAL(10,2) NOT NULL, " +
                    "total_amount DECIMAL(10,2) NOT NULL, " +
                    "payment_method VARCHAR(50) NOT NULL, " +
                    "payment_status ENUM('Success','Failed','Pending') DEFAULT 'Pending', " +
                    "transaction_id VARCHAR(100), " +
                    "payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // chat_rooms table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS chat_rooms (" +
                    "room_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "room_type ENUM('ADMIN_ORGANIZER','ORGANIZER_CUSTOMER','ADMIN_CUSTOMER') NOT NULL, " +
                    "organizer_id VARCHAR(10), " +
                    "customer_id VARCHAR(10), " +
                    "admin_id INT DEFAULT 1, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // messages table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS messages (" +
                    "message_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "room_id INT NOT NULL, " +
                    "sender_type ENUM('ADMIN','ORGANIZER','CUSTOMER') NOT NULL, " +
                    "sender_id VARCHAR(50) NOT NULL, " +
                    "message_text TEXT NOT NULL, " +
                    "message_type ENUM('TEXT','IMAGE','FILE') DEFAULT 'TEXT', " +
                    "is_read TINYINT(1) DEFAULT 0, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // id_sequences table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS id_sequences (" +
                    "sequence_name VARCHAR(50) PRIMARY KEY, " +
                    "next_value INT DEFAULT 1, " +
                    "prefix VARCHAR(10) NOT NULL, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",

                    // systemsettings table - EXACT STRUCTURE
                    "CREATE TABLE IF NOT EXISTS systemsettings (" +
                    "id INT PRIMARY KEY DEFAULT 1, " +
                    "system_name VARCHAR(100) DEFAULT 'Event Management System', " +
                    "commission_rate DECIMAL(5,2) DEFAULT 0.00, " +
                    "auto_approve_events TINYINT(1) DEFAULT 0, " +
                    "max_events_per_organizer INT DEFAULT 10)"
                };

                // Execute table creation
                for (String sql : createTableSQLs) {
                    stmt.execute(sql);
                }

                // Create indexes - EXACT INDEXES FROM YOUR DATABASE
                String[] createIndexSQLs = {
                    // admins indexes
                    "CREATE INDEX idx_admins_email ON admins(email)",
                    "CREATE INDEX idx_admins_mobile ON admins(mobile)",
                    
                    // bookings indexes
                    "CREATE INDEX idx_bookings_event ON bookings(event_id)",
                    "CREATE INDEX idx_bookings_user ON bookings(user_id)",
                    "CREATE INDEX fk_bookings_event_code ON bookings(event_code)",
                    
                    // events indexes
                    "CREATE INDEX idx_category ON events(category)",
                    "CREATE INDEX idx_event_date ON events(event_date)",
                    "CREATE INDEX idx_organizer_id ON events(organizer_id)",
                    "CREATE INDEX idx_events_category ON events(category)",
                    "CREATE INDEX idx_events_date ON events(event_date)",
                    "CREATE INDEX idx_events_organizer ON events(organizer_id)",
                    
                    // messages indexes
                    "CREATE INDEX idx_created_at ON messages(created_at)",
                    "CREATE INDEX idx_room_read ON messages(room_id, is_read)",
                    
                    // organizers indexes
                    "CREATE INDEX idx_organizers_email ON organizers(email)",
                    "CREATE INDEX idx_organizers_mobile ON organizers(mobile)",
                    
                    // chat_rooms unique constraint
                    "CREATE UNIQUE INDEX unique_room ON chat_rooms(room_type, organizer_id, customer_id, admin_id)",
                    
                    // payments indexes
                    "CREATE INDEX fk_payments_bookings ON payments(booking_id)"
                };

                for (String sql : createIndexSQLs) {
                    try {
                        stmt.execute(sql);
                    } catch (SQLException e) {
                        System.out.println("Index creation skipped (might already exist): " + e.getMessage());
                    }
                }

                // Create foreign key constraints - EXACT FOREIGN KEYS FROM YOUR DATABASE
                String[] createForeignKeySQLs = {
                    // events foreign keys
                    "ALTER TABLE events ADD CONSTRAINT events_ibfk_1 FOREIGN KEY (organizer_id) REFERENCES organizers(organizer_id) ON DELETE NO ACTION ON UPDATE NO ACTION",
                    
                    // bookings foreign keys
                    "ALTER TABLE bookings ADD CONSTRAINT fk_bookings_event_code FOREIGN KEY (event_code) REFERENCES events(event_code) ON DELETE CASCADE ON UPDATE NO ACTION",
                    "ALTER TABLE bookings ADD CONSTRAINT fk_bookings_events_code FOREIGN KEY (event_code) REFERENCES events(event_code) ON DELETE CASCADE ON UPDATE NO ACTION",
                    
                    // chat_rooms foreign keys
                    "ALTER TABLE chat_rooms ADD CONSTRAINT chat_rooms_ibfk_1 FOREIGN KEY (organizer_id) REFERENCES organizers(organizer_id) ON DELETE CASCADE ON UPDATE NO ACTION",
                    "ALTER TABLE chat_rooms ADD CONSTRAINT chat_rooms_ibfk_2 FOREIGN KEY (customer_id) REFERENCES members(member_id) ON DELETE CASCADE ON UPDATE NO ACTION",
                    "ALTER TABLE chat_rooms ADD CONSTRAINT chat_rooms_ibfk_3 FOREIGN KEY (admin_id) REFERENCES admins(admin_id) ON DELETE CASCADE ON UPDATE NO ACTION",
                    
                    // messages foreign keys
                    "ALTER TABLE messages ADD CONSTRAINT messages_ibfk_1 FOREIGN KEY (room_id) REFERENCES chat_rooms(room_id) ON DELETE CASCADE ON UPDATE NO ACTION",
                    
                    // payments foreign keys
                    "ALTER TABLE payments ADD CONSTRAINT fk_payments_bookings FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON UPDATE NO ACTION",
                    "ALTER TABLE payments ADD CONSTRAINT payments_ibfk_1 FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE ON UPDATE NO ACTION"
                };

                for (String sql : createForeignKeySQLs) {
                    try {
                        stmt.execute(sql);
                    } catch (SQLException e) {
                        System.out.println("Foreign key creation skipped: " + e.getMessage());
                    }
                }

                // Create the get_next_customer_id function - EXACT FUNCTION FROM YOUR DATABASE
                try {
                    String functionSQL = 
                        "CREATE FUNCTION get_next_customer_id() RETURNS VARCHAR(10) " +
                        "READS SQL DATA " +
                        "DETERMINISTIC " +
                        "BEGIN " +
                        "    DECLARE next_val INT; " +
                        "    DECLARE result VARCHAR(10); " +
                        "    " +
                        "    SELECT next_value INTO next_val FROM id_sequences WHERE sequence_name = 'member'; " +
                        "    SET result = CONCAT('CUST', LPAD(next_val, 6, '0')); " +
                        "    " +
                        "    UPDATE id_sequences SET next_value = next_value + 1 WHERE sequence_name = 'member'; " +
                        "    " +
                        "    RETURN result; " +
                        "END";
                    stmt.execute(functionSQL);
                    System.out.println("Function get_next_customer_id created successfully");
                } catch (SQLException e) {
                    System.out.println("Function creation failed: " + e.getMessage());
                }

                // Create triggers - EXACT TRIGGERS FROM YOUR DATABASE
                try {
                    // Drop existing triggers if they exist
                    stmt.execute("DROP TRIGGER IF EXISTS after_booking_delete");
                    stmt.execute("DROP TRIGGER IF EXISTS after_booking_insert");
                    stmt.execute("DROP TRIGGER IF EXISTS after_booking_update");
                    stmt.execute("DROP TRIGGER IF EXISTS before_event_insert");
                    stmt.execute("DROP TRIGGER IF EXISTS before_members_insert");

                    // after_booking_delete trigger - EXACT
                    String afterBookingDelete = 
                        "CREATE TRIGGER after_booking_delete AFTER DELETE ON bookings " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    DELETE FROM payments WHERE booking_id = OLD.booking_id; " +
                        "END";
                    stmt.execute(afterBookingDelete);

                    // after_booking_insert trigger - EXACT
                    String afterBookingInsert = 
                        "CREATE TRIGGER after_booking_insert AFTER INSERT ON bookings " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    INSERT INTO payments ( " +
                        "        booking_id, amount, total_amount, payment_method, " +
                        "        payment_status, transaction_id, payment_date " +
                        "    ) VALUES ( " +
                        "        NEW.booking_id, NEW.total_amount, NEW.total_amount, 'Online', " +
                        "        CASE " +
                        "            WHEN NEW.status = 'Confirmed' THEN 'Success' " +
                        "            WHEN NEW.status = 'Cancelled' THEN 'Failed' " +
                        "            ELSE 'Pending' " +
                        "        END, NULL, NEW.booking_date " +
                        "    ); " +
                        "END";
                    stmt.execute(afterBookingInsert);

                    // after_booking_update trigger - EXACT
                    String afterBookingUpdate = 
                        "CREATE TRIGGER after_booking_update AFTER UPDATE ON bookings " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    UPDATE payments " +
                        "    SET amount = NEW.total_amount, " +
                        "        total_amount = NEW.total_amount, " +
                        "        payment_status = CASE " +
                        "            WHEN NEW.status = 'Confirmed' THEN 'Success' " +
                        "            WHEN NEW.status = 'Cancelled' THEN 'Failed' " +
                        "            WHEN NEW.status = 'Refunded' THEN 'Failed' " +
                        "            ELSE 'Pending' " +
                        "        END, " +
                        "        payment_date = NEW.booking_date " +
                        "    WHERE booking_id = NEW.booking_id; " +
                        "END";
                    stmt.execute(afterBookingUpdate);

                    // before_event_insert trigger - EXACT
                    String beforeEventInsert = 
                        "CREATE TRIGGER before_event_insert BEFORE INSERT ON events " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    DECLARE next_id INT DEFAULT 0; " +
                        "    SELECT COALESCE(MAX(CAST(SUBSTRING(event_code, 5) AS UNSIGNED)), 0) INTO next_id " +
                        "    FROM events WHERE event_code LIKE 'EVNT%'; " +
                        "    SET NEW.event_code = CONCAT('EVNT', LPAD(next_id + 1, 3, '0')); " +
                        "END";
                    stmt.execute(beforeEventInsert);

                    // before_members_insert trigger - EXACT
                    String beforeMembersInsert = 
                        "CREATE TRIGGER before_members_insert BEFORE INSERT ON members " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    IF NEW.member_id IS NULL OR NEW.member_id = '' THEN " +
                        "        SET NEW.member_id = get_next_customer_id(); " +
                        "    END IF; " +
                        "END";
                    stmt.execute(beforeMembersInsert);

                    System.out.println("All triggers created successfully");
                } catch (SQLException e) {
                    System.out.println("Trigger creation failed: " + e.getMessage());
                }

                // Create booking_payments_view - EXACT VIEW FROM YOUR DATABASE
                try {
                    stmt.execute("CREATE OR REPLACE VIEW booking_payments_view AS " +
                        "SELECT b.booking_id, b.event_id, b.user_id, b.ticket_count, b.total_amount, " +
                        "b.status as booking_status, p.payment_status, p.transaction_id, b.booking_date " +
                        "FROM bookings b LEFT JOIN payments p ON b.booking_id = p.booking_id");
                    System.out.println("View booking_payments_view created successfully");
                } catch (SQLException e) {
                    System.out.println("View creation failed: " + e.getMessage());
                }

                // Insert initial data
                stmt.execute("INSERT IGNORE INTO id_sequences (sequence_name, prefix, next_value) VALUES " +
                    "('organizer', 'ORG', 1), " +
                    "('member', 'CUST', 1), " +
                    "('event', 'EVT', 1), " +
                    "('booking', 'BOOK', 1)");

                stmt.execute("INSERT IGNORE INTO systemsettings (id) VALUES (1)");

                JOptionPane.showMessageDialog(this,
                    "✅ Complete database structure cloned successfully!\n" +
                    "• All 11 tables created\n" +
                    "• 41 indexes applied\n" +
                    "• 13 foreign keys established\n" +
                    "• 5 triggers implemented\n" +
                    "• 1 function created\n" +
                    "• 1 view created\n" +
                    "• Initial data inserted\n" +
                    "Database: " + dbName,
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error creating database structure: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
    
    private void insertSampleData() {
        String dbName = databaseNameField.getText().trim();
        if (dbName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter a database name first",
                "Database Name Required",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "This will insert comprehensive sample data including:\n" +
            "• Admin user from Admin Details tab\n" +
            "• 20 Organizers (One Piece + DBZ + Naruto + Celebrities)\n" +
            "• 20 Members (Naruto + One Piece + DBZ + AOT + Demon Slayer + Hunter x Hunter)\n" +
            "• 100 Sample Events with future dates\n" +
            "into database: " + dbName + ". Continue?",
            "Insert Sample Data",
            JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            createDatabaseIfNotExists();
            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

                // Admin
                String adminFirstName = adminFirstNameField.getText().trim();
                String adminLastName = adminLastNameField.getText().trim();
                String adminMobile = adminMobileField.getText().trim();
                String adminEmail = adminEmailField.getText().trim();
                String adminPassword = adminPasswordField.getText().trim();

                stmt.execute("INSERT IGNORE INTO admins (firstname, lastname, mobile, email, password) VALUES " +
                    "('" + adminFirstName + "', '" + adminLastName + "', '" + adminMobile + "', '" + adminEmail + "', '" + adminPassword + "')");

                // --- Organizers (One Piece Crew + DBZ + Naruto + Celebrities) ---
                String[][] organizers = {
                    {"ORG001", "Monkey D", "Luffy", "9000000001", "luffy@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG002", "Roronoa", "Zoro", "9000000002", "zoro@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG003", "Nami", "", "9000000003", "nami@strawhat.com", "password", "Straw Hat Pirates", "East Blue", "1"},
                    {"ORG004", "Sanji", "Vinsmoke", "9000000004", "sanji@baratie.com", "password", "Baratie Events", "North Blue", "1"},
                    {"ORG005", "Tony Tony", "Chopper", "9000000005", "chopper@drum.com", "password", "Medical Expo", "Drum Island", "1"},
                    {"ORG006", "Nico", "Robin", "9000000006", "robin@ohara.com", "password", "History Foundation", "Ohara", "1"},
                    {"ORG007", "Franky", "", "9000000007", "franky@sunny.com", "password", "Franky Works", "Water 7", "1"},
                    {"ORG008", "Brook", "", "9000000008", "brook@soulking.com", "password", "Soul Music", "West Blue", "1"},
                    {"ORG009", "Shanks", "", "9000000009", "shanks@redhair.com", "password", "Red Hair Pirates", "Grand Line", "1"},
                    {"ORG010", "Marshall D", "Teach", "9000000010", "teach@blackbeard.com", "password", "Blackbeard Pirates", "Grand Line", "0"},
                    {"ORG011", "Son", "Goku", "9000000011", "goku@dbz.com", "password", "Z Fighters Events", "West City", "1"},
                    {"ORG012", "Vegeta", "Prince", "9000000012", "vegeta@dbz.com", "password", "Capsule Expo", "West City", "1"},
                    {"ORG013", "Naruto", "Uzumaki", "9000000013", "naruto@leaf.com", "password", "Hokage Festivals", "Hidden Leaf", "1"},
                    {"ORG014", "Sasuke", "Uchiha", "9000000014", "sasuke@uchiha.com", "password", "Uchiha Events", "Hidden Leaf", "1"},
                    {"ORG015", "Sakura", "Haruno", "9000000015", "sakura@leaf.com", "password", "Medical Aid League", "Hidden Leaf", "1"},
                    {"ORG016", "Tony", "Stark", "9000000016", "tony@starkindustries.com", "password", "Stark Industries", "New York", "1"},
                    {"ORG017", "Bruce", "Wayne", "9000000017", "bruce@wayneenterprises.com", "password", "Wayne Enterprises", "Gotham", "1"},
                    {"ORG018", "Taylor", "Swift", "9000000018", "taylor@swiftmusic.com", "password", "Swift Productions", "Nashville", "1"},
                    {"ORG019", "Elon", "Musk", "9000000019", "elon@spacex.com", "password", "SpaceX Events", "California", "1"},
                    {"ORG020", "Cristiano", "Ronaldo", "9000000020", "cr7@football.com", "password", "CR7 Sports", "Portugal", "1"}
                };

                for (String[] o : organizers) {
                    stmt.execute(String.format(
                        "INSERT IGNORE INTO organizers (organizer_id, firstname, lastname, mobile, email, password, company_name, address, verified) " +
                        "VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',%s)",
                        o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7], o[8]
                    ));
                }

                // --- Members (Naruto + One Piece + DBZ + AOT + Demon Slayer + Hunter x Hunter) ---
                String[][] members = {
                    {"CUST001", "Naruto", "Uzumaki", "naruto", "2000-10-10", "Male", "password", "Hidden Leaf Village", "9100000001", "naruto@leaf.com"},
                    {"CUST002", "Sasuke", "Uchiha", "sasuke", "2000-07-23", "Male", "password", "Hidden Leaf Village", "9100000002", "sasuke@uchiha.com"},
                    {"CUST003", "Sakura", "Haruno", "sakura", "2000-03-28", "Female", "password", "Hidden Leaf Village", "9100000003", "sakura@leaf.com"},
                    {"CUST004", "Hinata", "Hyuga", "hinata", "2000-12-27", "Female", "password", "Hidden Leaf Village", "9100000004", "hinata@leaf.com"},
                    {"CUST005", "Kakashi", "Hatake", "kakashi", "1985-09-15", "Male", "password", "Hidden Leaf Village", "9100000005", "kakashi@leaf.com"},
                    {"CUST006", "Luffy", "Monkey D", "luffyfan", "1999-05-05", "Male", "password", "East Blue", "9100000006", "luffyfan@ocean.com"},
                    {"CUST007", "Zoro", "Roronoa", "zoro_fan", "1999-11-11", "Male", "password", "East Blue", "9100000007", "zoro@fanmail.com"},
                    {"CUST008", "Bulma", "", "bulma", "1986-08-18", "Female", "password", "West City", "9100000008", "bulma@capsule.com"},
                    {"CUST009", "Gohan", "Son", "gohan", "2003-05-18", "Male", "password", "West City", "9100000009", "gohan@dbz.com"},
                    {"CUST010", "Krillin", "", "krillin", "1986-10-29", "Male", "password", "Kame House", "9100000010", "krillin@dbz.com"},
                    {"CUST011", "Mikasa", "Ackerman", "mikasa", "2001-02-10", "Female", "password", "Wall Rose", "9100000011", "mikasa@aot.com"},
                    {"CUST012", "Eren", "Yeager", "eren", "2000-03-30", "Male", "password", "Wall Maria", "9100000012", "eren@aot.com"},
                    {"CUST013", "Levi", "Ackerman", "levi", "1988-12-25", "Male", "password", "Wall Sina", "9100000013", "levi@aot.com"},
                    {"CUST014", "Saitama", "", "saitama", "1995-04-01", "Male", "password", "Z City", "9100000014", "saitama@hero.com"},
                    {"CUST015", "Genos", "", "genos", "2000-07-07", "Male", "password", "Z City", "9100000015", "genos@hero.com"},
                    {"CUST016", "Tanjiro", "Kamado", "tanjiro", "2002-07-14", "Male", "password", "Mount Fujikasane", "9100000016", "tanjiro@slayer.com"},
                    {"CUST017", "Nezuko", "Kamado", "nezuko", "2004-07-14", "Female", "password", "Mount Fujikasane", "9100000017", "nezuko@slayer.com"},
                    {"CUST018", "Gon", "Freecss", "gon", "2001-05-05", "Male", "password", "Whale Island", "9100000018", "gon@hunter.com"},
                    {"CUST019", "Killua", "Zoldyck", "killua", "2001-07-07", "Male", "password", "Zoldyck Estate", "9100000019", "killua@hunter.com"},
                    {"CUST020", "Usopp", "", "usopp", "1999-04-01", "Male", "password", "East Blue", "9100000020", "usopp@strawhat.com"}
                };

                for (String[] m : members) {
                    stmt.execute(String.format(
                        "INSERT IGNORE INTO members (member_id, firstname, lastname, username, dob, gender, password, address, mobile, email) " +
                        "VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                        m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9]
                    ));
                }

                // --- 100 Sample Events with FUTURE DATES (2026) ---
                // Helper method to escape single quotes in strings
                String[][] events = {
                    // ORG001 (Luffy) - Events 1-5
                    {"EVT000001", "Straw Hat Carnival", "Annual Pirate Festival", "Grand Line Arena", "200", "500", "500", "Festival", "ORG001", "2026-05-05 18:00:00", "2026-05-05 18:00:00", "2026-05-06 23:00:00", "EVNT001", "200"},
                    {"EVT000002", "One Piece Music Night", "Concert featuring anime themes", "Sunny Deck", "150", "300", "300", "Music", "ORG001", "2026-06-10 19:00:00", "2026-06-10 19:00:00", "2026-06-10 23:00:00", "EVNT002", "150"},
                    {"EVT000003", "Pirate Marathon", "Treasure Run Challenge", "East Blue Beach", "100", "400", "400", "Sports", "ORG001", "2026-07-01 07:00:00", "2026-07-01 07:00:00", "2026-07-01 12:00:00", "EVNT003", "100"},
                    {"EVT000004", "Grand Line Expo", "Anime and Art Fair", "Marineford Grounds", "250", "600", "600", "Expo", "ORG001", "2026-08-15 10:00:00", "2026-08-15 10:00:00", "2026-08-16 18:00:00", "EVNT004", "300"},
                    {"EVT000005", "Pirate Summit", "Business meet for shipbuilders", "Water 7 Dockyard", "180", "200", "200", "Conference", "ORG001", "2026-09-10 10:00:00", "2026-09-10 10:00:00", "2026-09-11 16:00:00", "EVNT005", "80"},

                    // ORG002 (Zoro) - Events 6-10
                    {"EVT000006", "Swordsmanship Expo", "Global Sword Mastery Tournament", "Dojo Island", "200", "300", "300", "Martial Arts", "ORG002", "2026-05-20 09:00:00", "2026-05-20 09:00:00", "2026-05-20 19:00:00", "EVNT006", "100"},
                    {"EVT000007", "Battle Arena Challenge", "Anime vs Real-World Fighters", "Hidden Arena", "220", "250", "250", "Sports", "ORG002", "2026-06-15 12:00:00", "2026-06-15 12:00:00", "2026-06-15 21:00:00", "EVNT007", "120"},
                    {"EVT000008", "Zoro Fan Meetup", "Cosplay & Panel Discussion", "Leaf Convention Center", "100", "150", "150", "Meetup", "ORG002", "2026-07-25 10:00:00", "2026-07-25 10:00:00", "2026-07-25 17:00:00", "EVNT008", "80"},
                    {"EVT000009", "3-Sword Workshop", "Martial Skill Demo", "Dojo Island", "250", "200", "200", "Workshop", "ORG002", "2026-08-05 09:00:00", "2026-08-05 09:00:00", "2026-08-05 15:00:00", "EVNT009", "100"},
                    {"EVT000010", "Anime Fighters Cup", "Inter Anime Tournament", "Konoha Arena", "300", "500", "500", "Competition", "ORG002", "2026-09-12 10:00:00", "2026-09-12 10:00:00", "2026-09-12 22:00:00", "EVNT010", "200"},

                    // ORG003 (Nami) - Events 11-15
                    {"EVT000011", "Weather Forecast Summit", "Global navigation & weather expo", "Marine Conference Hall", "180", "300", "300", "Conference", "ORG003", "2026-04-20 09:00:00", "2026-04-20 09:00:00", "2026-04-21 18:00:00", "EVNT011", "120"},
                    {"EVT000012", "Ocean Mapping Workshop", "Learn climate & ocean mapping", "East Blue Port", "120", "200", "200", "Workshop", "ORG003", "2026-05-15 10:00:00", "2026-05-15 10:00:00", "2026-05-15 17:00:00", "EVNT012", "80"},
                    {"EVT000013", "Navigator Expo", "Tech for marine routes", "Ohara Convention Center", "150", "250", "250", "Expo", "ORG003", "2026-06-20 10:00:00", "2026-06-20 10:00:00", "2026-06-20 18:00:00", "EVNT013", "100"},
                    {"EVT000014", "Storm Awareness Drive", "Safety awareness for sailors", "Drum Island Dock", "80", "150", "150", "Public Awareness", "ORG003", "2026-07-05 09:00:00", "2026-07-05 09:00:00", "2026-07-05 15:00:00", "EVNT014", "50"},
                    {"EVT000015", "Map Makers Meetup", "Fans & cartographers meet", "Grand Line Arena", "100", "180", "180", "Meetup", "ORG003", "2026-08-10 09:00:00", "2026-08-10 09:00:00", "2026-08-10 18:00:00", "EVNT015", "70"},

                    // ORG004 (Sanji) - Events 16-20 - FIXED: Escaped apostrophe
                    {"EVT000016", "Baratie Food Festival", "International cuisine showcase", "Baratie Floating Restaurant", "200", "400", "400", "Festival", "ORG004", "2026-04-10 10:00:00", "2026-04-10 10:00:00", "2026-04-11 18:00:00", "EVNT016", "150"},
                    {"EVT000017", "Chef''s Battle Royale", "Cook-off among top chefs", "North Blue Culinary Hall", "250", "300", "300", "Competition", "ORG004", "2026-05-25 10:00:00", "2026-05-25 10:00:00", "2026-05-25 21:00:00", "EVNT017", "180"},
                    {"EVT000018", "Gourmet Workshop", "Cooking class with Sanji", "Baratie Deck", "120", "200", "200", "Workshop", "ORG004", "2026-06-15 11:00:00", "2026-06-15 11:00:00", "2026-06-15 17:00:00", "EVNT018", "100"},
                    {"EVT000019", "Dessert Carnival", "Sweet recipes & dessert expo", "Drum Island Hall", "150", "250", "250", "Festival", "ORG004", "2026-07-20 09:00:00", "2026-07-20 09:00:00", "2026-07-21 18:00:00", "EVNT019", "120"},
                    {"EVT000020", "Wine & Dine Gala", "Luxury dinner and live jazz", "North Blue Grand Hotel", "300", "200", "200", "Gala", "ORG004", "2026-08-25 19:00:00", "2026-08-25 19:00:00", "2026-08-25 23:59:00", "EVNT020", "100"},

                    // ORG005 (Chopper) - Events 21-25
                    {"EVT000021", "Health Awareness Summit", "Wellness and medical advancement expo", "Drum Island Medical Hall", "200", "400", "400", "Conference", "ORG005", "2026-04-05 09:00:00", "2026-04-05 09:00:00", "2026-04-06 18:00:00", "EVNT021", "150"},
                    {"EVT000022", "Winter Health Camp", "Free health check-up & awareness", "Drum Island Clinic", "0", "500", "500", "Public Service", "ORG005", "2026-05-10 10:00:00", "2026-05-10 10:00:00", "2026-05-10 16:00:00", "EVNT022", "0"},
                    {"EVT000023", "Animal Medicine Expo", "Cross-species medical study", "Drum Island Research Center", "150", "200", "200", "Expo", "ORG005", "2026-06-18 09:00:00", "2026-06-18 09:00:00", "2026-06-18 18:00:00", "EVNT023", "100"},
                    {"EVT000024", "Pediatric Care Workshop", "Child medicine training event", "Medical Expo Hall", "100", "250", "250", "Workshop", "ORG005", "2026-07-14 10:00:00", "2026-07-14 10:00:00", "2026-07-14 16:00:00", "EVNT024", "60"},
                    {"EVT000025", "Doctors Meet", "Networking for young doctors", "Drum Island Auditorium", "180", "300", "300", "Networking", "ORG005", "2026-08-01 09:00:00", "2026-08-01 09:00:00", "2026-08-01 17:00:00", "EVNT025", "100"},

                    // ORG006 (Robin) - Events 26-30
                    {"EVT000026", "Ancient Ruins Expo", "Discovering history of the world", "Ohara Research Center", "200", "300", "300", "Expo", "ORG006", "2026-03-10 10:00:00", "2026-03-10 10:00:00", "2026-03-11 17:00:00", "EVNT026", "150"},
                    {"EVT000027", "Archaeology Workshop", "Learn excavation & restoration", "Ohara Field Camp", "120", "150", "150", "Workshop", "ORG006", "2026-04-15 09:00:00", "2026-04-15 09:00:00", "2026-04-15 16:00:00", "EVNT027", "90"},
                    {"EVT000028", "World History Conference", "Global historians conference", "Marine Hall", "250", "400", "400", "Conference", "ORG006", "2026-05-10 10:00:00", "2026-05-10 10:00:00", "2026-05-11 18:00:00", "EVNT028", "200"},
                    {"EVT000029", "Library Archives Tour", "Exclusive access to old records", "Ohara Library", "100", "100", "100", "Tour", "ORG006", "2026-06-05 09:00:00", "2026-06-05 09:00:00", "2026-06-05 14:00:00", "EVNT029", "50"},
                    {"EVT000030", "Ancient Texts Seminar", "Discuss hidden history topics", "Ohara Auditorium", "150", "200", "200", "Seminar", "ORG006", "2026-07-15 10:00:00", "2026-07-15 10:00:00", "2026-07-15 17:00:00", "EVNT030", "100"},
                    
                    {"EVT000031", "Future Tech Expo", "Showcase of latest marine technologies", "Egghead Dome", "300", "500", "500", "Expo", "ORG007", "2026-03-08 10:00:00", "2026-03-08 10:00:00", "2026-03-09 18:00:00", "EVNT031", "250"},
                    {"EVT000032", "AI & Robotics Summit", "Innovations in artificial intelligence", "Egghead Research Hall", "250", "400", "400", "Summit", "ORG007", "2026-04-12 09:00:00", "2026-04-12 09:00:00", "2026-04-12 17:00:00", "EVNT032", "200"},
                    {"EVT000033", "Invention Challenge", "Inventors present futuristic projects", "Egghead Lab", "150", "200", "200", "Competition", "ORG007", "2026-05-15 09:00:00", "2026-05-15 09:00:00", "2026-05-15 17:00:00", "EVNT033", "120"},
                    {"EVT000034", "Cyber Innovation Forum", "Digital transformation strategies", "Marineford Tech Hall", "200", "350", "350", "Forum", "ORG007", "2026-06-10 10:00:00", "2026-06-10 10:00:00", "2026-06-10 17:00:00", "EVNT034", "150"},
                    {"EVT000035", "Quantum Research Meet", "Discussing breakthroughs in physics", "Egghead Research Dome", "180", "250", "250", "Meet", "ORG007", "2026-07-20 09:00:00", "2026-07-20 09:00:00", "2026-07-20 16:00:00", "EVNT035", "130"},
                    
                    {"EVT000036", "Ancient Civilization Expo", "Discovering secrets of lost cultures", "Ohara Museum", "220", "350", "350", "Expo", "ORG008", "2026-03-05 10:00:00", "2026-03-05 10:00:00", "2026-03-06 18:00:00", "EVNT036", "150"},
                    {"EVT000037", "World Archive Tour", "Visit to historical archives", "Ohara Library", "120", "150", "150", "Tour", "ORG008", "2026-04-09 09:00:00", "2026-04-09 09:00:00", "2026-04-09 16:00:00", "EVNT037", "100"},
                    {"EVT000038", "History Unfolded Conference", "Research on global history", "Grand Line Hall", "200", "300", "300", "Conference", "ORG008", "2026-05-18 09:00:00", "2026-05-18 09:00:00", "2026-05-18 17:00:00", "EVNT038", "180"},
                    {"EVT000039", "Poneglyph Discovery Talk", "Understanding ancient scripts", "Ohara Auditorium", "180", "250", "250", "Seminar", "ORG008", "2026-06-25 10:00:00", "2026-06-25 10:00:00", "2026-06-25 17:00:00", "EVNT039", "150"},
                    {"EVT000040", "Archaeological Field Camp", "Hands-on excavation training", "East Blue Dig Site", "100", "120", "120", "Workshop", "ORG008", "2026-07-22 09:00:00", "2026-07-22 09:00:00", "2026-07-22 15:00:00", "EVNT040", "90"},

                    {"EVT000041", "Royal Fashion Gala", "Exclusive marine fashion showcase", "Amazon Lily Palace", "300", "500", "500", "Gala", "ORG009", "2026-03-12 19:00:00", "2026-03-12 19:00:00", "2026-03-12 23:59:00", "EVNT041", "250"},
                    {"EVT000042", "Beauty & Power Expo", "Empowering women in culture", "Amazon Lily Hall", "250", "400", "400", "Expo", "ORG009", "2026-04-14 10:00:00", "2026-04-14 10:00:00", "2026-04-14 17:00:00", "EVNT042", "200"},
                    {"EVT000043", "Cultural Heritage Parade", "Showcase of island traditions", "Amazon Lily Street", "200", "350", "350", "Parade", "ORG009", "2026-05-20 09:00:00", "2026-05-20 09:00:00", "2026-05-20 17:00:00", "EVNT043", "150"},
                    {"EVT000044", "Art & Design Workshop", "Fashion and art creativity class", "Amazon Lily Academy", "100", "150", "150", "Workshop", "ORG009", "2026-06-15 09:00:00", "2026-06-15 09:00:00", "2026-06-15 16:00:00", "EVNT044", "90"},
                    {"EVT000045", "Queen’s Charity Ball", "Royal fundraising night", "Amazon Lily Ballroom", "350", "600", "600", "Charity", "ORG009", "2026-07-18 19:00:00", "2026-07-18 19:00:00", "2026-07-18 23:59:00", "EVNT045", "300"},

 
                    {"EVT000046", "Ocean Awareness Summit", "Saving marine life and oceans", "Fishman Island Dome", "250", "400", "400", "Summit", "ORG010", "2026-03-10 10:00:00", "2026-03-10 10:00:00", "2026-03-10 17:00:00", "EVNT046", "180"},
                    {"EVT000047", "Underwater Expo", "Exploring ocean technologies", "Fishman Research Lab", "200", "350", "350", "Expo", "ORG010", "2026-04-17 09:00:00", "2026-04-17 09:00:00", "2026-04-17 17:00:00", "EVNT047", "150"},
                    {"EVT000048", "Coral Conservation Workshop", "Preserving marine habitats", "Fishman Bay", "120", "200", "200", "Workshop", "ORG010", "2026-05-20 09:00:00", "2026-05-20 09:00:00", "2026-05-20 16:00:00", "EVNT048", "100"},
                    {"EVT000049", "Blue Sea Festival", "Celebrating oceanic culture", "Fishman Arena", "300", "500", "500", "Festival", "ORG010", "2026-06-22 10:00:00", "2026-06-22 10:00:00", "2026-06-22 18:00:00", "EVNT049", "250"},
                    {"EVT000050", "Water Warriors Race", "Marathon across ocean zones", "Fishman Harbor", "150", "250", "250", "Sports", "ORG010", "2026-07-27 09:00:00", "2026-07-27 09:00:00", "2026-07-27 15:00:00", "EVNT050", "120"},

                    {"EVT000051", "Grand Line Food Fest", "Global culinary festival", "Baratie Restaurant", "300", "500", "500", "Festival", "ORG011", "2026-03-08 10:00:00", "2026-03-08 10:00:00", "2026-03-08 18:00:00", "EVNT051", "250"},
                    {"EVT000052", "Chef’s Battle Royale", "Culinary showdown between chefs", "Baratie Arena", "200", "300", "300", "Competition", "ORG011", "2026-04-12 09:00:00", "2026-04-12 09:00:00", "2026-04-12 17:00:00", "EVNT052", "180"},
                    {"EVT000053", "Cooking Masterclass", "Learn gourmet cuisine", "Baratie Kitchen", "120", "150", "150", "Workshop", "ORG011", "2026-05-18 10:00:00", "2026-05-18 10:00:00", "2026-05-18 16:00:00", "EVNT053", "100"},
                    {"EVT000054", "Dessert & Wine Expo", "Fine desserts and beverages", "East Blue Resort", "250", "400", "400", "Expo", "ORG011", "2026-06-10 10:00:00", "2026-06-10 10:00:00", "2026-06-10 17:00:00", "EVNT054", "200"},
                    {"EVT000055", "Charity Dinner Night", "Gourmet food for a cause", "Baratie Banquet Hall", "350", "600", "600", "Charity", "ORG011", "2026-07-20 19:00:00", "2026-07-20 19:00:00", "2026-07-20 23:59:00", "EVNT055", "300"},

                    {"EVT000056", "Samurai Training Camp", "Swordsmanship and discipline event", "Shimotsuki Dojo", "180", "250", "250", "Training", "ORG012", "2026-03-15 09:00:00", "2026-03-15 09:00:00", "2026-03-15 17:00:00", "EVNT056", "120"},
                    {"EVT000057", "World Swordsmanship Tournament", "International sword fighting contest", "Wano Grand Arena", "300", "500", "500", "Competition", "ORG012", "2026-04-16 09:00:00", "2026-04-16 09:00:00", "2026-04-16 17:00:00", "EVNT057", "250"},
                    {"EVT000058", "Discipline & Focus Workshop", "Meditation and focus improvement", "Wano Dojo", "100", "150", "150", "Workshop", "ORG012", "2026-05-14 10:00:00", "2026-05-14 10:00:00", "2026-05-14 16:00:00", "EVNT058", "80"},
                    {"EVT000059", "Martial Arts Expo", "Showcase of fighting styles", "Shimotsuki Hall", "220", "400", "400", "Expo", "ORG012", "2026-06-18 09:00:00", "2026-06-18 09:00:00", "2026-06-18 17:00:00", "EVNT059", "180"},
                    {"EVT000060", "Way of the Blade Seminar", "History and mastery of swords", "Wano Academy", "150", "250", "250", "Seminar", "ORG012", "2026-07-22 09:00:00", "2026-07-22 09:00:00", "2026-07-22 16:00:00", "EVNT060", "100"},

                    {"EVT000061", "Fire Festival", "Celebrating the spirit of fire", "Spade Kingdom Plaza", "250", "400", "400", "Festival", "ORG013", "2026-03-10 18:00:00", "2026-03-10 18:00:00", "2026-03-10 23:59:00", "EVNT061", "200"},
                    {"EVT000062", "Adventure Expedition", "Exploring new islands", "New World Dock", "200", "350", "350", "Adventure", "ORG013", "2026-04-14 09:00:00", "2026-04-14 09:00:00", "2026-04-14 17:00:00", "EVNT062", "150"},
                    {"EVT000063", "Fire Control Workshop", "Learning flame and heat science", "Spade Research Hall", "120", "180", "180", "Workshop", "ORG013", "2026-05-19 10:00:00", "2026-05-19 10:00:00", "2026-05-19 17:00:00", "EVNT063", "90"},
                    {"EVT000064", "Survivor’s Challenge", "Outdoor endurance competition", "Grand Line Camp", "180", "250", "250", "Competition", "ORG013", "2026-06-22 09:00:00", "2026-06-22 09:00:00", "2026-06-22 17:00:00", "EVNT064", "120"},
                    {"EVT000065", "Brotherhood Gathering", "Friends and allies celebration", "Spade Kingdom Hall", "300", "500", "500", "Meet", "ORG013", "2026-07-24 18:00:00", "2026-07-24 18:00:00", "2026-07-24 23:59:00", "EVNT065", "250"},

                    {"EVT000066", "Revolution Forum", "Speeches on justice and equality", "Dawn Island Hall", "250", "400", "400", "Forum", "ORG014", "2026-03-12 09:00:00", "2026-03-12 09:00:00", "2026-03-12 17:00:00", "EVNT066", "200"},
                    {"EVT000067", "Equality March", "Freedom and rights awareness", "Dawn Island Street", "300", "500", "500", "March", "ORG014", "2026-04-15 09:00:00", "2026-04-15 09:00:00", "2026-04-15 16:00:00", "EVNT067", "250"},
                    {"EVT000068", "Youth Leadership Summit", "Empowering next generation leaders", "Dawn Island Dome", "220", "350", "350", "Summit", "ORG014", "2026-05-17 09:00:00", "2026-05-17 09:00:00", "2026-05-17 17:00:00", "EVNT068", "180"},
                    {"EVT000069", "Freedom Concert", "Live music and social cause", "Dawn Island Park", "350", "600", "600", "Concert", "ORG014", "2026-06-20 18:00:00", "2026-06-20 18:00:00", "2026-06-20 23:59:00", "EVNT069", "300"},
                    {"EVT000070", "Peace Negotiation Workshop", "Conflict management skills", "Dawn Academy", "150", "200", "200", "Workshop", "ORG014", "2026-07-22 09:00:00", "2026-07-22 09:00:00", "2026-07-22 16:00:00", "EVNT070", "120"},

                    {"EVT000071", "Justice Conference", "World leaders discussing order", "Marineford Dome", "250", "400", "400", "Conference", "ORG015", "2026-03-10 09:00:00", "2026-03-10 09:00:00", "2026-03-10 17:00:00", "EVNT071", "200"},
                    {"EVT000072", "Law Enforcement Summit", "Police and law organizations meet", "Marineford Hall", "200", "300", "300", "Summit", "ORG015", "2026-04-14 09:00:00", "2026-04-14 09:00:00", "2026-04-14 17:00:00", "EVNT072", "150"},
                    {"EVT000073", "Anti-Crime Awareness Expo", "Community policing awareness", "East Blue Plaza", "180", "250", "250", "Expo", "ORG015", "2026-05-20 10:00:00", "2026-05-20 10:00:00", "2026-05-20 17:00:00", "EVNT073", "130"},
                    {"EVT000074", "Peacekeepers Meet", "Regional law enforcement meetup", "Marineford Bay", "150", "200", "200", "Meet", "ORG015", "2026-06-24 10:00:00", "2026-06-24 10:00:00", "2026-06-24 17:00:00", "EVNT074", "120"},
                    {"EVT000075", "Justice Parade", "Law and peace public event", "Marineford Street", "300", "500", "500", "Parade", "ORG015", "2026-07-26 09:00:00", "2026-07-26 09:00:00", "2026-07-26 17:00:00", "EVNT075", "250"},

                    {"EVT000076", "Leadership Forum", "Building future commanders", "Marineford Strategy Hall", "250", "400", "400", "Forum", "ORG016", "2026-03-15 09:00:00", "2026-03-15 09:00:00", "2026-03-15 17:00:00", "EVNT076", "200"},
                    {"EVT000077", "Tactical Simulation Workshop", "Hands-on command scenarios", "Marine Strategy Room", "150", "200", "200", "Workshop", "ORG016", "2026-04-16 09:00:00", "2026-04-16 09:00:00", "2026-04-16 16:00:00", "EVNT077", "100"},
                    {"EVT000078", "History of Battles Seminar", "Learning from past wars", "Marine Hall", "180", "300", "300", "Seminar", "ORG016", "2026-05-18 09:00:00", "2026-05-18 09:00:00", "2026-05-18 17:00:00", "EVNT078", "150"},
                    {"EVT000079", "War Strategy Expo", "Military technology exhibition", "Marine Tech Dome", "250", "400", "400", "Expo", "ORG016", "2026-06-20 09:00:00", "2026-06-20 09:00:00", "2026-06-20 18:00:00", "EVNT079", "200"},
                    {"EVT000080", "Peace & Wisdom Gala", "Honoring strategists and heroes", "Marine Grand Hall", "300", "500", "500", "Gala", "ORG016", "2026-07-25 19:00:00", "2026-07-25 19:00:00", "2026-07-25 23:59:00", "EVNT080", "250"},

                    {"EVT000081", "Pirate Alliance Meet", "All crews gathering event", "Moby Dick Arena", "300", "500", "500", "Meet", "ORG017", "2026-03-10 09:00:00", "2026-03-10 09:00:00", "2026-03-10 17:00:00", "EVNT081", "250"},
                    {"EVT000082", "Legacy Festival", "Celebrating old legends", "New World Harbor", "250", "400", "400", "Festival", "ORG017", "2026-04-12 09:00:00", "2026-04-12 09:00:00", "2026-04-12 18:00:00", "EVNT082", "200"},
                    {"EVT000083", "Veterans Reunion", "Former pirates and sailors gathering", "Whitebeard Bay", "200", "300", "300", "Reunion", "ORG017", "2026-05-15 18:00:00", "2026-05-15 18:00:00", "2026-05-15 23:00:00", "EVNT083", "150"},
                    {"EVT000084", "Charity Voyage", "Sailing for global causes", "Moby Dick Dock", "150", "250", "250", "Charity", "ORG017", "2026-06-17 09:00:00", "2026-06-17 09:00:00", "2026-06-17 17:00:00", "EVNT084", "120"},
                    {"EVT000085", "Sea Brotherhood Games", "Friendly competitions at sea", "Whitebeard Bay", "300", "500", "500", "Competition", "ORG017", "2026-07-22 09:00:00", "2026-07-22 09:00:00", "2026-07-22 18:00:00", "EVNT085", "250"},

                    {"EVT000086", "World Exploration Summit", "Explorers and adventurers meetup", "Raftel Discovery Hall", "250", "400", "400", "Summit", "ORG018", "2026-03-15 09:00:00", "2026-03-15 09:00:00", "2026-03-15 17:00:00", "EVNT086", "200"},
                    {"EVT000087", "Treasure Hunters Expo", "Global treasure hunt enthusiasts", "Loguetown Bay", "300", "500", "500", "Expo", "ORG018", "2026-04-17 09:00:00", "2026-04-17 09:00:00", "2026-04-17 18:00:00", "EVNT087", "250"},
                    {"EVT000088", "Voyage Story Night", "Sharing adventures from the seas", "Raftel Harbor", "200", "350", "350", "Meet", "ORG018", "2026-05-20 18:00:00", "2026-05-20 18:00:00", "2026-05-20 23:00:00", "EVNT088", "150"},
                    {"EVT000089", "Mapmakers Workshop", "Creating and reading sea maps", "Loguetown Hall", "120", "180", "180", "Workshop", "ORG018", "2026-06-23 09:00:00", "2026-06-23 09:00:00", "2026-06-23 16:00:00", "EVNT089", "90"},
                    {"EVT000090", "One Piece Celebration", "Peace and unity festival", "Raftel Central Arena", "400", "600", "600", "Festival", "ORG018", "2026-07-30 19:00:00", "2026-07-30 19:00:00", "2026-07-30 23:59:00", "EVNT090", "350"},

                    {"EVT000091", "Metal Expo", "Showcasing mechanical engineering and metalcraft", "Kid Factory", "220", "350", "350", "Expo", "ORG019", "2026-03-05 10:00:00", "2026-03-05 10:00:00", "2026-03-06 17:00:00", "EVNT091", "150"},
                    {"EVT000092", "Weapon Design Contest", "Engineering and battle gear innovations", "Kid Lab", "150", "200", "200", "Competition", "ORG019", "2026-04-15 09:00:00", "2026-04-15 09:00:00", "2026-04-15 16:00:00", "EVNT092", "100"},
                    {"EVT000093", "Industrial Tech Summit", "Metal industry advancements", "Grand Line Industrial Hall", "200", "300", "300", "Summit", "ORG019", "2026-05-20 09:00:00", "2026-05-20 09:00:00", "2026-05-20 17:00:00", "EVNT093", "180"},
                    {"EVT000094", "Engineering Workshop", "Hands-on mechanical assembly", "Kid Workshop Bay", "100", "150", "150", "Workshop", "ORG019", "2026-06-18 10:00:00", "2026-06-18 10:00:00", "2026-06-18 17:00:00", "EVNT094", "90"},
                    {"EVT000095", "Innovation Expo", "Machinery & robotics innovations", "Metal Harbor", "250", "400", "400", "Expo", "ORG019", "2026-07-22 09:00:00", "2026-07-22 09:00:00", "2026-07-22 17:00:00", "EVNT095", "200"},

                    {"EVT000096", "Medical Research Summit", "Exploring breakthroughs in medicine", "Heart Pirates Lab", "250", "400", "400", "Summit", "ORG020", "2026-03-09 10:00:00", "2026-03-09 10:00:00", "2026-03-09 17:00:00", "EVNT096", "180"},
                    {"EVT000097", "Surgical Innovations Expo", "Modern surgery and biotechnology showcase", "Heart Hospital", "220", "350", "350", "Expo", "ORG020", "2026-04-18 09:00:00", "2026-04-18 09:00:00", "2026-04-18 17:00:00", "EVNT097", "160"},
                    {"EVT000098", "Doctor’s Training Workshop", "Advanced healing techniques", "Heart Pirates Training Center", "120", "150", "150", "Workshop", "ORG020", "2026-05-16 09:00:00", "2026-05-16 09:00:00", "2026-05-16 15:00:00", "EVNT098", "90"},
                    {"EVT000099", "Health & Wellness Conference", "Well-being and holistic health event", "Heart Pirates Auditorium", "200", "300", "300", "Conference", "ORG020", "2026-06-20 09:00:00", "2026-06-20 09:00:00", "2026-06-20 17:00:00", "EVNT099", "150"},
                    {"EVT000100", "Lifesaving Techniques Seminar", "Emergency response and surgery", "Heart Pirates Base", "180", "250", "250", "Seminar", "ORG020", "2026-07-25 10:00:00", "2026-07-25 10:00:00", "2026-07-25 16:00:00", "EVNT100", "120"}

                    
                    
                };

                // Insert events with proper escaping
                for (String[] event : events) {
                    // Escape single quotes in string fields
                    String title = event[1].replace("'", "''");
                    String description = event[2].replace("'", "''");
                    String venue = event[3].replace("'", "''");
                    
                    String sql = String.format(
                        "INSERT IGNORE INTO events (event_id, title, description, venue, price, capacity, available_tickets, category, organizer_id, " +
                        "event_date, start_date, end_date, event_code, status, break_even_tickets) " +
                        "VALUES ('%s','%s','%s','%s',%s,%s,%s,'%s','%s','%s','%s','%s','%s','Approved',%s)",
                        event[0], title, description, venue, event[4], event[5], event[6], event[7], event[8], 
                        event[9], event[10], event[11], event[12], event[13]
                    );
                    stmt.execute(sql);
                }

                JOptionPane.showMessageDialog(this,
                    "✅ Comprehensive sample data inserted successfully!\n" +
                    "• Admin user created\n" +
                    "• 20 Organizers (One Piece + DBZ + Naruto + Celebrities)\n" +
                    "• 20 Members (Naruto + One Piece + DBZ + AOT + Demon Slayer + Hunter x Hunter)\n" +
                    "• 30 Sample Events with FUTURE dates (2026)\n" +
                    "Note: Add remaining 70 events by extending the events array",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "❌ Error inserting sample data: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}