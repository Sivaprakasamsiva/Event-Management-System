package com.Mavan.EventManagementSystem.OrganizerChat;


import javax.swing.*;

import com.Mavan.EventManagementSystem.ChatService.RealTimeChatFrame;

import java.awt.*;

public class OrganizerChat extends RealTimeChatFrame {
    
    public OrganizerChat(String organizerId) {
        super("Organizer Chat", organizerId, "ORGANIZER");
    }
    
    @Override
    protected Color getUserColor() {
        return ORGANIZER_COLOR;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrganizerChat("ORG003"));
    }
}