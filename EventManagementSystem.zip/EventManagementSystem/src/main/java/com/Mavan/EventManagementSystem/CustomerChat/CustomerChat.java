package com.Mavan.EventManagementSystem.CustomerChat;

import javax.swing.*;

import com.Mavan.EventManagementSystem.ChatService.RealTimeChatFrame;

import java.awt.*;

public class CustomerChat extends RealTimeChatFrame {
    
    public CustomerChat(String customerId) {
        super("Customer Chat", customerId, "CUSTOMER");
    }
    
    @Override
    protected Color getUserColor() {
        return Color.GREEN;
    }
    
    public static void main(String[] args) {
        new CustomerChat("CUST001");
    }
}