package com.Mavan.EventManagementSystem.DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

import com.Mavan.EventManagementSystem.ConfigManager.ConfigManager;

public class DBConnection {
    private static ConfigManager cfg = new ConfigManager();

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Get the latest configuration values each time
            String url = cfg.getCompleteDbUrl();
            String user = cfg.get("DB_USER");    
            String pass = cfg.get("DB_PASS");
            
            System.out.println("Connecting to: " + url); // Debug line
            System.out.println("Username: " + user); // Debug line
            
            Connection conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Database connection successful!");
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Database connection failed!\n" +
                "URL: " + cfg.getCompleteDbUrl() + "\n" +
                "User: " + cfg.get("DB_USER") + "\n" +
                "Error: " + e.getMessage(),
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    // Helper method to close connections properly
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    // Method to test connection (useful for debugging)
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}