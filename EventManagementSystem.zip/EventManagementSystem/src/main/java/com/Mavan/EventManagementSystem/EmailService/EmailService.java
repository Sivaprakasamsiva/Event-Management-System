package com.Mavan.EventManagementSystem.EmailService;


import java.sql.*;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.io.File;
import java.io.FileOutputStream;

import com.Mavan.EventManagementSystem.ConfigManager.ConfigManager;
import com.Mavan.EventManagementSystem.DBConnection.DBConnection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;



import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPCell;

public class EmailService {
    static ConfigManager cfg = new ConfigManager();
    
    // Email configuration
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    private static final String USERNAME = cfg.get("EMAIL_USER");
    private static final String PASSWORD = cfg.get("EMAIL_APP_PASSWORD");
    private static final String FROM_EMAIL = cfg.get("EMAIL_HOST");
    
    public static boolean sendBookingConfirmation(String bookingId, String customerEmail) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            // First verify the booking exists and get basic details
            conn = DBConnection.getConnection();
            String checkSql = "SELECT b.booking_id, e.title, m.firstname FROM bookings b " +
                            "JOIN events e ON b.event_code = e.event_code " +
                            "JOIN members m ON b.user_id = m.member_id " +
                            "WHERE b.booking_id = ?";
            ps = conn.prepareStatement(checkSql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (!rs.next()) {
                System.out.println("Booking not found: " + bookingId);
                return false;
            }
            
            String eventTitle = rs.getString("title");
            String customerName = rs.getString("firstname");
            
            // Close previous result set and statement
            rs.close();
            ps.close();
            
            // Generate PDF invoice
            String pdfFilePath = generateBookingPDF(bookingId);
            
            if (pdfFilePath != null) {
                System.out.println("PDF generated successfully: " + pdfFilePath);
                
                boolean sent = sendEmailWithAttachment(customerEmail, 
                    "Event Booking Confirmation - " + eventTitle + " (Booking ID: " + bookingId + ")",
                    getEmailBody(bookingId, customerName, eventTitle),
                    pdfFilePath);
                
                // Clean up PDF file after sending
                File pdfFile = new File(pdfFilePath);
                if (pdfFile.exists()) {
                    pdfFile.delete();
                }
                return sent;
            } else {
                System.out.println("Failed to generate PDF for booking: " + bookingId);
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private static String generateBookingPDF(String bookingId) {
        String filePath = System.getProperty("java.io.tmpdir") + "/booking_" + bookingId + ".pdf";
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        Document document = new Document();
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, b.ticket_count, b.total_amount, b.booking_date, " +
                        "e.title, e.venue, e.event_date, e.price, e.description, " +
                        "m.firstname, m.lastname, m.email, m.mobile, m.address " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "JOIN members m ON b.user_id = m.member_id " +
                        "WHERE b.booking_id = ?";
            
            ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                PdfWriter.getInstance(document, new FileOutputStream(filePath));
                document.open();
                
                // Title
                Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.BLUE);
                Paragraph title = new Paragraph("EVENT BOOKING CONFIRMATION", titleFont);
                title.setAlignment(Element.ALIGN_CENTER);
                title.setSpacingAfter(20);
                document.add(title);
                
                // Booking Details Section
                Font sectionFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.DARK_GRAY);
                Paragraph bookingSection = new Paragraph("Booking Details", sectionFont);
                bookingSection.setSpacingAfter(10);
                document.add(bookingSection);
                
                // Booking Details Table
                PdfPTable bookingTable = new PdfPTable(2);
                bookingTable.setWidthPercentage(100);
                bookingTable.setSpacingBefore(10);
                bookingTable.setSpacingAfter(15);
                
                addTableRow(bookingTable, "Booking ID:", rs.getString("booking_id"));
                addTableRow(bookingTable, "Booking Date:", formatDate(rs.getString("booking_date")));
                addTableRow(bookingTable, "Number of Tickets:", String.valueOf(rs.getInt("ticket_count")));
                addTableRow(bookingTable, "Total Amount:", "₹" + String.format("%.2f", rs.getDouble("total_amount")));
                
                document.add(bookingTable);
                
                // Customer Details Section
                Paragraph customerSection = new Paragraph("Customer Information", sectionFont);
                customerSection.setSpacingAfter(10);
                document.add(customerSection);
                
                PdfPTable customerTable = new PdfPTable(2);
                customerTable.setWidthPercentage(100);
                customerTable.setSpacingBefore(10);
                customerTable.setSpacingAfter(15);
                
                addTableRow(customerTable, "Name:", rs.getString("firstname") + " " + rs.getString("lastname"));
                addTableRow(customerTable, "Email:", rs.getString("email"));
                addTableRow(customerTable, "Mobile:", rs.getString("mobile"));
                if (rs.getString("address") != null) {
                    addTableRow(customerTable, "Address:", rs.getString("address"));
                }
                
                document.add(customerTable);
                
                // Event Details Section
                Paragraph eventSection = new Paragraph("Event Information", sectionFont);
                eventSection.setSpacingAfter(10);
                document.add(eventSection);
                
                PdfPTable eventTable = new PdfPTable(2);
                eventTable.setWidthPercentage(100);
                eventTable.setSpacingBefore(10);
                eventTable.setSpacingAfter(15);
                
                addTableRow(eventTable, "Event Title:", rs.getString("title"));
                addTableRow(eventTable, "Venue:", rs.getString("venue"));
                addTableRow(eventTable, "Event Date:", formatDate(rs.getString("event_date")));
                addTableRow(eventTable, "Price per Ticket:", "₹" + String.format("%.2f", rs.getDouble("price")));
                if (rs.getString("description") != null) {
                    addTableRow(eventTable, "Description:", rs.getString("description"));
                }
                
                document.add(eventTable);
                
                // Thank you message
                Font thankYouFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);
                Paragraph thankYou = new Paragraph("\n\nThank you for your booking! We look forward to seeing you at the event.", thankYouFont);
                thankYou.setAlignment(Element.ALIGN_CENTER);
                document.add(thankYou);
                
                document.close();
                return filePath;
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (document.isOpen()) {
                document.close();
            }
            // Delete the file if creation failed
            new File(filePath).delete();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    
    private static void addTableRow(PdfPTable table, String header, String value) {
        Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Font valueFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
        
        PdfPCell headerCell = new PdfPCell(new Phrase(header, headerFont));
        headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        headerCell.setBorderWidth(1);
        headerCell.setPadding(5);
        
        PdfPCell valueCell = new PdfPCell(new Phrase(value != null ? value : "N/A", valueFont));
        valueCell.setBorderWidth(1);
        valueCell.setPadding(5);
        
        table.addCell(headerCell);
        table.addCell(valueCell);
    }
    
    private static String formatDate(String dateTime) {
        try {
            if (dateTime == null) return "N/A";
            // Format: 2024-01-15 18:30:00 -> Jan 15, 2024 18:30
            String[] parts = dateTime.split(" ")[0].split("-");
            String year = parts[0];
            String month = getMonthName(Integer.parseInt(parts[1]));
            String day = parts[2];
            String time = dateTime.split(" ")[1].substring(0, 5);
            
            return month + " " + day + ", " + year + " " + time;
        } catch (Exception e) {
            return dateTime;
        }
    }
    
    private static String getMonthName(int month) {
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        return months[month - 1];
    }
    
    private static String getEmailBody(String bookingId, String customerName, String eventTitle) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT b.ticket_count, b.total_amount, e.venue, e.event_date " +
                        "FROM bookings b " +
                        "JOIN events e ON b.event_code = e.event_code " +
                        "WHERE b.booking_id = ?";
            
            ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                return "Dear " + customerName + ",\n\n" +
                       "Your event booking has been confirmed successfully!\n\n" +
                       "📋 BOOKING SUMMARY:\n" +
                       "• Booking ID: " + bookingId + "\n" +
                       "• Event: " + eventTitle + "\n" +
                       "• Venue: " + rs.getString("venue") + "\n" +
                       "• Event Date: " + formatDate(rs.getString("event_date")) + "\n" +
                       "• Tickets: " + rs.getInt("ticket_count") + "\n" +
                       "• Total Amount: ₹" + String.format("%.2f", rs.getDouble("total_amount")) + "\n\n" +
                       "📎 Your detailed booking invoice is attached to this email.\n\n" +
                       "Please keep this booking confirmation for your records.\n" +
                       "If you have any questions, please contact our support team.\n\n" +
                       "Best regards,\n" +
                       "Event Management Team";
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) DBConnection.closeConnection(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return "Your booking has been confirmed. Booking ID: " + bookingId;
    }
    
    private static boolean sendEmailWithAttachment(String toEmail, String subject, String body, String attachmentPath) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            
            Session session = Session.getInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(USERNAME, PASSWORD);
                }
            });
            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            
            // Create the message part
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(body);
            
            // Create multipart message
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            
            // Attachment part
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(new File(attachmentPath));
            multipart.addBodyPart(attachmentPart);
            
            message.setContent(multipart);
            
            // Send message
            Transport.send(message);
            System.out.println("Email sent successfully to: " + toEmail);
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to send email to: " + toEmail);
            e.printStackTrace();
            return false;
        }
    }
}