package com.Event_Management.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connectors.DBConnection;
import Connectors.OTPCheck;

public class App extends JFrame {

    public App() {
        setTitle("Event Management - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 350);
        setLocationRelativeTo(null); // center on screen

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));

        // Title
        JLabel titleLabel = new JLabel("Event Management System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(new Color(70, 130, 180)); // Steel Blue
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userLabel = new JLabel("Username / Email / Mobile:");
        JTextField userField = new JTextField();
        GridBagConstraints gbc1 = new GridBagConstraints();
        gbc1.insets = new Insets(10, 10, 10, 10);
        gbc1.fill = GridBagConstraints.HORIZONTAL; // allow horizontal expansion
        gbc1.weightx = 1.0; // takes available extra horizontal space
        gbc1.gridx = 1; gbc1.gridy = 0;
        formPanel.add(userField, gbc1);
        
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField();
        gbc.gridx = 1; gbc.gridy = 1;
        formPanel.add(passField, gbc);
        
        JLabel roleLabel = new JLabel("Select Role:");
        String[] roles = {"Customer", "Organizer", "Admin"};
        JComboBox<String> roleCombo = new JComboBox<>(roles);

        JButton loginButton = new JButton("Login");
        JButton clearButton = new JButton("Clear");
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setPreferredSize(new Dimension(100, 35));
        clearButton.setPreferredSize(new Dimension(100, 35));

        JLabel registerLabel = new JLabel("<HTML><U>Register Here</U></HTML>");
        registerLabel.setForeground(new Color(0, 102, 204));
        registerLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JLabel SetupLabel = new JLabel("<HTML><U>Setup Here</U></HTML>");
        SetupLabel.setForeground(new Color(200, 102, 204));
        SetupLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Layout components
        gbc1.gridx = 0; gbc1.gridy = 0; formPanel.add(userLabel, gbc1);
        gbc1.gridx = 1; formPanel.add(userField, gbc1);

        gbc1.gridx = 0; gbc1.gridy = 1; formPanel.add(passLabel, gbc1);
        gbc1.gridx = 1; formPanel.add(passField, gbc1);

        gbc1.gridx = 0; gbc1.gridy = 2; formPanel.add(roleLabel, gbc1);
        gbc1.gridx = 1; formPanel.add(roleCombo, gbc1);

        gbc1.gridx = 0; gbc1.gridy = 3; formPanel.add(clearButton, gbc1);
        gbc1.gridx = 1; formPanel.add(loginButton, gbc1);

        gbc1.gridx = 0; gbc1.gridy = 4; gbc1.gridwidth = 2; gbc1.anchor = GridBagConstraints.CENTER;
        formPanel.add(registerLabel, gbc1);
        
        gbc1.gridx = 0; gbc1.gridy = -1; gbc1.gridwidth = 2; gbc1.anchor = GridBagConstraints.CENTER;
        formPanel.add(SetupLabel, gbc1);
        

        mainPanel.add(formPanel, BorderLayout.CENTER);
        add(mainPanel);

        // Button actions
        clearButton.addActionListener(e -> {
            userField.setText("");
            passField.setText("");
        });

     // Register label click → open Register window
     // Register Label action
        registerLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Open Register window
                SwingUtilities.invokeLater(() -> {
                    new Register().setVisible(true);  // make sure Register extends JFrame
                });
                dispose(); // close current window
            }
        });

        // Setup Label action
        SetupLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Open ConfigEditor window
                SwingUtilities.invokeLater(() -> {
                    new ConfigEditor().setVisible(true); // make sure ConfigEditor extends JFrame
                });
            }
        });
        roleCombo.addActionListener(e -> {
            String selected = (String) roleCombo.getSelectedItem();
            if ("Customer".equals(selected)) {
                registerLabel.setVisible(true);
            } else {
                registerLabel.setVisible(false);
            }

            formPanel.revalidate();
            formPanel.repaint();
        });
        




        loginButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());
            String role = roleCombo.getSelectedItem().toString();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter username/email/mobile and password!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (Connection con = DBConnection.getConnection()) {
                if (con == null) {
                    JOptionPane.showMessageDialog(this, "Database connection failed!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (role.equals("Customer")) {
                    String sql = "SELECT * FROM Members WHERE username=? AND password=?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, username);
                    ps.setString(2, password);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        int id = getMemberIdByUsername(username);
                        JOptionPane.showMessageDialog(this, "Login successful as Customer!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        SwingUtilities.invokeLater(() -> new Customer(Integer.toString(id)));
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this, "Invalid Username or Password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (role.equals("Organizer")) {
                    handleOTPLogin(con, username, password, "organizers");
                } else if (role.equals("Admin")) {
                    handleOTPLogin(con, username, password, "Admins");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setVisible(true);
    }

    private void handleOTPLogin(Connection con, String username, String password, String table) throws Exception {
        String sql = "SELECT * FROM " + table + " WHERE (Mobile=? OR email=?) AND password=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, username);
        ps.setString(3, password);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            String mobile = rs.getString("Mobile");
            String email = rs.getString("email");
            OTPCheck otpService = new OTPCheck();
            boolean otpSent = false;

            if (mobile != null && !mobile.isEmpty()) otpSent = otpService.sendOtpMobile("+91" + mobile);
            if (email != null && !email.isEmpty()) otpSent = otpService.sendOtpEmail(email);

            if (!otpSent) {
                JOptionPane.showMessageDialog(this, "Failed to send OTP. Login aborted!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!otpService.verifyOtpWithDialog()) {
                JOptionPane.showMessageDialog(this, "OTP verification failed. Login aborted!", "Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

            if (table.equals("organizers")) new Organizer(Integer.toString(rs.getInt("organizer_id")));
            else new Admin(username);

            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Mobile/Email or Password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static int getMemberIdByUsername(String username) {
        int memberId = -1;
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT member_id FROM members WHERE username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) memberId = rs.getInt("member_id");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return memberId;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(App::new);
    }
}
