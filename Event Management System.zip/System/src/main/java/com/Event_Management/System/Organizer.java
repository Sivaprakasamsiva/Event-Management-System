package com.Event_Management.System;



import Connectors.ConfigManager;
import Connectors.DBConnection;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import javax.swing.table.TableCellRenderer;
import java.awt.Component;

public class Organizer extends JFrame
{
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Organizer("1"));
    }
    private String organizerId;
    private Connection con;
    private JTable eventsTable;
    private DefaultTableModel eventsTableModel;
    private JPanel analyticsPanel;
    private JPanel analyticsGridPanel;
    private JLabel refreshLabel;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

    public Organizer(String organizerId) {
        super("Organizer Dashboard - Event Management System");
        this.organizerId = organizerId;

        // Initialize database connection
        con = getConnection();

        setupUI();
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel with logout button
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JTabbedPane tabs = new JTabbedPane();

        // Tab 1: My Events
        JPanel eventsPanel = new JPanel(new BorderLayout());
        eventsPanel.add(createEventsTablePanel(), BorderLayout.CENTER);
        eventsPanel.add(createEventActionsPanel(), BorderLayout.SOUTH);

        // Tab 2: Create Event
        JPanel createEventPanel = new JPanel(new GridBagLayout());
        createEventPanel.add(createEventForm());

        // Tab 3: Analytics
        analyticsPanel = new JPanel(new BorderLayout());
        analyticsGridPanel = new JPanel(new GridLayout(2, 2));
        analyticsGridPanel.add(createRevenueChart());
        analyticsGridPanel.add(createAttendanceChart());
        analyticsGridPanel.add(createTopEventsTable());
        analyticsGridPanel.add(createSummaryPanel());
        analyticsPanel.add(analyticsGridPanel, BorderLayout.CENTER);

        // Refresh label at bottom-right
        refreshLabel = new JLabel("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));
        refreshLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.add(refreshLabel);
        analyticsPanel.add(footer, BorderLayout.SOUTH);

        // Auto refresh every 30 sec
        new javax.swing.Timer(30000, e -> refreshAnalyticsTab()).start();

        // Tab 4: Profile
        JPanel profilePanel = new JPanel(new GridBagLayout());
        profilePanel.add(createProfilePanel());

        tabs.add("My Events", eventsPanel);
        tabs.add("Create Event", createEventPanel);
        tabs.add("Analytics", analyticsPanel);
        tabs.add("Profile", profilePanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);
        loadOrganizerEvents();
    }

    // NEW: Create header panel with logout button
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setPreferredSize(new Dimension(1000, 50));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Title label
        JLabel titleLabel = new JLabel("Organizer Dashboard - Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setBackground(new Color(220, 53, 69));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                SwingUtilities.invokeLater(() -> {
                    // You'll need to create an App class or replace with your main application class
                    // For now, we'll just show a message
                    JOptionPane.showMessageDialog(null, "Logged out successfully!");
                    SwingUtilities.invokeLater(App::new);
                    // If you have an App class, use: new App();
                });
            }
        });

        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutButton);
        headerPanel.add(logoutPanel, BorderLayout.EAST);

        return headerPanel;
    }

    //refresh method
    private void refreshAnalyticsTab() {
        // Remove old content from grid
        analyticsPanel.remove(analyticsGridPanel);

        // Recreate grid panel
        analyticsGridPanel = new JPanel(new GridLayout(2, 2));
        analyticsGridPanel.add(createRevenueChart());
        analyticsGridPanel.add(createAttendanceChart());
        analyticsGridPanel.add(createTopEventsTable());
        analyticsGridPanel.add(createSummaryPanel());

        analyticsPanel.add(analyticsGridPanel, BorderLayout.CENTER);

        // Update refresh label
        refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));

        analyticsPanel.revalidate();
        analyticsPanel.repaint();
    } 
    
    // ======create Event=================

    private JPanel createEventActionsPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.setBorder(BorderFactory.createTitledBorder("Event Actions"));

        JButton createButton = new JButton("Create New Event");
        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        Font btnFont = new Font("Segoe UI", Font.PLAIN, 13);
        JButton[] buttons = {createButton, editButton, deleteButton, refreshButton};
        for (JButton btn : buttons) {
            btn.setFont(btnFont);
            btn.setBackground(new Color(60, 120, 180));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        }

        createButton.addActionListener(e -> showCreateEventDialog());
        editButton.addActionListener(e -> editSelectedEvent());
        deleteButton.addActionListener(e -> deleteSelectedEvent());
        refreshButton.addActionListener(e -> loadOrganizerEvents());

        actionPanel.add(createButton);
        actionPanel.add(editButton);
        actionPanel.add(deleteButton);
        actionPanel.add(refreshButton);

        return actionPanel;
    }

    private JScrollPane createEventsTablePanel() {
        String[] columns = {"Event ID", "Title", "Date", "Venue", "Tickets Sold", "Revenue", "Status", "Actions"};
        eventsTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 7; // Only Actions column is editable
            }
        };
        eventsTable = new JTable(eventsTableModel);

        // Better row height
        eventsTable.setRowHeight(28);

        // Table header styling
        JTableHeader header = eventsTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(50, 90, 150));
        header.setForeground(Color.WHITE);

        // Alternate row colors
        eventsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                }
                return c;
            }
        });

        // Actions column with buttons
        eventsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        eventsTable.getColumn("Actions").setCellEditor(
            new OrganizerEventButtonEditor(new JCheckBox(), con, this, eventsTable)
        );

        JScrollPane scrollPane = new JScrollPane(eventsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Events Table"));
        return scrollPane;
    }

    private JPanel createEventForm() {
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Create Event"));

        JTextField titleField = new JTextField(25);
        JTextArea descriptionArea = new JTextArea(3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JTextField venueField = new JTextField(20);
        JTextField priceField = new JTextField(10);
        JTextField capacityField = new JTextField(10);

        JComboBox<String> categoryDropdown = new JComboBox<>(new String[]{
            "Music", "Sports", "Conference", "Workshop", "Exhibition", "Party", "Wedding"
        });

        JDateChooser dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");

        JTextField timeField = new JTextField(6);

        formPanel.add(new JLabel("Event Title:"));
        formPanel.add(titleField);
        formPanel.add(new JLabel("Description:"));
        formPanel.add(new JScrollPane(descriptionArea));
        formPanel.add(new JLabel("Venue:"));
        formPanel.add(venueField);
        formPanel.add(new JLabel("Price:"));
        formPanel.add(priceField);
        formPanel.add(new JLabel("Capacity:"));
        formPanel.add(capacityField);
        formPanel.add(new JLabel("Category:"));
        formPanel.add(categoryDropdown);
        formPanel.add(new JLabel("Event Date:"));
        formPanel.add(dateChooser);
        formPanel.add(new JLabel("Event Time (HH:MM):"));
        formPanel.add(timeField);

        JButton submitButton = new JButton("Create Event");
        submitButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        submitButton.setBackground(new Color(46, 139, 87));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));

        submitButton.addActionListener(e -> {
            if (dateChooser.getDate() == null || timeField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select date and enter time.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!timeField.getText().matches("([01]?[0-9]|2[0-3]):[0-5][0-9]")) {
                JOptionPane.showMessageDialog(this, "Please enter time in HH:MM format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String datePart = dateFormat.format(dateChooser.getDate());
            String dateTime = datePart + " " + timeField.getText() + ":00";

            createEvent(
                titleField.getText(),
                descriptionArea.getText(),
                venueField.getText(),
                Double.parseDouble(priceField.getText()),
                Integer.parseInt(capacityField.getText()),
                (String) categoryDropdown.getSelectedItem(),
                dateTime
            );

            // Clear form
            titleField.setText("");
            descriptionArea.setText("");
            venueField.setText("");
            priceField.setText("");
            capacityField.setText("");
            categoryDropdown.setSelectedIndex(0);
            dateChooser.setDate(null);
            timeField.setText("");
        });

        formPanel.add(new JLabel(""));
        formPanel.add(submitButton);

        return formPanel;
    }

    private void createEvent(String title, String description, String venue,
                            double price, int capacity, String category, String dateTime) {
        try {
            String sql = "INSERT INTO Events (title, description, venue, price, capacity, available_tickets, category, organizer_id, event_date) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, venue);
            ps.setDouble(4, price);
            ps.setInt(5, capacity);
            ps.setInt(6, capacity); // available_tickets starts equal to capacity
            ps.setString(7, category);
            ps.setInt(8, Integer.parseInt(organizerId)); // Convert to int
            ps.setString(9, dateTime);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Event created successfully!");
                loadOrganizerEvents();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating event: " + ex.getMessage());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid organizer ID format. Please contact administrator.");
        }
    }

    private JPanel createProfilePanel() {
        JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
        profilePanel.setBorder(BorderFactory.createTitledBorder("Organizer Profile"));

        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;

        try {
            String sql = "SELECT * FROM Organizers WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                 int[] row = {0};

                // Helper method to add rows cleanly
                java.util.function.BiConsumer<String, String> addRow = (label, value) -> {
                    gbc.gridx = 0;
                    gbc.gridy = row[0];
                    infoPanel.add(new JLabel(label + ":"), gbc);

                    gbc.gridx = 1;
                    JLabel valueLabel = new JLabel(value);
                    valueLabel.setFont(valueLabel.getFont().deriveFont(Font.BOLD));
                    infoPanel.add(valueLabel, gbc);

                    row[0]++;
                };

                addRow.accept("First Name", rs.getString("firstname"));
                addRow.accept("Last Name", rs.getString("lastname"));
                addRow.accept("Mobile", rs.getString("mobile"));
                addRow.accept("Email", rs.getString("email"));
                addRow.accept("Company", rs.getString("company_name"));
                addRow.accept("Address", rs.getString("address"));
                addRow.accept("Verified", rs.getBoolean("verified") ? "✅ Yes" : "❌ No");
                addRow.accept("Member Since", rs.getString("created_at"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Edit button at bottom
        JButton editProfileButton = new JButton("Edit Profile");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(editProfileButton);

        editProfileButton.addActionListener(e -> showEditProfileDialog());

        profilePanel.add(infoPanel, BorderLayout.CENTER);
        profilePanel.add(buttonPanel, BorderLayout.SOUTH);

        return profilePanel;
    }

    private void showEditProfileDialog() {
        JDialog editDialog = new JDialog(this, "Edit Profile", true);
        editDialog.setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField firstnameField = new JTextField(20);
        JTextField lastnameField = new JTextField(20);
        JTextField mobileField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField companyField = new JTextField(20);
        JTextArea addressArea = new JTextArea(3, 20);

        // Load existing profile
        try {
            String sql = "SELECT * FROM Organizers WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                firstnameField.setText(rs.getString("firstname"));
                lastnameField.setText(rs.getString("lastname"));
                mobileField.setText(rs.getString("mobile"));
                emailField.setText(rs.getString("email"));
                companyField.setText(rs.getString("company_name"));
                addressArea.setText(rs.getString("address"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Helper to add fields neatly
        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("First Name:"), gbc);
        gbc.gridx = 1; formPanel.add(firstnameField, gbc);

        row++; gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx = 1; formPanel.add(lastnameField, gbc);

        row++; gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Mobile:"), gbc);
        gbc.gridx = 1; formPanel.add(mobileField, gbc);

        row++; gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; formPanel.add(emailField, gbc);

        row++; gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Company:"), gbc);
        gbc.gridx = 1; formPanel.add(companyField, gbc);

        row++; gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1; formPanel.add(new JScrollPane(addressArea), gbc);

        // Save button
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE Organizers SET firstname=?, lastname=?, mobile=?, email=?, company_name=?, address=? WHERE organizer_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, firstnameField.getText());
                ps.setString(2, lastnameField.getText());
                ps.setString(3, mobileField.getText());
                ps.setString(4, emailField.getText());
                ps.setString(5, companyField.getText());
                ps.setString(6, addressArea.getText());
                ps.setInt(7, Integer.parseInt(organizerId));

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Profile updated successfully!");
                    editDialog.dispose();
                    removeAll();
                    setupUI();
                    revalidate();
                    repaint();
                }
            } catch (SQLException ex1) {
                ex1.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating profile: " + ex1.getMessage());
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);

        // Wrap form in scroll for better UI
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        editDialog.add(scrollPane, BorderLayout.CENTER);
        editDialog.add(buttonPanel, BorderLayout.SOUTH);

        editDialog.setSize(500, 400);  // Wider & taller for comfort
        editDialog.setLocationRelativeTo(this);
        editDialog.setVisible(true);
    }

    private void loadOrganizerEvents() {
        try {
            String sql = "SELECT * FROM Events WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();
            updateEventsTable(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading events: " + ex.getMessage());
        }
    }

    private void updateEventsTable(ResultSet rs) throws SQLException {
        eventsTableModel.setRowCount(0);
        while (rs.next()) {
            eventsTableModel.addRow(new Object[]{
                rs.getInt("event_id"),
                rs.getString("title"),
                rs.getString("event_date"),
                rs.getString("venue"),
                rs.getInt("tickets_sold"),
                rs.getDouble("revenue"),
                rs.getString("status"),
                "Edit/Delete"
            });
        }
    }

    private void showCreateEventDialog() {
        // This is now handled by the Create Event tab
        JOptionPane.showMessageDialog(this, "Use the 'Create Event' tab to add new events.");
    }

    private void editSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to edit.");
            return;
        }
        
        int eventId = (Integer) eventsTableModel.getValueAt(selectedRow, 0);
        showEventEditDialog(eventId);
    }
    
    void showEventEditDialog(int eventId) {
        JDialog editDialog = new JDialog(this, "Edit Event", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        JTextField titleField = new JTextField();
        JTextArea descriptionArea = new JTextArea(3, 20);
        JTextField venueField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField capacityField = new JTextField();
        JComboBox<String> categoryDropdown = new JComboBox<>(new String[]{
            "Music", "Sports", "Conference", "Workshop", "Exhibition", "Party", "Wedding"
        });
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Pending", "Approved", "Rejected", "Cancelled"});
        
        try {
            String sql = "SELECT * FROM Events WHERE event_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                titleField.setText(rs.getString("title"));
                descriptionArea.setText(rs.getString("description"));
                venueField.setText(rs.getString("venue"));
                priceField.setText(String.valueOf(rs.getDouble("price")));
                capacityField.setText(String.valueOf(rs.getInt("capacity")));
                categoryDropdown.setSelectedItem(rs.getString("category"));
                statusCombo.setSelectedItem(rs.getString("status"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("Title:"));
        editDialog.add(titleField);
        editDialog.add(new JLabel("Description:"));
        editDialog.add(new JScrollPane(descriptionArea));
        editDialog.add(new JLabel("Venue:"));
        editDialog.add(venueField);
        editDialog.add(new JLabel("Price:"));
        editDialog.add(priceField);
        editDialog.add(new JLabel("Capacity:"));
        editDialog.add(capacityField);
        editDialog.add(new JLabel("Category:"));
        editDialog.add(categoryDropdown);
        editDialog.add(new JLabel("Status:"));
        editDialog.add(statusCombo);
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE Events SET title=?, description=?, venue=?, price=?, capacity=?, category=?, status=? WHERE event_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, titleField.getText());
                ps.setString(2, descriptionArea.getText());
                ps.setString(3, venueField.getText());
                ps.setDouble(4, Double.parseDouble(priceField.getText()));
                ps.setInt(5, Integer.parseInt(capacityField.getText()));
                ps.setString(6, (String) categoryDropdown.getSelectedItem());
                ps.setString(7, (String) statusCombo.getSelectedItem());
                ps.setInt(8, eventId);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Event updated successfully!");
                    editDialog.dispose();
                    loadOrganizerEvents();
                }
            } catch (SQLException | NumberFormatException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating event: " + ex.getMessage());
            }
        });
        
        editDialog.add(new JLabel(""));
        editDialog.add(saveButton);
        
        editDialog.setSize(500, 400);
        editDialog.setLocationRelativeTo(this);
        editDialog.setVisible(true);
    }

    private void deleteSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to delete.");
            return;
        }
        
        int eventId = (Integer) eventsTableModel.getValueAt(selectedRow, 0);
        String eventTitle = (String) eventsTableModel.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete the event '" + eventTitle + "'?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // First check if there are any bookings for this event
                String checkSql = "SELECT COUNT(*) FROM Bookings WHERE event_id = ?";
                PreparedStatement checkPs = con.prepareStatement(checkSql);
                checkPs.setInt(1, eventId);
                ResultSet rs = checkPs.executeQuery();
                
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Cannot delete event with existing bookings. Please cancel the event instead.");
                    return;
                }
                
                String deleteSql = "DELETE FROM Events WHERE event_id = ?";
                PreparedStatement ps = con.prepareStatement(deleteSql);
                ps.setInt(1, eventId);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(this, "Event deleted successfully!");
                    loadOrganizerEvents();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting event: " + ex.getMessage());
            }
        }
    }

    // Implement analytics methods
    private JPanel createRevenueChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(100, 150, 200), 2, true),
            "Revenue Chart",
            javax.swing.border.TitledBorder.CENTER,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(50, 50, 50)
        ));
        
        DefaultTableModel model = new DefaultTableModel(new String[]{"Event", "Revenue"}, 0);
        JTable table = new JTable(model);

        // Improve table look
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(new Color(100, 150, 200));
        table.setSelectionForeground(Color.WHITE);

        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(60, 120, 180));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        // Alternate row colors for better readability
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                }
                return c;
            }
        });

        try {
            String sql = "SELECT title, revenue FROM Events WHERE organizer_id = ? ORDER BY revenue DESC LIMIT 10";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    rs.getDouble("revenue")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // clean look
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createAttendanceChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(100, 180, 120), 2, true),
            "Attendance Chart",
            javax.swing.border.TitledBorder.CENTER,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(40, 80, 40)
        ));

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Event", "Tickets Sold", "Capacity"}, 0
        );
        JTable table = new JTable(model);

        // Improve table appearance
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(new Color(80, 150, 100));
        table.setSelectionForeground(Color.WHITE);

        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(60, 140, 100));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        // Alternate row coloring
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(240, 250, 240) : Color.WHITE);
                }
                return c;
            }
        });

        try {
            String sql = "SELECT title, tickets_sold, capacity FROM Events WHERE organizer_id = ? ORDER BY tickets_sold DESC LIMIT 10";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    rs.getInt("tickets_sold"),
                    rs.getInt("capacity")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // cleaner look
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createTopEventsTable() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(180, 120, 60), 2, true),
            "Top Events",
            javax.swing.border.TitledBorder.CENTER,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(120, 70, 20)
        ));

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Event", "Rating", "Bookings"}, 0
        );
        JTable table = new JTable(model);

        // Table styling
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(new Color(200, 140, 90));
        table.setSelectionForeground(Color.WHITE);

        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(160, 100, 50));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        // Alternate row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                          boolean isSelected, boolean hasFocus,
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(255, 245, 230) : Color.WHITE);
                }
                return c;
            }
        });

        // Query to fetch events
        try {
            String sql = "SELECT title, tickets_sold FROM Events WHERE organizer_id = ? ORDER BY tickets_sold DESC LIMIT 5";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(organizerId));
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("title"),
                    "N/A", // Placeholder for rating
                    rs.getInt("tickets_sold")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // clean look
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2));
        
        try {
            String[] queries = {
                "SELECT COUNT(*) FROM Events WHERE organizer_id = " + organizerId,
                "SELECT SUM(tickets_sold) FROM Events WHERE organizer_id = " + organizerId,
                "SELECT SUM(revenue) FROM Events WHERE organizer_id = " + organizerId,
                "SELECT AVG(tickets_sold) FROM Events WHERE organizer_id = " + organizerId
            };
            
            String[] labels = {"Total Events", "Total Tickets Sold", "Total Revenue", "Avg. Attendance"};
            
            for (int i = 0; i < queries.length; i++) {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(queries[i]);
                if (rs.next()) {
                    JPanel statPanel = new JPanel(new BorderLayout());
                    statPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                    
                    JLabel title = new JLabel(labels[i], JLabel.CENTER);
                    JLabel value = new JLabel(rs.getString(1), JLabel.CENTER);
                    value.setFont(new Font("Arial", Font.BOLD, 16));
                    
                    statPanel.add(title, BorderLayout.NORTH);
                    statPanel.add(value, BorderLayout.CENTER);
                    panel.add(statPanel);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return panel;
    }

    // Database connection
    private Connection getConnection() {
        try {
        	ConfigManager cfg = new ConfigManager();
        	String url = cfg.get("DB_URL");
            String user = cfg.get("DB_USER");
            String password = cfg.get("DB_PASS");
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage());
            return null;
        }
    }

    
}

class OrganizerEventButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Organizer organizer;
    private JTable table;

    public OrganizerEventButtonEditor(JCheckBox checkBox, Connection con, Organizer organizer, JTable table) {
        super(checkBox);
        this.con = con;
        this.organizer = organizer;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int eventId = (Integer) table.getModel().getValueAt(row, 0);
            String action = (String) table.getModel().getValueAt(row, 7);
            
            if ("Edit/Delete".equals(action)) {
                organizer.showEventEditDialog(eventId);
            }
        }
        isPushed = false;
        return label;
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

class ButtonRenderer extends JButton implements TableCellRenderer {

    public ButtonRenderer() {
        setOpaque(true); // ensures button background is visible
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        setText((value == null) ? "Edit" : value.toString());

        // Optional: customize appearance based on selection
        if (isSelected) {
            setForeground(table.getSelectionForeground());
            setBackground(table.getSelectionBackground());
        } else {
            setForeground(table.getForeground());
            setBackground(table.getBackground());
        }

        return this;
    }
    
}