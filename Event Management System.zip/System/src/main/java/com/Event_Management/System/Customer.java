package com.Event_Management.System;


import Connectors.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Customer extends JFrame {
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Customer("1"));
    }
    private String customerId;
    private Connection con;
    private JTable eventsTable;
    private JTable bookingsTable;
    

    public Customer(String customerId) {
        super("Customer Dashboard - Event Management System");
        this.customerId = customerId;
        try {
            con = DBConnection.getConnection();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection failed!");
        }

        setupUI();
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel with logout button
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JTabbedPane tabs = new JTabbedPane();

        // Tab 1: Browse Events
        JPanel browsePanel = new JPanel(new BorderLayout());
        browsePanel.add(createSearchPanel(), BorderLayout.NORTH);
        browsePanel.add(createEventsTable(), BorderLayout.CENTER);

        // Tab 2: My Bookings
        JPanel bookingsPanel = new JPanel(new BorderLayout());
        bookingsPanel.add(createBookingsTable(), BorderLayout.CENTER);

        // Tab 3: Profile
        JPanel profilePanel = new JPanel(new BorderLayout());
        profilePanel.add(createProfilePanel(), BorderLayout.CENTER);

        tabs.add("Browse Events", browsePanel);
        tabs.add("My Bookings", bookingsPanel);
        tabs.add("My Profile", profilePanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);

        loadAvailableEvents();
        loadUserBookings();
    }

    // NEW: Create header panel with logout button
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel blue color
        headerPanel.setPreferredSize(new Dimension(900, 50));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Title label
        JLabel titleLabel = new JLabel("Customer Dashboard - Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setBackground(new Color(220, 53, 69)); // Red color
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                SwingUtilities.invokeLater(() -> {
                    // You'll need to create an App class or replace with your main application class
                    // For now, we'll just show a message
                    JOptionPane.showMessageDialog(null, "Logged out successfully!");
                    SwingUtilities.invokeLater(App::new);
                    // If you have an App class, use: new App();
                });
            }
        });

        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutButton);
        headerPanel.add(logoutPanel, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout());
        JTextField searchField = new JTextField(20);
        JComboBox<String> categoryFilter = new JComboBox<>(new String[]{"All Categories", "Music", "Sports", "Conference", "Workshop"});
        JComboBox<String> priceFilter = new JComboBox<>(new String[]{"Any Price", "Free", "Under ₹500", "₹500 - ₹1000", "₹1000 - ₹2000", "Over ₹2000"});
        JComboBox<String> dateFilter = new JComboBox<>(new String[]{"Any Date", "Today", "Tomorrow", "This Week", "Next Week", "This Month"});
        JButton searchButton = new JButton("Search");

        searchButton.addActionListener(e -> searchEvents(
            searchField.getText(),
            categoryFilter.getSelectedItem().toString(),
            priceFilter.getSelectedItem().toString(),
            dateFilter.getSelectedItem().toString()
        ));

        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(new JLabel("Category:"));
        searchPanel.add(categoryFilter);
        searchPanel.add(new JLabel("Price:"));
        searchPanel.add(priceFilter);
        searchPanel.add(new JLabel("Date:"));
        searchPanel.add(dateFilter);
        searchPanel.add(searchButton);

        return searchPanel;
    }

    private void searchEvents(String query, String category, String price, String date) {
        try {
            String sql = "SELECT * FROM Events WHERE title LIKE ? AND (category = ? OR ? = 'All Categories') AND event_date >= CURDATE()";
            if (!price.equals("Any Price")) {
                switch (price) {
                    case "Free":
                        sql += " AND price = 0";
                        break;
                    case "Under ₹500":
                        sql += " AND price < 500";
                        break;
                    case "₹500 - ₹1000":
                        sql += " AND price BETWEEN 500 AND 1000";
                        break;
                    case "₹1000 - ₹2000":
                        sql += " AND price BETWEEN 1000 AND 2000";
                        break;
                    case "Over ₹2000":
                        sql += " AND price > 2000";
                        break;
                }
            }

            if (!date.equals("Any Date")) {
                switch (date) {
                    case "Today":
                        sql += " AND DATE(event_date) = CURDATE()";
                        break;
                    case "Tomorrow":
                        sql += " AND DATE(event_date) = CURDATE() + INTERVAL 1 DAY";
                        break;
                    case "This Week":
                        sql += " AND YEARWEEK(event_date) = YEARWEEK(CURDATE())";
                        break;
                    case "Next Week":
                        sql += " AND YEARWEEK(event_date) = YEARWEEK(CURDATE()) + 1";
                        break;
                    case "This Month":
                        sql += " AND MONTH(event_date) = MONTH(CURDATE()) AND YEAR(event_date) = YEAR(CURDATE())";
                        break;
                }
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + query + "%");
            ps.setString(2, category);
            ps.setString(3, category);
            ResultSet rs = ps.executeQuery();
            updateEventsTable(rs);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error searching events: " + ex.getMessage());
        }
    }

    private JScrollPane createEventsTable() {
        String[] columns = {"Event ID", "Title", "Date", "Venue", "Price", "Available Tickets", "Actions"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Only Actions column is editable
            }
        };
        eventsTable = new JTable(model);
        eventsTable.setRowHeight(25);
        eventsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Add button renderer and editor for Actions column
        eventsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        eventsTable.getColumn("Actions").setCellEditor(new CustomerEventButtonEditor(new JCheckBox(), con, this, eventsTable));
        
        return new JScrollPane(eventsTable);
    }

    private JScrollPane createBookingsTable() {
        String[] columns = {"Booking ID", "Event", "Date", "Tickets", "Amount", "Status", "Actions"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Only Actions column is editable
            }
        };
        
        bookingsTable = new JTable(model) {
            // Override prepareRenderer to color status cells
            public Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                if (column == 5) { // Status column
                    String status = (String) getModel().getValueAt(row, column);
                    if ("Confirmed".equalsIgnoreCase(status)) {
                        c.setBackground(new Color(144, 238, 144)); // Light green
                        c.setForeground(Color.BLACK);
                    } else if ("Cancelled".equalsIgnoreCase(status) || "Rejected".equalsIgnoreCase(status)) {
                        c.setBackground(new Color(255, 99, 71)); // Light red
                        c.setForeground(Color.WHITE);
                    } else {
                        c.setBackground(Color.WHITE);
                        c.setForeground(Color.BLACK);
                    }
                } else {
                    c.setBackground(Color.WHITE);
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        };

        bookingsTable.setRowHeight(25);
        bookingsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Add button renderer and editor for Actions column
        bookingsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        bookingsTable.getColumn("Actions").setCellEditor(new CustomerBookingButtonEditor(new JCheckBox(), con, this, bookingsTable));

        return new JScrollPane(bookingsTable);
    }

    private JPanel createProfilePanel() {
        JPanel profilePanel = new JPanel();
        profilePanel.setLayout(new GridBagLayout());
        profilePanel.setBackground(new Color(245, 245, 245)); // light gray background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // spacing between components
        gbc.anchor = GridBagConstraints.WEST;
        
        try {
            String sql = "SELECT * FROM Members WHERE member_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(customerId));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int row = 0;
                
                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("First Name:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("firstname")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Last Name:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("lastname")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Username:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("username")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Email:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("email")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Mobile:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("mobile")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Date of Birth:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getDate("dob").toString()), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Gender:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("gender")), gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Address:"), gbc);
                gbc.gridx = 1;
                JTextArea addressArea = new JTextArea(rs.getString("address"));
                addressArea.setLineWrap(true);
                addressArea.setWrapStyleWord(true);
                addressArea.setEditable(false);
                addressArea.setBackground(new Color(230, 230, 250)); // light lavender
                addressArea.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
                profilePanel.add(addressArea, gbc);
                row++;

                gbc.gridx = 0;
                gbc.gridy = row;
                profilePanel.add(new JLabel("Member Since:"), gbc);
                gbc.gridx = 1;
                profilePanel.add(new JLabel(rs.getString("created_at")), gbc);
                row++;

                // Edit Button
                gbc.gridx = 0;
                gbc.gridy = row;
                gbc.gridwidth = 2;
                gbc.anchor = GridBagConstraints.CENTER;
                JButton editProfileButton = new JButton("Edit Profile");
                editProfileButton.setBackground(new Color(70, 130, 180)); // steel blue
                editProfileButton.setForeground(Color.WHITE);
                editProfileButton.setFocusPainted(false);
                editProfileButton.setPreferredSize(new Dimension(150, 40)); // bigger button
                editProfileButton.addActionListener(e -> showEditProfileDialog());
                profilePanel.add(editProfileButton, gbc);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return profilePanel;
    }

    private void showEditProfileDialog() {
        JDialog editDialog = new JDialog(this, "Edit Profile", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        JTextField firstnameField = new JTextField();
        JTextField lastnameField = new JTextField();
        JTextField usernameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField mobileField = new JTextField();
        JTextArea addressArea = new JTextArea(3, 20);
        JComboBox<String> genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        
        try {
            String sql = "SELECT * FROM Members WHERE member_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(customerId));
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                firstnameField.setText(rs.getString("firstname"));
                lastnameField.setText(rs.getString("lastname"));
                usernameField.setText(rs.getString("username"));
                emailField.setText(rs.getString("email"));
                mobileField.setText(rs.getString("mobile"));
                addressArea.setText(rs.getString("address"));
                genderCombo.setSelectedItem(rs.getString("gender"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("First Name:"));
        editDialog.add(firstnameField);
        editDialog.add(new JLabel("Last Name:"));
        editDialog.add(lastnameField);
        editDialog.add(new JLabel("Username:"));
        editDialog.add(usernameField);
        editDialog.add(new JLabel("Email:"));
        editDialog.add(emailField);
        editDialog.add(new JLabel("Mobile:"));
        editDialog.add(mobileField);
        editDialog.add(new JLabel("Address:"));
        editDialog.add(new JScrollPane(addressArea));
        editDialog.add(new JLabel("Gender:"));
        editDialog.add(genderCombo);
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE Members SET firstname=?, lastname=?, username=?, email=?, mobile=?, address=?, gender=? WHERE member_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, firstnameField.getText());
                ps.setString(2, lastnameField.getText());
                ps.setString(3, usernameField.getText());
                ps.setString(4, emailField.getText());
                ps.setString(5, mobileField.getText());
                ps.setString(6, addressArea.getText());
                ps.setString(7, (String) genderCombo.getSelectedItem());
                ps.setInt(8, Integer.parseInt(customerId));
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Profile updated successfully!");
                    editDialog.dispose();
                    // Refresh profile panel
                    removeAll();
                    setupUI();
                    revalidate();
                    repaint();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating profile: " + ex.getMessage());
            }
        });
        
        editDialog.add(new JLabel(""));
        editDialog.add(saveButton);
        
        editDialog.setSize(500, 400);
        editDialog.setLocationRelativeTo(this);
        editDialog.setVisible(true);
    }

    private void loadAvailableEvents() {
        try {
            String sql = "SELECT * FROM Events WHERE event_date >= CURDATE() AND available_tickets > 0 AND status = 'Approved'";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            updateEventsTable(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadUserBookings() {
        try {
            String sql = "SELECT b.booking_id, e.title, e.event_date, b.ticket_count, b.total_amount, b.status " +
                    "FROM Bookings b JOIN Events e ON b.event_id = e.event_id " +
                    "WHERE b.user_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(customerId));
            ResultSet rs = ps.executeQuery();
            updateBookingsTable(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateEventsTable(ResultSet rs) throws SQLException {
        DefaultTableModel model = (DefaultTableModel) eventsTable.getModel();
        model.setRowCount(0);
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("event_id"),
                rs.getString("title"),
                rs.getDate("event_date"),
                rs.getString("venue"),
                rs.getDouble("price"),
                rs.getInt("available_tickets"),
                "View/Book"
            });
        }
    }

    private void updateBookingsTable(ResultSet rs) throws SQLException {
        DefaultTableModel model = (DefaultTableModel) bookingsTable.getModel();
        model.setRowCount(0);
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("booking_id"),
                rs.getString("title"),
                rs.getDate("event_date"),
                rs.getInt("ticket_count"),
                rs.getDouble("total_amount"),
                rs.getString("status"),
                "Cancel"
            });
        }
    }
    
    void bookEvent(int eventId) {
        try {
            // Get event details
            String eventSql = "SELECT * FROM Events WHERE event_id = ?";
            PreparedStatement eventPs = con.prepareStatement(eventSql);
            eventPs.setInt(1, eventId);
            ResultSet eventRs = eventPs.executeQuery();
            
            if (eventRs.next()) {
                String eventTitle = eventRs.getString("title");
                double eventPrice = eventRs.getDouble("price");
                int availableTickets = eventRs.getInt("available_tickets");
                
                // Ask for number of tickets
                String ticketCountStr = JOptionPane.showInputDialog(this, 
                    "How many tickets for '" + eventTitle + "'? (Available: " + availableTickets + ")");
                
                if (ticketCountStr != null && !ticketCountStr.isEmpty()) {
                    int ticketCount = Integer.parseInt(ticketCountStr);
                    
                    if (ticketCount <= 0) {
                        JOptionPane.showMessageDialog(this, "Please enter a valid number of tickets.");
                        return;
                    }
                    
                    if (ticketCount > availableTickets) {
                        JOptionPane.showMessageDialog(this, "Not enough tickets available. Only " + availableTickets + " left.");
                        return;
                    }
                    
                    double totalAmount = eventPrice * ticketCount;
                    
                    // Confirm booking
                    int confirm = JOptionPane.showConfirmDialog(this, 
                        "Confirm booking:\nEvent: " + eventTitle + 
                        "\nTickets: " + ticketCount + 
                        "\nTotal: ₹" + totalAmount,
                        "Confirm Booking", JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        // Create booking
                        String bookingSql = "INSERT INTO Bookings (event_id, user_id, ticket_count, total_amount, status) VALUES (?, ?, ?, ?, 'Confirmed')";
                        PreparedStatement bookingPs = con.prepareStatement(bookingSql);
                        bookingPs.setInt(1, eventId);
                        bookingPs.setInt(2, Integer.parseInt(customerId));
                        bookingPs.setInt(3, ticketCount);
                        bookingPs.setDouble(4, totalAmount);
                        
                        if (bookingPs.executeUpdate() > 0) {
                            // Update available tickets
                            String updateSql = "UPDATE Events SET available_tickets = available_tickets - ?, tickets_sold = tickets_sold + ?, revenue = revenue + ? WHERE event_id = ?";
                            PreparedStatement updatePs = con.prepareStatement(updateSql);
                            updatePs.setInt(1, ticketCount);
                            updatePs.setInt(2, ticketCount);
                            updatePs.setDouble(3, totalAmount);
                            updatePs.setInt(4, eventId);
                            updatePs.executeUpdate();
                            
                            // Create payment record
                            String paymentSql = "INSERT INTO Payments (booking_id, amount, total_amount, payment_method, payment_status) VALUES (LAST_INSERT_ID(), ?, ?, 'Online', 'Success')";
                            PreparedStatement paymentPs = con.prepareStatement(paymentSql);
                            paymentPs.setDouble(1, totalAmount);
                            paymentPs.setDouble(2, totalAmount);
                            paymentPs.executeUpdate();
                            
                            JOptionPane.showMessageDialog(this, "Booking confirmed successfully!");
                            loadAvailableEvents();
                            loadUserBookings();
                        }
                    }
                }
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error booking event: " + ex.getMessage());
        }
    }
    
    void cancelBooking(int bookingId) {
        try {
            // Get booking details
            String bookingSql = "SELECT b.*, e.title FROM Bookings b JOIN Events e ON b.event_id = e.event_id WHERE b.booking_id = ?";
            PreparedStatement bookingPs = con.prepareStatement(bookingSql);
            bookingPs.setInt(1, bookingId);
            ResultSet bookingRs = bookingPs.executeQuery();
            
            if (bookingRs.next()) {
                String eventTitle = bookingRs.getString("title");
                int ticketCount = bookingRs.getInt("ticket_count");
                int eventId = bookingRs.getInt("event_id");
                String status = bookingRs.getString("status");
                
                if ("Cancelled".equals(status) || "Refunded".equals(status)) {
                    JOptionPane.showMessageDialog(this, "This booking is already cancelled.");
                    return;
                }
                
                // Confirm cancellation
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Are you sure you want to cancel your booking for '" + eventTitle + "'?",
                    "Confirm Cancellation", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    // Update booking status
                    String updateSql = "UPDATE Bookings SET status = 'Cancelled' WHERE booking_id = ?";
                    PreparedStatement updatePs = con.prepareStatement(updateSql);
                    updatePs.setInt(1, bookingId);
                    
                    if (updatePs.executeUpdate() > 0) {
                        // Update available tickets
                        String eventSql = "UPDATE Events SET available_tickets = available_tickets + ?, tickets_sold = tickets_sold - ?, revenue = revenue - ? WHERE event_id = ?";
                        PreparedStatement eventPs = con.prepareStatement(eventSql);
                        eventPs.setInt(1, ticketCount);
                        eventPs.setInt(2, ticketCount);
                        eventPs.setDouble(3, bookingRs.getDouble("total_amount"));
                        eventPs.setInt(4, eventId);
                        eventPs.executeUpdate();
                        
                        JOptionPane.showMessageDialog(this, "Booking cancelled successfully!");
                        loadUserBookings();
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error cancelling booking: " + ex.getMessage());
        }
    }

    
}

class CustomerEventButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Customer customer;
    private JTable table;

    public CustomerEventButtonEditor(JCheckBox checkBox, Connection con, Customer customer, JTable table) {
        super(checkBox);
        this.con = con;
        this.customer = customer;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "View/Book" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int eventId = (Integer) table.getModel().getValueAt(row, 0);
            String action = (String) table.getModel().getValueAt(row, 6);
            
            if ("View/Book".equals(action)) {
                customer.bookEvent(eventId);
            }
        }
        isPushed = false;
        return label;
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

class CustomerBookingButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Customer customer;
    private JTable table;

    public CustomerBookingButtonEditor(JCheckBox checkBox, Connection con, Customer customer, JTable table) {
        super(checkBox);
        this.con = con;
        this.customer = customer;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Cancel" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int bookingId = (Integer) table.getModel().getValueAt(row, 0);
            String action = (String) table.getModel().getValueAt(row, 6);
            
            if ("Cancel".equals(action)) {
                customer.cancelBooking(bookingId);
            }
        }
        isPushed = false;
        return label;
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

// Button Renderer class
class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
    }

    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "" : value.toString());
        
        if (isSelected) {
            setForeground(table.getSelectionForeground());
            setBackground(table.getSelectionBackground());
        } else {
            setForeground(table.getForeground());
            setBackground(UIManager.getColor("Button.background"));
        }
        
        return this;
    }
}