package com.Event_Management.System;


import Connectors.DBConnection;
import Connectors.OTPCheck;


import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Register extends JFrame {
    private JTextField T1, T2, T3, T6, T7;
    private JPasswordField T4, T5;
    private JTextArea TA1;
    private JDateChooser DOB;
    private ButtonGroup genderGroup;
    private JRadioButton RB1, RB2, RB3;

    public Register() {
        super("Register - Event Management System");
        setupUI();
        setSize(500, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setupUI() {
        // Main panel with padding
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);

        // Header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = createFormPanel();
        mainPanel.add(new JScrollPane(formPanel), BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = createButtonPanel();
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(65, 105, 225));
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titleLabel = new JLabel("User Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Initialize components with modern styling
        initializeComponents();

        int row = 0;

        // Personal Information Section
        addSectionLabel("Personal Information", formPanel, gbc, row++);

        // First Name
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("First Name *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T1), gbc);
        row++;

        // Last Name
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Last Name *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T2), gbc);
        row++;

        // Mobile Number
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Mobile Number:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T6), gbc);
        row++;

        // Email
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Email:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T7), gbc);
        row++;

        // Account Information Section
        addSectionLabel("Account Information", formPanel, gbc, row++);

        // Username
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Username *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledTextField(T3), gbc);
        row++;

        // Password
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Password *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledPasswordField(T4), gbc);
        row++;

        // Confirm Password
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Confirm Password *:"), gbc);
        gbc.gridx = 1;
        formPanel.add(createStyledPasswordField(T5), gbc);
        row++;

        // Additional Information Section
        addSectionLabel("Additional Information", formPanel, gbc, row++);

        // Date of Birth
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Date of Birth:"), gbc);
        gbc.gridx = 1;
        DOB.setPreferredSize(new Dimension(200, 30));
        DOB.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(DOB, gbc);
        row++;

        // Gender
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Gender:"), gbc);
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.setBackground(Color.WHITE);
        genderPanel.add(RB1);
        genderPanel.add(RB2);
        genderPanel.add(RB3);
        formPanel.add(genderPanel, gbc);
        row++;

        // Address
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(createStyledLabel("Address:"), gbc);
        gbc.gridx = 1;
        JScrollPane addressScroll = new JScrollPane(TA1);
        addressScroll.setPreferredSize(new Dimension(200, 80));
        formPanel.add(addressScroll, gbc);
        row++;

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton B1 = createStyledButton("Create Account", new Color(40, 167, 69));
        JButton B2 = createStyledButton("Clear Form", new Color(108, 117, 125));

        B1.addActionListener(e -> createAccount());
        B2.addActionListener(e -> clearForm());

        buttonPanel.add(B1);
        buttonPanel.add(B2);

        return buttonPanel;
    }

    private void initializeComponents() {
        // Text fields
        T1 = new JTextField(20);
        T2 = new JTextField(20);
        T3 = new JTextField(20);
        T6 = new JTextField(20);
        T7 = new JTextField(20);

        // Password fields
        T4 = new JPasswordField(20);
        T5 = new JPasswordField(20);

        // Text area
        TA1 = new JTextArea(3, 20);
        TA1.setLineWrap(true);
        TA1.setWrapStyleWord(true);

        // Date chooser
        DOB = new JDateChooser();
        DOB.setDateFormatString("yyyy-MM-dd");

        // Gender radio buttons
        genderGroup = new ButtonGroup();
        RB1 = createStyledRadioButton("Male");
        RB2 = createStyledRadioButton("Female");
        RB3 = createStyledRadioButton("Other");

        genderGroup.add(RB1);
        genderGroup.add(RB2);
        genderGroup.add(RB3);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(51, 51, 51));
        return label;
    }

    private JTextField createStyledTextField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(200, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JPasswordField createStyledPasswordField(JPasswordField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(200, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JRadioButton createStyledRadioButton(String text) {
        JRadioButton radio = new JRadioButton(text);
        radio.setFont(new Font("Arial", Font.PLAIN, 14));
        radio.setBackground(Color.WHITE);
        return radio;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void addSectionLabel(String text, JPanel panel, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 8, 10, 8);
        
        JLabel sectionLabel = new JLabel(text);
        sectionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        sectionLabel.setForeground(new Color(65, 105, 225));
        sectionLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(65, 105, 225)));
        
        panel.add(sectionLabel, gbc);
        
        gbc.gridwidth = 1;
        gbc.insets = new Insets(8, 8, 8, 8);
    }

    private void createAccount() {
        String fname = T1.getText().trim();
        String lname = T2.getText().trim();
        String mobile = T6.getText().trim();
        String email = T7.getText().trim();
        String uname = T3.getText().trim();
        Date dob = DOB.getDate();
        String gender = getSelectedGender();
        String pass = new String(T4.getPassword());
        String cpass = new String(T5.getPassword());
        String address = TA1.getText().trim();

        // Validation
        if (!validateInput(fname, lname, uname, pass, cpass, mobile, email)) {
            return;
        }

        // OTP Handling
        OTPCheck otpService = new OTPCheck();
        boolean otpSent = false;

        if (!mobile.isEmpty() && mobile.matches("\\d{10}")) {
            otpSent = otpService.sendOtpMobile("+91" + mobile);
        }

        if (!email.isEmpty() && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            boolean emailSent = otpService.sendOtpEmail(email);
            otpSent = otpSent || emailSent;
        }

        if (!otpSent) {
            JOptionPane.showMessageDialog(this,
                "Failed to send OTP to both mobile and email. Registration aborted!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean verified = otpService.verifyOtpWithDialog();
        if (!verified) {
            JOptionPane.showMessageDialog(this,
                "OTP verification failed. Registration aborted!",
                "Failed",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert into Database
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO Members(firstname, lastname, username, dob, gender, password, address, mobile, email) VALUES(?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, uname);
            ps.setDate(4, dob != null ? new java.sql.Date(dob.getTime()) : null);
            ps.setString(5, gender);
            ps.setString(6, pass);
            ps.setString(7, address);
            ps.setString(8, mobile);
            ps.setString(9, email);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, 
                "✅ Member registered successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            new App();
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Database error! " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validateInput(String fname, String lname, String uname, String pass, 
                                 String cpass, String mobile, String email) {
        if (fname.isEmpty() || lname.isEmpty() || uname.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please fill in all required fields!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!pass.equals(cpass)) {
            JOptionPane.showMessageDialog(this, 
                "Passwords do not match!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!pass.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$")) {
            JOptionPane.showMessageDialog(this,
                "Password must be at least 8 characters and include uppercase, lowercase, and number.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        boolean validMobile = mobile.isEmpty() || mobile.matches("\\d{10}");
        boolean validEmail = email.isEmpty() || email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        if ((!mobile.isEmpty() && !validMobile) || (!email.isEmpty() && !validEmail)) {
            JOptionPane.showMessageDialog(this,
                "Please enter valid mobile number (10 digits) or email address.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (mobile.isEmpty() && email.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please provide either mobile number or email address.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private String getSelectedGender() {
        if (RB1.isSelected()) return "Male";
        if (RB2.isSelected()) return "Female";
        if (RB3.isSelected()) return "Other";
        return null;
    }

    private void clearForm() {
        T1.setText("");
        T2.setText("");
        T3.setText("");
        T4.setText("");
        T5.setText("");
        T6.setText("");
        T7.setText("");
        TA1.setText("");
        genderGroup.clearSelection();
        DOB.setDate(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Register());
    }
}