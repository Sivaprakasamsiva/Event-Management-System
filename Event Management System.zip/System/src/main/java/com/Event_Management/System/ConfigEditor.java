package com.Event_Management.System;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import Connectors.ConfigManager;

public class ConfigEditor extends JFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ConfigEditor::new);
    }
    
    private ConfigManager config;
    private JTextField dbUrlField, dbUserField, dbPassField;
    private JTextField sidField, tokenField, twilioField;
    private JTextField emailUserField, emailPassField, emailHostField;

    public ConfigEditor() {
        super("Configuration Settings");
        config = new ConfigManager();
        
        initializeUI();
        setupWindow();
        setVisible(true);
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(550, 500);
        setLocationRelativeTo(null);
        
        // Main panel with styling
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("Configuration Settings", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form panel with tabs for better organization
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Database", createDatabasePanel());
        tabbedPane.addTab("Twilio", createTwilioPanel());
        tabbedPane.addTab("Email", createEmailPanel());
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createDatabasePanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        dbUrlField = createTextField(config.get("DB_URL"));
        dbUserField = createTextField(config.get("DB_USER"));
        dbPassField = createTextField(config.get("DB_PASS"));
        

        addLabelAndField(panel, gbc, "Database URL:", dbUrlField, 0);
        addLabelAndField(panel, gbc, "Database User:", dbUserField, 1);
        addLabelAndField(panel, gbc, "Database Password:", dbPassField, 2);

        return panel;
    }

    private JPanel createTwilioPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        sidField = createTextField(config.get("ACCOUNT_SID"));
        tokenField = createTextField(config.get("AUTH_TOKEN"));
        
        twilioField = createTextField(config.get("TWILIO_NUMBER"));

        addLabelAndField(panel, gbc, "Twilio Account SID:", sidField, 0);
        addLabelAndField(panel, gbc, "Twilio Auth Token:", tokenField, 1);
        addLabelAndField(panel, gbc, "Twilio Phone Number:", twilioField, 2);

        return panel;
    }

    private JPanel createEmailPanel() {
        JPanel panel = createStyledPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = createGBC();

        emailUserField = createTextField(config.get("EMAIL_USER"));
        emailPassField = createTextField(config.get("EMAIL_APP_PASSWORD"));
       
        emailHostField = createTextField(config.get("EMAIL_HOST"));

        addLabelAndField(panel, gbc, "Email Username:", emailUserField, 0);
        addLabelAndField(panel, gbc, "Email App Password:", emailPassField, 1);
        addLabelAndField(panel, gbc, "Email Host:", emailHostField, 2);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(245, 245, 245));

        JButton saveBtn = createStyledButton("Save", new Color(70, 130, 180));
        JButton cancelBtn = createStyledButton("Cancel", new Color(120, 120, 120));
        JButton testBtn = createStyledButton("Test Connections", new Color(60, 179, 113));

        saveBtn.addActionListener(e -> saveConfig());
        cancelBtn.addActionListener(e -> dispose());
        testBtn.addActionListener(e -> testConnections());

        buttonPanel.add(testBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        return buttonPanel;
    }

    private void addLabelAndField(JPanel panel, GridBagConstraints gbc, String labelText, JTextField field, int gridy) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 0;
        gbc.gridy = gridy;
        gbc.anchor = GridBagConstraints.LINE_END;
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(field, gbc);
    }

    private JPanel createStyledPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        return panel;
    }

    private GridBagConstraints createGBC() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        return gbc;
    }

    private JTextField createTextField(String text) {
        JTextField field = new JTextField(text, 20);
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(250, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(140, 35));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }

    private void setupWindow() {
        // Add window listener for confirmation on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (hasUnsavedChanges()) {
                    int result = JOptionPane.showConfirmDialog(
                        ConfigEditor.this,
                        "You have unsaved changes. Are you sure you want to close?",
                        "Unsaved Changes",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    if (result == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                dispose();
            }
        });
    }

    private boolean hasUnsavedChanges() {
        // Check if any field has been modified from original config values
        return !dbUrlField.getText().equals(config.get("DB_URL")) ||
               !dbUserField.getText().equals(config.get("DB_USER")) ||
               !dbPassField.getText().equals(config.get("DB_PASS")) ||
               !sidField.getText().equals(config.get("ACCOUNT_SID")) ||
               !tokenField.getText().equals(config.get("AUTH_TOKEN")) ||
               !twilioField.getText().equals(config.get("TWILIO_NUMBER")) ||
               !emailUserField.getText().equals(config.get("EMAIL_USER")) ||
               !emailPassField.getText().equals(config.get("EMAIL_APP_PASSWORD")) ||
               !emailHostField.getText().equals(config.get("EMAIL_HOST"));
    }

    private void saveConfig() {
        try {
            config.set("DB_URL", dbUrlField.getText().trim());
            config.set("DB_USER", dbUserField.getText().trim());
            config.set("DB_PASS", dbPassField.getText().trim());

            config.set("ACCOUNT_SID", sidField.getText().trim());
            config.set("AUTH_TOKEN", tokenField.getText().trim());
            config.set("TWILIO_NUMBER", twilioField.getText().trim());

            config.set("EMAIL_USER", emailUserField.getText().trim());
            config.set("EMAIL_APP_PASSWORD", emailPassField.getText().trim());
            config.set("EMAIL_HOST", emailHostField.getText().trim());

            config.save();
            
            JOptionPane.showMessageDialog(this, 
                "Configuration saved successfully!\nPlease restart the application for changes to take effect.",
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saving configuration: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void testConnections() {
        // Simple connection testing simulation
        StringBuilder result = new StringBuilder();
        result.append("Connection Test Results:\n\n");
        
        // Test database connection
        if (dbUrlField.getText().trim().isEmpty() || dbUserField.getText().trim().isEmpty()) {
            result.append("❌ Database: Missing URL or username\n");
        } else {
            result.append("✅ Database: Configuration looks valid\n");
        }
        
        // Test Twilio configuration
        if (sidField.getText().trim().isEmpty() || tokenField.getText().trim().isEmpty()) {
            result.append("❌ Twilio: Missing SID or Token\n");
        } else {
            result.append("✅ Twilio: Configuration looks valid\n");
        }
        
        // Test Email configuration
        if (emailUserField.getText().trim().isEmpty() || emailPassField.getText().trim().isEmpty()) {
            result.append("❌ Email: Missing username or password\n");
        } else {
            result.append("✅ Email: Configuration looks valid\n");
        }
        
        result.append("\nNote: This is a basic configuration check.\nActual connectivity testing would require network access.");
        
        JOptionPane.showMessageDialog(this,
            result.toString(),
            "Connection Test Results",
            JOptionPane.INFORMATION_MESSAGE);
    }
}