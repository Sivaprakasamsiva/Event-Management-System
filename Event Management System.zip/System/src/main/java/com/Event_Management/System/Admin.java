package com.Event_Management.System;
import Connectors.*;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import java.awt.Color;


public class Admin extends JFrame {
    private Connection con;
    private String adminId;
    private JTable usersTable;
    private DefaultTableModel usersTableModel;
    private JTable eventsTable;
    private DefaultTableModel eventsTableModel;
    private JTable organizersTable;
    private DefaultTableModel organizersTableModel;
    private JPanel dashboardStats;
    private JScrollPane dashboardActivity;
    private JPanel dashboardRevenue;
    private JPanel dashboardUserGrowth;
    private JLabel refreshLabel;  
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

    public Admin(String adminId) {
        super("Admin Dashboard - Event Management System");
        this.adminId = adminId;

        // Initialize DB connection
        con = getConnection();

        setupUI();
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    
    private void setupUI() {
        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel with logout button
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JTabbedPane tabs = new JTabbedPane();

        // Dashboard Tab
        JPanel overviewPanel = new JPanel(new BorderLayout());
        JPanel gridPanel = new JPanel(new GridLayout(2, 2));

        JPanel statsPanel = createStatsPanel();
        JScrollPane recentActivityPanel = createRecentActivityTable();
        JPanel revenuePanel = createRevenueChart();
        JPanel userGrowthPanel = createUserGrowthChart();

        gridPanel.add(statsPanel);
        gridPanel.add(recentActivityPanel);
        gridPanel.add(revenuePanel);
        gridPanel.add(userGrowthPanel);

        // Save references
        this.dashboardStats = statsPanel;
        this.dashboardActivity = recentActivityPanel;
        this.dashboardRevenue = revenuePanel;
        this.dashboardUserGrowth = userGrowthPanel;

        // Add grid to center
        overviewPanel.add(gridPanel, BorderLayout.CENTER);

        // Refresh label at bottom (small footer)
        refreshLabel = new JLabel("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));
        refreshLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.add(refreshLabel);

        overviewPanel.add(footer, BorderLayout.SOUTH);

        // User Management Tab
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.add(createUsersTablePanel(), BorderLayout.CENTER);
        userPanel.add(createUserActionsPanel(), BorderLayout.SOUTH);

        // Event Management Tab
        JPanel eventManagementPanel = new JPanel(new BorderLayout());
        eventManagementPanel.add(createEventsTablePanel(), BorderLayout.CENTER);
        eventManagementPanel.add(createEventActionsPanel(), BorderLayout.SOUTH);

        // Organizer Management Tab (NEW)
        JPanel organizerPanel = new JPanel(new BorderLayout());
        organizerPanel.add(createOrganizersTablePanel(), BorderLayout.CENTER);
        organizerPanel.add(createOrganizerActionsPanel(), BorderLayout.SOUTH);

        // Settings Tab
        JPanel settingsPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        settingsPanel.add(createSettingsForm());

        tabs.add("Dashboard", overviewPanel);
        tabs.add("User Management", userPanel);
        tabs.add("Event Management", eventManagementPanel);
        tabs.add("Organizer Management", organizerPanel); // NEW TAB
        tabs.add("Settings", settingsPanel);

        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);

        loadUsersData();
        loadAllEvents();
        loadOrganizersData(); // NEW METHOD
        loadRecentActivity();

        // Auto refresh dashboard every 30 sec
        new javax.swing.Timer(30000, e -> refreshDashboard(gridPanel, footer)).start();
    }

    // NEW: Create header panel with logout button
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(65, 105, 225));
        headerPanel.setPreferredSize(new Dimension(1200, 50));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Title label
        JLabel titleLabel = new JLabel("Admin Dashboard - Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(220, 53, 69));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to logout?", 
                "Confirm Logout", 
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                SwingUtilities.invokeLater(() -> {
                    // You'll need to create an App class or replace with your main application class
                    // For now, we'll just show a message
                    JOptionPane.showMessageDialog(null, "Logged out successfully!");
                    SwingUtilities.invokeLater(App::new);
                    // If you have an App class, use: new App();
                });
            }
        });

        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutButton);
        headerPanel.add(logoutPanel, BorderLayout.EAST);

        return headerPanel;
    }

    // NEW: Create organizers table panel
    private JScrollPane createOrganizersTablePanel() {
        String[] columns = {"Organizer ID", "First Name", "Last Name", "Email", "Mobile", "Company", "Verified", "Created At", "Actions"};
        organizersTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 8; // Only Actions editable
            }
        };
        organizersTable = new JTable(organizersTableModel);

        // Style table header
        organizersTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        organizersTable.getTableHeader().setBackground(new Color(102, 51, 153)); // Purple color
        organizersTable.getTableHeader().setForeground(Color.WHITE);

        // Row height & font
        organizersTable.setRowHeight(28);
        organizersTable.setFont(new Font("Arial", Font.PLAIN, 14));

        // Alternating row colors
        organizersTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        // Buttons in Actions column
        organizersTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        organizersTable.getColumn("Actions").setCellEditor(new OrganizerButtonEditor(new JCheckBox(), con, this, organizersTable));

        return new JScrollPane(organizersTable);
    }

    // NEW: Create organizer actions panel with Register button
    private JPanel createOrganizerActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        JButton registerButton = new JButton("Register New Organizer");
        JButton verifyButton = new JButton("Verify Selected");
        JButton unverifyButton = new JButton("Unverify Selected");
        JButton refreshButton = new JButton("Refresh");
        JButton exportButton = new JButton("Export to CSV");

        // Button styling
        for (JButton btn : new JButton[]{registerButton, verifyButton, unverifyButton, refreshButton, exportButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(102, 51, 153)); // Purple color
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(180, 30));
        }

        // Special styling for register button
        registerButton.setBackground(new Color(40, 167, 69)); // Green color for register
        registerButton.setPreferredSize(new Dimension(200, 30));

        registerButton.addActionListener(e -> registerNewOrganizer());
        verifyButton.addActionListener(e -> verifySelectedOrganizer());
        unverifyButton.addActionListener(e -> unverifySelectedOrganizer());
        refreshButton.addActionListener(e -> loadOrganizersData());
        exportButton.addActionListener(e -> exportOrganizersToCSV());

        panel.add(registerButton);
        panel.add(verifyButton);
        panel.add(unverifyButton);
        panel.add(refreshButton);
        panel.add(exportButton);
        return panel;
    }

    // NEW: Method to register a new organizer
    private void registerNewOrganizer() {
        JDialog registerDialog = new JDialog(this, "Register New Organizer", true);
        registerDialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Create form fields
        JTextField firstnameField = new JTextField(20);
        JTextField lastnameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField mobileField = new JTextField(20);
        JTextField companyField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JPasswordField confirmPasswordField = new JPasswordField(20);
        JTextArea addressArea = new JTextArea(3, 20);
        JCheckBox verifiedCheckbox = new JCheckBox("Verified immediately");
        JCheckBox autoVerifyCheckbox = new JCheckBox("Auto-verify this organizer");

        // Set fonts
        Font fieldFont = new Font("Arial", Font.PLAIN, 14);
        firstnameField.setFont(fieldFont);
        lastnameField.setFont(fieldFont);
        emailField.setFont(fieldFont);
        mobileField.setFont(fieldFont);
        companyField.setFont(fieldFont);
        passwordField.setFont(fieldFont);
        confirmPasswordField.setFont(fieldFont);
        addressArea.setFont(fieldFont);

        // Layout the form
        int row = 0;
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(firstnameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(lastnameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Email *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Mobile *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(mobileField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Password *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(passwordField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Confirm Password *:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(confirmPasswordField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Company Name:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(companyField, gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(new JScrollPane(addressArea), gbc);
        
        gbc.gridx = 0; gbc.gridy = row++;
        registerDialog.add(verifiedCheckbox, gbc);
        
        gbc.gridx = 1; gbc.gridy = row++;
        registerDialog.add(autoVerifyCheckbox, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton registerBtn = new JButton("Register");
        JButton cancelBtn = new JButton("Cancel");

        registerBtn.setBackground(new Color(40, 167, 69));
        registerBtn.setForeground(Color.WHITE);
        cancelBtn.setBackground(new Color(108, 117, 125));
        cancelBtn.setForeground(Color.WHITE);

        registerBtn.addActionListener(e -> {
            // Validate form
            if (firstnameField.getText().trim().isEmpty() ||
                lastnameField.getText().trim().isEmpty() ||
                emailField.getText().trim().isEmpty() ||
                mobileField.getText().trim().isEmpty() ||
                passwordField.getPassword().length == 0) {
                
                JOptionPane.showMessageDialog(registerDialog, 
                    "Please fill in all required fields (*)", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!new String(passwordField.getPassword()).equals(new String(confirmPasswordField.getPassword()))) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Passwords do not match!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (new String(passwordField.getPassword()).length() < 6) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Password must be at least 6 characters long!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Register the organizer
            try {
                String sql = "INSERT INTO organizers (firstname, lastname, email, mobile, password, company_name, address, verified) " +
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, firstnameField.getText().trim());
                ps.setString(2, lastnameField.getText().trim());
                ps.setString(3, emailField.getText().trim());
                ps.setString(4, mobileField.getText().trim());
                
                // Hash the password (in a real application, use proper hashing like BCrypt)
                String password = new String(passwordField.getPassword());
                // For now, we'll store as plain text (NOT recommended for production)
                ps.setString(5, password);
                
                ps.setString(6, companyField.getText().trim().isEmpty() ? null : companyField.getText().trim());
                ps.setString(7, addressArea.getText().trim().isEmpty() ? null : addressArea.getText().trim());
                ps.setBoolean(8, verifiedCheckbox.isSelected());

                int result = ps.executeUpdate();
                if (result > 0) {
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Organizer registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    registerDialog.dispose();
                    loadOrganizersData(); // Refresh the table
                    
                    // If auto-verify is checked, set system to auto-verify future organizers
                    if (autoVerifyCheckbox.isSelected()) {
                        updateAutoVerifySetting(true);
                    }
                }
            } catch (SQLException ex) {
                if (ex.getErrorCode() == 1062) { // Duplicate entry
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Email or mobile number already exists!", "Registration Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Error registering organizer: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelBtn.addActionListener(e -> registerDialog.dispose());

        buttonPanel.add(cancelBtn);
        buttonPanel.add(registerBtn);

        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        registerDialog.add(buttonPanel, gbc);

        registerDialog.setSize(500, 550);
        registerDialog.setLocationRelativeTo(this);
        registerDialog.setVisible(true);
    }

    // NEW: Method to update auto-verify setting
    private void updateAutoVerifySetting(boolean autoVerify) {
        try {
            String sql = "UPDATE SystemSettings SET auto_verify_organizers = ? WHERE id = 1";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setBoolean(1, autoVerify);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // NEW: Load organizers data
    void loadOrganizersData() {
        try {
            String sql = "SELECT organizer_id, firstname, lastname, email, mobile, company_name, verified, created_at FROM organizers";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            organizersTableModel.setRowCount(0);
            while (rs.next()) {
                organizersTableModel.addRow(new Object[]{
                    rs.getInt("organizer_id"),
                    rs.getString("firstname"),
                    rs.getString("lastname"),
                    rs.getString("email"),
                    rs.getString("mobile"),
                    rs.getString("company_name"),
                    rs.getBoolean("verified") ? "Verified" : "Not Verified",
                    rs.getTimestamp("created_at"),
                    "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // NEW: Verify selected organizer
    private void verifySelectedOrganizer() {
        int selectedRow = organizersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an organizer to verify.");
            return;
        }
        
        int organizerId = (Integer) organizersTableModel.getValueAt(selectedRow, 0);
        String organizerName = organizersTableModel.getValueAt(selectedRow, 1) + " " + organizersTableModel.getValueAt(selectedRow, 2);
        
        try {
            String sql = "UPDATE organizers SET verified = 1 WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, organizerId);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Organizer '" + organizerName + "' verified successfully!");
                loadOrganizersData();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error verifying organizer: " + ex.getMessage());
        }
    }

    // NEW: Unverify selected organizer
    private void unverifySelectedOrganizer() {
        int selectedRow = organizersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an organizer to unverify.");
            return;
        }
        
        int organizerId = (Integer) organizersTableModel.getValueAt(selectedRow, 0);
        String organizerName = organizersTableModel.getValueAt(selectedRow, 1) + " " + organizersTableModel.getValueAt(selectedRow, 2);
        
        try {
            String sql = "UPDATE organizers SET verified = 0 WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, organizerId);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Organizer '" + organizerName + "' unverified successfully!");
                loadOrganizersData();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error unverifying organizer: " + ex.getMessage());
        }
    }

    // NEW: Export organizers to CSV
    private void exportOrganizersToCSV() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Specify a file to save");
            
            int userSelection = fileChooser.showSaveDialog(this);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                FileWriter writer = new FileWriter(fileChooser.getSelectedFile() + ".csv");
                
                // Write header
                for (int i = 0; i < organizersTableModel.getColumnCount(); i++) {
                    writer.write(organizersTableModel.getColumnName(i));
                    if (i < organizersTableModel.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.write("\n");
                
                // Write data
                for (int i = 0; i < organizersTableModel.getRowCount(); i++) {
                    for (int j = 0; j < organizersTableModel.getColumnCount(); j++) {
                        writer.write(organizersTableModel.getValueAt(i, j).toString());
                        if (j < organizersTableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.write("\n");
                }
                
                writer.close();
                JOptionPane.showMessageDialog(this, "Organizers data exported successfully to CSV!");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting to CSV: " + ex.getMessage());
        }
    }

    // Rest of the existing methods remain exactly the same...
    private void refreshDashboard(JPanel gridPanel, JPanel footer) {
        gridPanel.removeAll();

        dashboardStats = createStatsPanel();
        dashboardActivity = createRecentActivityTable();
        dashboardRevenue = createRevenueChart();
        dashboardUserGrowth = createUserGrowthChart();

        gridPanel.add(dashboardStats);
        gridPanel.add(dashboardActivity);
        gridPanel.add(dashboardRevenue);
        gridPanel.add(dashboardUserGrowth);

        refreshLabel.setText("Last refresh: " + java.time.LocalTime.now().format(TIME_FORMATTER));

        gridPanel.revalidate();
        gridPanel.repaint();
        footer.revalidate();
        footer.repaint();
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        try {
            String[] queries = {
                "SELECT COUNT(*) FROM Members",
                "SELECT COUNT(*) FROM Events WHERE event_date >= CURDATE()",
                "SELECT COUNT(*) FROM Bookings WHERE booking_date >= CURDATE() - INTERVAL 30 DAY",
                "SELECT SUM(total_amount) FROM Payments WHERE payment_status = 'Success' AND payment_date >= CURDATE() - INTERVAL 30 DAY"
            };

            String[] labels = {"Total Users", "Upcoming Events", "Bookings (30 days)", "Revenue (30 days)"};
            Color[] colors = {new Color(135, 206, 250), new Color(144, 238, 144), new Color(255, 182, 193), new Color(255, 228, 181)};

            for (int i = 0; i < queries.length; i++) {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(queries[i]);
                if (rs.next()) {
                    JPanel statCard = new JPanel(new BorderLayout());
                    statCard.setBackground(colors[i]);
                    statCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.GRAY, 1, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    ));

                    JLabel title = new JLabel(labels[i], JLabel.CENTER);
                    title.setFont(new Font("Segoe UI", Font.BOLD, 14));
                    title.setForeground(Color.DARK_GRAY);

                    String valueText = rs.getString(1);
                    if (valueText == null) valueText = "0";

                    JLabel value = new JLabel(valueText, JLabel.CENTER);
                    value.setFont(new Font("Segoe UI", Font.BOLD, 20));
                    value.setForeground(new Color(0, 102, 204));

                    statCard.add(title, BorderLayout.NORTH);
                    statCard.add(value, BorderLayout.CENTER);
                    statsPanel.add(statCard);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading statistics: " + ex.getMessage());
        }

        return statsPanel;
    }

    private JScrollPane createRecentActivityTable() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"User", "Activity", "Date"}, 0);
        JTable table = new JTable(model);
        
        table.setFillsViewportHeight(true);
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(60, 179, 113));
        table.getTableHeader().setForeground(Color.WHITE);

        // Alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        try {
            String sql = "SELECT m.username, 'Booking' AS activity, b.booking_date AS activity_date " +
                         "FROM Bookings b " +
                         "JOIN Members m ON b.user_id = m.member_id " +
                         "WHERE b.booking_date >= CURDATE() - INTERVAL 7 DAY " +
                         "UNION ALL " +
                         "SELECT m.username, 'Registration' AS activity, m.created_at AS activity_date " +
                         "FROM Members m " +
                         "WHERE m.created_at >= CURDATE() - INTERVAL 7 DAY " +
                         "ORDER BY activity_date DESC LIMIT 10";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("username"),
                    rs.getString("activity"),
                    rs.getTimestamp("activity_date")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        return scrollPane;
    }

    private JPanel createRevenueChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Revenue Chart"));

        // Table model
        DefaultTableModel model = new DefaultTableModel(new String[]{"Month", "Revenue"}, 0);
        JTable table = new JTable(model);

        // Style table header
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(60, 179, 113));
        table.getTableHeader().setForeground(Color.WHITE);

        // Row height & font
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        // Alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        // Load data from database
        try {
            String sql = "SELECT DATE_FORMAT(payment_date, '%Y-%m') as month, SUM(total_amount) as revenue " +
                         "FROM Payments WHERE payment_status = 'Success' " +
                         "GROUP BY DATE_FORMAT(payment_date, '%Y-%m') " +
                         "ORDER BY month DESC LIMIT 6";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            // Decimal formatter to avoid scientific notation
            java.text.DecimalFormat df = new java.text.DecimalFormat("#,##0.00");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("month"),
                    df.format(rs.getDouble("revenue"))
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createUserGrowthChart() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("User Growth Chart"));

        DefaultTableModel model = new DefaultTableModel(new String[]{"Month", "New Users"}, 0);
        JTable table = new JTable(model);

        // Style table header
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(65, 105, 225));
        table.getTableHeader().setForeground(Color.WHITE);

        // Row height & font
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        // Alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        // Load data from database
        try {
            String sql = "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as new_users " +
                         "FROM Members GROUP BY DATE_FORMAT(created_at, '%Y-%m') " +
                         "ORDER BY month DESC LIMIT 6";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("month"),
                    rs.getInt("new_users")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JScrollPane createUsersTablePanel() {
        String[] columns = {"User ID", "Username", "Email", "Mobile", "Status", "Join Date", "Actions"};
        usersTableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Only Actions editable
            }
        };
        usersTable = new JTable(usersTableModel);

        // Style table header
        usersTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        usersTable.getTableHeader().setBackground(new Color(65, 105, 225));
        usersTable.getTableHeader().setForeground(Color.WHITE);

        // Row height & font
        usersTable.setRowHeight(28);
        usersTable.setFont(new Font("Arial", Font.PLAIN, 14));

        // Alternating row colors
        usersTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        // Buttons in Actions column
        usersTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        usersTable.getColumn("Actions").setCellEditor(new ButtonEditor(new JCheckBox(), con, this, usersTable));

        return new JScrollPane(usersTable);
    }

    private JPanel createUserActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        JButton refreshButton = new JButton("Refresh");
        JButton exportButton = new JButton("Export to CSV");

        // Button styling
        for (JButton btn : new JButton[]{refreshButton, exportButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(140, 30));
        }

        refreshButton.addActionListener(e -> loadUsersData());
        exportButton.addActionListener(e -> exportUsersToCSV());

        panel.add(refreshButton);
        panel.add(exportButton);
        return panel;
    }

    private JScrollPane createEventsTablePanel() {
        String[] columns = {"Event ID", "Title", "Organizer", "Date", "Venue", "Tickets Sold", "Revenue", "Status", "Actions"};
        eventsTableModel = new DefaultTableModel(columns, 0);
        eventsTable = new JTable(eventsTableModel);

        // Table header styling
        eventsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        eventsTable.getTableHeader().setBackground(new Color(65, 105, 225));
        eventsTable.getTableHeader().setForeground(Color.WHITE);

        // Row styling
        eventsTable.setRowHeight(28);
        eventsTable.setFont(new Font("Arial", Font.PLAIN, 14));
        eventsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 245, 245) : Color.WHITE);
                }
                return c;
            }
        });

        // Buttons in Actions column
        eventsTable.getColumn("Actions").setCellRenderer(new ButtonRenderer());
        eventsTable.getColumn("Actions").setCellEditor(new EventButtonEditor(new JCheckBox(), con, this, eventsTable));

        return new JScrollPane(eventsTable);
    }

    private JPanel createEventActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBackground(new Color(240, 240, 240));

        JButton approveButton = new JButton("Approve Selected");
        JButton rejectButton = new JButton("Reject Selected");
        JButton featureButton = new JButton("Feature Event");
        JButton refreshButton = new JButton("Refresh");

        // Button styling
        for (JButton btn : new JButton[]{approveButton, rejectButton, featureButton, refreshButton}) {
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setBackground(new Color(65, 105, 225));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(150, 30));
        }

        approveButton.addActionListener(e -> approveSelectedEvent());
        rejectButton.addActionListener(e -> rejectSelectedEvent());
        featureButton.addActionListener(e -> featureSelectedEvent());
        refreshButton.addActionListener(e -> loadAllEvents());

        panel.add(approveButton);
        panel.add(rejectButton);
        panel.add(featureButton);
        panel.add(refreshButton);
        return panel;
    }

    private JPanel createSettingsForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // System Name
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel nameLabel = new JLabel("System Name:");
        panel.add(nameLabel, gbc);

        gbc.gridx = 1;
        JTextField systemName = new JTextField(15);
        systemName.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(systemName, gbc);

        // Commission Rate
        gbc.gridx = 0; gbc.gridy++;
        JLabel commissionLabel = new JLabel("Commission Rate (%):");
        commissionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(commissionLabel, gbc);

        gbc.gridx = 1;
        JTextField commissionField = new JTextField(7);
        commissionField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(commissionField, gbc);

        // Auto-approve Events
        gbc.gridx = 0; gbc.gridy++;
        JLabel autoApproveLabel = new JLabel("Auto-approve Events:");
        autoApproveLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(autoApproveLabel, gbc);

        gbc.gridx = 1;
        JCheckBox autoApprove = new JCheckBox();
        panel.add(autoApprove, gbc);

        // Max Events per Organizer
        gbc.gridx = 0; gbc.gridy++;
        JLabel maxEventsLabel = new JLabel("Max Events per Organizer:");
        maxEventsLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(maxEventsLabel, gbc);

        gbc.gridx = 1;
        JTextField maxEvents = new JTextField(7);
        maxEvents.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(maxEvents, gbc);

        // Save Button
        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton saveButton = new JButton("Save Settings");
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.setBackground(new Color(65, 105, 225));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new Dimension(180, 35));

        saveButton.addActionListener(e -> saveSettings(
                systemName.getText(),
                commissionField.getText(),
                autoApprove.isSelected(),
                maxEvents.getText()
        ));
        panel.add(saveButton, gbc);

        loadCurrentSettings(systemName, commissionField, autoApprove, maxEvents);

        return panel;
    }

    private void loadCurrentSettings(JTextField systemName, JTextField commission, JCheckBox autoApprove, JTextField maxEvents) {
        try {
            String sql = "SELECT * FROM SystemSettings WHERE id = 1";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                systemName.setText(rs.getString("system_name"));
                commission.setText(String.valueOf(rs.getDouble("commission_rate")));
                autoApprove.setSelected(rs.getBoolean("auto_approve_events"));
                maxEvents.setText(String.valueOf(rs.getInt("max_events_per_organizer")));
            } else {
                // Insert default settings if not exists
                String insertSql = "INSERT INTO SystemSettings (system_name, commission_rate, auto_approve_events, max_events_per_organizer) " +
                                   "VALUES ('Event Management System', 5.0, false, 10)";
                stmt.executeUpdate(insertSql);

                systemName.setText("Event Management System");
                commission.setText("5.0");
                autoApprove.setSelected(false);
                maxEvents.setText("10");
            }

            // Improve UI styling for settings fields
            Font fieldFont = new Font("Arial", Font.PLAIN, 14);
            systemName.setFont(fieldFont);
            commission.setFont(fieldFont);
            autoApprove.setFont(fieldFont);
            maxEvents.setFont(fieldFont);

            // Set preferred sizes for text fields
            systemName.setPreferredSize(new Dimension(250, 30));
            commission.setPreferredSize(new Dimension(100, 30));
            maxEvents.setPreferredSize(new Dimension(100, 30));

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading settings: " + ex.getMessage());
        }
    }

    private void saveSettings(String systemName, String commission, boolean autoApprove, String maxEvents) {
        try {
            String sql = "UPDATE SystemSettings SET system_name=?, commission_rate=?, auto_approve_events=?, max_events_per_organizer=? WHERE id=1";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, systemName);
            ps.setDouble(2, Double.parseDouble(commission));
            ps.setBoolean(3, autoApprove);
            ps.setInt(4, Integer.parseInt(maxEvents));

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "✅ Settings saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Error saving settings: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    void loadUsersData() {
        try {
            String sql = "SELECT member_id, username, email, mobile, active, created_at FROM Members";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            usersTableModel.setRowCount(0);
            while (rs.next()) {
                usersTableModel.addRow(new Object[]{
                        rs.getInt("member_id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("mobile"),
                        rs.getBoolean("active") ? "Active" : "Inactive",
                        rs.getDate("created_at"),
                        "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    void loadAllEvents() {
        try {
            String sql = "SELECT e.event_id, e.title, o.firstname, o.lastname, e.event_date, e.venue, " +
                         "e.tickets_sold, e.revenue, e.status " +
                         "FROM events e " +
                         "JOIN organizers o ON e.organizer_id = o.organizer_id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            eventsTableModel.setRowCount(0);

            while (rs.next()) {
                String organizerName = rs.getString("firstname") + " " + rs.getString("lastname");
                eventsTableModel.addRow(new Object[]{
                        rs.getInt("event_id"),
                        rs.getString("title"),
                        organizerName,
                        rs.getTimestamp("event_date"),
                        rs.getString("venue"),
                        rs.getInt("tickets_sold"),
                        rs.getDouble("revenue"),
                        rs.getString("status"),
                        "Edit"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading events: " + ex.getMessage());
        }
    }

    private void loadRecentActivity() {
        // Implementation for recent activity
    }

    private void exportUsersToCSV() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Specify a file to save");
            
            int userSelection = fileChooser.showSaveDialog(this);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                FileWriter writer = new FileWriter(fileChooser.getSelectedFile() + ".csv");
                
                // Write header
                for (int i = 0; i < usersTableModel.getColumnCount(); i++) {
                    writer.write(usersTableModel.getColumnName(i));
                    if (i < usersTableModel.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.write("\n");
                
                // Write data
                for (int i = 0; i < usersTableModel.getRowCount(); i++) {
                    for (int j = 0; j < usersTableModel.getColumnCount(); j++) {
                        writer.write(usersTableModel.getValueAt(i, j).toString());
                        if (j < usersTableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.write("\n");
                }
                
                writer.close();
                JOptionPane.showMessageDialog(this, "Users data exported successfully to CSV!");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting to CSV: " + ex.getMessage());
        }
    }
    
    private void approveSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to approve.");
            return;
        }
        
        int eventId = (Integer) eventsTableModel.getValueAt(selectedRow, 0);
        
        try {
            String sql = "UPDATE Events SET status = 'Approved' WHERE event_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, eventId);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Event approved successfully!");
                loadAllEvents();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error approving event: " + ex.getMessage());
        }
    }
    
    private void rejectSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to reject.");
            return;
        }
        
        int eventId = (Integer) eventsTableModel.getValueAt(selectedRow, 0);
        
        try {
            String sql = "UPDATE Events SET status = 'Rejected' WHERE event_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, eventId);
            
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Event rejected successfully!");
                loadAllEvents();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error rejecting event: " + ex.getMessage());
        }
    }
    
    private void featureSelectedEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to feature.");
            return;
        }
        
        int eventId = (Integer) eventsTableModel.getValueAt(selectedRow, 0);
        String eventTitle = (String) eventsTableModel.getValueAt(selectedRow, 1);
        
        JOptionPane.showMessageDialog(this, "Event '" + eventTitle + "' has been featured!");
    }

    private Connection getConnection() {
        try {
        	ConfigManager cfg = new ConfigManager();
            String url = cfg.get("DB_URL");
            String user = cfg.get("DB_USER");
            String password = cfg.get("DB_PASS");
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage());
            return null;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Admin("1"));
    }
}

// Button Renderer and Editor Classes
class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
    }

    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "Edit" : value.toString());
        return this;
    }
}

class ButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Admin admin;
    private JTable table;

    public ButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
        super(checkBox);
        this.con = con;
        this.admin = admin;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int userId = (Integer) table.getModel().getValueAt(row, 0);
            showUserEditDialog(userId);
        }
        isPushed = false;
        return label;
    }
    
    private void showUserEditDialog(int userId) {
        JDialog editDialog = new JDialog(admin, "Edit User", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        JTextField usernameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField mobileField = new JTextField();
        JCheckBox activeCheckbox = new JCheckBox("Active");
        
        try {
            String sql = "SELECT * FROM Members WHERE member_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                usernameField.setText(rs.getString("username"));
                emailField.setText(rs.getString("email"));
                mobileField.setText(rs.getString("mobile"));
                activeCheckbox.setSelected(rs.getBoolean("active"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("Username:"));
        editDialog.add(usernameField);
        editDialog.add(new JLabel("Email:"));
        editDialog.add(emailField);
        editDialog.add(new JLabel("Mobile:"));
        editDialog.add(mobileField);
        editDialog.add(new JLabel("Status:"));
        editDialog.add(activeCheckbox);
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE Members SET username=?, email=?, mobile=?, active=? WHERE member_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, usernameField.getText());
                ps.setString(2, emailField.getText());
                ps.setString(3, mobileField.getText());
                ps.setBoolean(4, activeCheckbox.isSelected());
                ps.setInt(5, userId);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "User updated successfully!");
                    editDialog.dispose();
                    admin.loadUsersData();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating user: " + ex.getMessage());
            }
        });
        
        editDialog.add(new JLabel(""));
        editDialog.add(saveButton);
        
        editDialog.setSize(400, 200);
        editDialog.setLocationRelativeTo(admin);
        editDialog.setVisible(true);
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

class EventButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Admin admin;
    private JTable table;

    public EventButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
        super(checkBox);
        this.con = con;
        this.admin = admin;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int eventId = (Integer) table.getModel().getValueAt(row, 0);
            showEventEditDialog(eventId);
        }
        isPushed = false;
        return label;
    }
    
    private void showEventEditDialog(int eventId) {
        JDialog editDialog = new JDialog(admin, "Edit Event", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        JTextField titleField = new JTextField();
        JTextArea descriptionArea = new JTextArea(3, 20);
        JTextField venueField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField capacityField = new JTextField();
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Pending", "Approved", "Rejected", "Cancelled"});
        
        try {
            String sql = "SELECT * FROM Events WHERE event_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                titleField.setText(rs.getString("title"));
                descriptionArea.setText(rs.getString("description"));
                venueField.setText(rs.getString("venue"));
                priceField.setText(String.valueOf(rs.getDouble("price")));
                capacityField.setText(String.valueOf(rs.getInt("capacity")));
                statusCombo.setSelectedItem(rs.getString("status"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("Title:"));
        editDialog.add(titleField);
        editDialog.add(new JLabel("Description:"));
        editDialog.add(new JScrollPane(descriptionArea));
        editDialog.add(new JLabel("Venue:"));
        editDialog.add(venueField);
        editDialog.add(new JLabel("Price:"));
        editDialog.add(priceField);
        editDialog.add(new JLabel("Capacity:"));
        editDialog.add(capacityField);
        editDialog.add(new JLabel("Status:"));
        editDialog.add(statusCombo);
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE Events SET title=?, description=?, venue=?, price=?, capacity=?, status=? WHERE event_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, titleField.getText());
                ps.setString(2, descriptionArea.getText());
                ps.setString(3, venueField.getText());
                ps.setDouble(4, Double.parseDouble(priceField.getText()));
                ps.setInt(5, Integer.parseInt(capacityField.getText()));
                ps.setString(6, (String) statusCombo.getSelectedItem());
                ps.setInt(7, eventId);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Event updated successfully!");
                    editDialog.dispose();
                    admin.loadAllEvents();
                }
            } catch (SQLException | NumberFormatException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating event: " + ex.getMessage());
            }
        });
        
        editDialog.add(new JLabel(""));
        editDialog.add(saveButton);
        
        editDialog.setSize(500, 300);
        editDialog.setLocationRelativeTo(admin);
        editDialog.setVisible(true);
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}

// NEW: Organizer Button Editor class
class OrganizerButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean isPushed;
    private Connection con;
    private Admin admin;
    private JTable table;

    public OrganizerButtonEditor(JCheckBox checkBox, Connection con, Admin admin, JTable table) {
        super(checkBox);
        this.con = con;
        this.admin = admin;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Edit" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            int organizerId = (Integer) table.getModel().getValueAt(row, 0);
            showOrganizerEditDialog(organizerId);
        }
        isPushed = false;
        return label;
    }
    
    private void showOrganizerEditDialog(int organizerId) {
        JDialog editDialog = new JDialog(admin, "Edit Organizer", true);
        editDialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        JTextField firstnameField = new JTextField();
        JTextField lastnameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField mobileField = new JTextField();
        JTextField companyField = new JTextField();
        JTextArea addressArea = new JTextArea(3, 20);
        JCheckBox verifiedCheckbox = new JCheckBox("Verified");
        
        try {
            String sql = "SELECT * FROM organizers WHERE organizer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, organizerId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                firstnameField.setText(rs.getString("firstname"));
                lastnameField.setText(rs.getString("lastname"));
                emailField.setText(rs.getString("email"));
                mobileField.setText(rs.getString("mobile"));
                companyField.setText(rs.getString("company_name"));
                addressArea.setText(rs.getString("address"));
                verifiedCheckbox.setSelected(rs.getBoolean("verified"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        editDialog.add(new JLabel("First Name:"));
        editDialog.add(firstnameField);
        editDialog.add(new JLabel("Last Name:"));
        editDialog.add(lastnameField);
        editDialog.add(new JLabel("Email:"));
        editDialog.add(emailField);
        editDialog.add(new JLabel("Mobile:"));
        editDialog.add(mobileField);
        editDialog.add(new JLabel("Company:"));
        editDialog.add(companyField);
        editDialog.add(new JLabel("Address:"));
        editDialog.add(new JScrollPane(addressArea));
        editDialog.add(new JLabel("Verified:"));
        editDialog.add(verifiedCheckbox);
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                String updateSql = "UPDATE organizers SET firstname=?, lastname=?, email=?, mobile=?, company_name=?, address=?, verified=? WHERE organizer_id=?";
                PreparedStatement ps = con.prepareStatement(updateSql);
                ps.setString(1, firstnameField.getText());
                ps.setString(2, lastnameField.getText());
                ps.setString(3, emailField.getText());
                ps.setString(4, mobileField.getText());
                ps.setString(5, companyField.getText());
                ps.setString(6, addressArea.getText());
                ps.setBoolean(7, verifiedCheckbox.isSelected());
                ps.setInt(8, organizerId);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(editDialog, "Organizer updated successfully!");
                    editDialog.dispose();
                    admin.loadOrganizersData();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(editDialog, "Error updating organizer: " + ex.getMessage());
            }
        });
        
        editDialog.add(new JLabel(""));
        editDialog.add(saveButton);
        
        editDialog.setSize(500, 350);
        editDialog.setLocationRelativeTo(admin);
        editDialog.setVisible(true);
    }

    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }
}