package Connectors;



import java.io.*;
import java.util.*;

import javax.swing.SwingUtilities;



public class ConfigManager {
	public static void main(String[] args) {
    	new ConfigManager();
    }
    private static final String CONFIG_FILE = "config.properties";
    private Properties props = new Properties();

    public ConfigManager() {
        load();
    }

    public void load() {
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
        } catch (IOException e) {
            System.out.println("Config file not found, using defaults.");
        }
    }

    public void save() {
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Event Management Config");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String key) {
        return props.getProperty(key, "");
    }

    public void set(String key, String value) {
        props.setProperty(key, value);
    }
    
}
