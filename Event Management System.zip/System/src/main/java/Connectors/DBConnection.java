package Connectors;





import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class DBConnection {
	static ConfigManager cfg = new ConfigManager();
	
    static final String URL = cfg.get("DB_URL");
    static final String USER = cfg.get("DB_USER");    
    static final String PASS = cfg.get("DB_PASS"); 

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database connection failed: " + e.getMessage());
            return null;
        }
    }
}


